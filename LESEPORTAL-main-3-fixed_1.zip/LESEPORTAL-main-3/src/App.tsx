import React, { useState, useEffect } from "react";
import {
  Library,
  LayoutDashboard,
  BookOpen,
  Users,
  RefreshCw,
  AlertCircle,
  Check,
  Sparkles,
  LogOut,
} from "lucide-react";

// Types
import { Book, Member, Loan, LibraryUser, LibraryOpeningHours } from "./types";

// DB Service
import { LibraryDB } from "./services/db";

// Components
import { DashboardOverview } from "./components/DashboardOverview";
import { BookCatalog } from "./components/BookCatalog";
import { BorrowReturn } from "./components/BorrowReturn";
import { MemberManagement } from "./components/MemberManagement";
import { ScannerModal } from "./components/ScannerModal";
import { LoginSignup } from "./components/LoginSignup";
import { MemberDashboard } from "./components/MemberDashboard";
import SuperadminDashboard from "./components/SuperadminDashboard";

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // User Auth State
  const [currentUser, setCurrentUser] = useState<LibraryUser | null>(() => {
    const saved = localStorage.getItem("library_current_user");
    try {
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [users, setUsers] = useState<LibraryUser[]>([]);
  const [openingHours, setOpeningHours] = useState<LibraryOpeningHours | null>(null);

  // State
  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Scanner modal triggers
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);

  // Ref to trigger catalog state pre-population
  const [scannedBookPreset, setScannedBookPreset] = useState<Partial<Book> | null>(null);

  // Load initial data
  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [fetchedBooks, fetchedMembers, fetchedLoans, fetchedUsers] = await Promise.all([
        LibraryDB.getBooks(),
        LibraryDB.getMembers(),
        LibraryDB.getLoans(),
        LibraryDB.getUsers(),
      ]);

      setBooks(fetchedBooks);
      setMembers(fetchedMembers);
      setLoans(fetchedLoans);
      setUsers(fetchedUsers);
    } catch (err: any) {
      console.error("Error loading library data:", err);
      setError("Daten konnten nicht vollständig geladen werden. Verwende Offline-Modus.");
    } finally {
      setLoading(false);
    }
  };

  const loadUsersList = async () => {
    try {
      const fetchedUsers = await LibraryDB.getUsers();
      setUsers(fetchedUsers);
    } catch (err) {
      console.error("Error refreshing users:", err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (currentUser?.schoolCode) {
      LibraryDB.getOpeningHours(currentUser.schoolCode).then((hours) => {
        setOpeningHours(hours);
      });
    } else {
      setOpeningHours(null);
    }
  }, [currentUser]);

  const handleSaveOpeningHours = async (hours: LibraryOpeningHours) => {
    try {
      await LibraryDB.saveOpeningHours(hours);
      setOpeningHours(hours);
      triggerNotification("Öffnungszeiten erfolgreich aktualisiert!");
    } catch (err) {
      triggerNotification("Fehler beim Speichern der Öffnungszeiten.", "error");
    }
  };


  // Notifications helper
  const triggerNotification = (message: string, type: "success" | "error" = "success") => {
    if (type === "error") {
      setError(message);
      setTimeout(() => setError(null), 5000);
    } else {
      setSuccessMessage(message);
      setTimeout(() => setSuccessMessage(null), 4000);
    }
  };

  // --- ACTIONS ---

  // Add/Edit Book
  const handleAddBook = async (book: Book) => {
    try {
      await LibraryDB.saveBook(book);
      // Update local state
      setBooks((prev) => [...prev.filter((b) => b.id !== book.id), book]);
      triggerNotification(`Buch "${book.title}" erfolgreich gespeichert!`);
    } catch (err) {
      triggerNotification("Konnte Buch nicht in Datenbank speichern.", "error");
    }
  };

  // Delete Book
  const handleDeleteBook = async (id: string) => {
    const book = books.find((b) => b.id === id);
    if (!book) return;

    if (book.status === "borrowed") {
      triggerNotification("Dieses Buch ist ausgeliehen und kann nicht gelöscht werden!", "error");
      return;
    }

    try {
      await LibraryDB.deleteBook(id);
      setBooks((prev) => prev.filter((b) => b.id !== id));
      triggerNotification(`Buch "${book.title}" wurde gelöscht.`);
    } catch (err) {
      triggerNotification("Fehler beim Löschen des Buches.", "error");
    }
  };

  // Add Member
  const handleAddMember = async (member: Member) => {
    try {
      await LibraryDB.saveMember(member);
      setMembers((prev) => [...prev.filter((m) => m.id !== member.id), member]);
      triggerNotification(`Mitglied "${member.name}" wurde erfolgreich registriert.`);
    } catch (err) {
      triggerNotification("Mitglied konnte nicht registriert werden.", "error");
    }
  };

  // Delete Member
  const handleDeleteMember = async (id: string) => {
    const member = members.find((m) => m.id === id);
    if (!member) return;

    // Check if member has active loans
    const hasActiveLoans = loans.some((l) => l.memberId === id && !l.returnDate);
    if (hasActiveLoans) {
      triggerNotification("Mitglied hat noch offene Ausleihen und kann nicht gelöscht werden!", "error");
      return;
    }

    try {
      await LibraryDB.deleteMember(id);
      setMembers((prev) => prev.filter((m) => m.id !== id));
      triggerNotification(`Konto von "${member.name}" gelöscht.`);
    } catch (err) {
      triggerNotification("Fehler beim Löschen des Mitglieds.", "error");
    }
  };

  // Issue/Borrow Book
  const handleBorrowBook = async (loan: Loan) => {
    try {
      await LibraryDB.createLoan(loan);
      
      // Update local state of loans and books
      setLoans((prev) => [...prev.filter((l) => l.id !== loan.id), loan]);
      setBooks((prev) =>
        prev.map((b) =>
          b.id === loan.bookId
            ? {
                ...b,
                status: "borrowed",
                borrowerId: loan.memberId,
                borrowerName: loan.memberName,
                dueDate: loan.dueDate,
              }
            : b
        )
      );

      triggerNotification(`Buch erfolgreich für ${loan.memberName} gebucht!`);
    } catch (err) {
      triggerNotification("Fehler beim Erstellen des Ausleihvorgangs.", "error");
    }
  };

  // Return Book
  const handleReturnBook = async (loanId: string) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return;

    try {
      await LibraryDB.returnLoan(loanId);
      
      // Update states
      setLoans((prev) =>
        prev.map((l) => (l.id === loanId ? { ...l, status: "returned", returnDate: "2026-06-24" } : l))
      );
      setBooks((prev) =>
        prev.map((b) =>
          b.id === loan.bookId
            ? { ...b, status: "available", borrowerId: null, borrowerName: null, dueDate: null }
            : b
        )
      );

      triggerNotification(`Buch "${loan.bookTitle}" erfolgreich zurückgegeben.`);
    } catch (err) {
      triggerNotification("Fehler beim Buchen der Rückgabe.", "error");
    }
  };

  // Extend Loan Deadline
  const handleExtendBook = async (loanId: string, newDueDate: string) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return;

    try {
      await LibraryDB.extendLoan(loanId, newDueDate);

      // Update states
      setLoans((prev) =>
        prev.map((l) => (l.id === loanId ? { ...l, dueDate: newDueDate, extendedCount: l.extendedCount + 1 } : l))
      );
      setBooks((prev) =>
        prev.map((b) => (b.id === loan.bookId ? { ...b, dueDate: newDueDate } : b))
      );

      triggerNotification(`Frist für "${loan.bookTitle}" wurde auf ${newDueDate.split("-").reverse().join(".")} geändert.`);
    } catch (err) {
      triggerNotification("Fehler beim Verlängern der Leihfrist.", "error");
    }
  };

  // Handle scanned book injection
  const handleBookDetected = (bookData: Partial<Book>) => {
    setScannedBookPreset(bookData);
    setActiveTab("books");
    triggerNotification("Scandaten empfangen! Trage Details im Katalog ein...");
  };

  // Clear scanned data after consumption
  const consumeScannedPreset = () => {
    setScannedBookPreset(null);
  };

  // 1. Auth Guard - if no user is authenticated, render Login/Signup
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-gray-800 selection:bg-indigo-100 selection:text-indigo-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full mt-4 empty:hidden">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 flex items-center gap-3 text-red-800 text-sm shadow-xs animate-slide-in">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <p className="font-medium">{error}</p>
            </div>
          )}
          {successMessage && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center gap-3 text-emerald-800 text-sm shadow-xs animate-slide-in">
              <Check className="w-5 h-5 text-emerald-600 shrink-0" />
              <p className="font-medium">{successMessage}</p>
            </div>
          )}
        </div>

        {loading ? (
          <div className="flex-1 flex flex-col items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-gray-600 font-semibold">Bücherei-Datenbank wird synchronisiert...</p>
            <span className="text-xs text-gray-400 mt-1">Lade Bestände, Karten und aktive Ausleihen</span>
          </div>
        ) : (
          <LoginSignup
            onLoginSuccess={(user) => {
              setCurrentUser(user);
              localStorage.setItem("library_current_user", JSON.stringify(user));
              triggerNotification(`Erfolgreich angemeldet als ${user.name}`);
            }}
            users={users}
            onRefreshUsers={loadUsersList}
          />
        )}

        <footer className="bg-white border-t border-gray-200 py-6 mt-12 text-center text-xs text-gray-400">
          <div className="max-w-7xl mx-auto px-4">
            <p>© 2026 LesePortal • Alle Rechte vorbehalten.</p>
          </div>
        </footer>
      </div>
    );
  }

  // 2. Member/User Guard - if a Pupil or Teacher is logged in, show their personalized dashboard
  if (currentUser.role === "Schüler" || currentUser.role === "Lehrer") {
    return (
      <MemberDashboard
        currentUser={currentUser}
        books={books}
        loans={loans}
        members={members}
        onLogout={() => {
          setCurrentUser(null);
          localStorage.removeItem("library_current_user");
          triggerNotification("Erfolgreich abgemeldet.");
        }}
      />
    );
  }

  // 2.5. Superadmin Guard - if a Superadmin is logged in, show their centralized dashboard
  if (currentUser.role === "Superadmin") {
    return (
      <SuperadminDashboard
        currentUser={currentUser}
        onLogout={() => {
          setCurrentUser(null);
          localStorage.removeItem("library_current_user");
          triggerNotification("Erfolgreich abgemeldet.");
        }}
      />
    );
  }

  // 3. Admin View (currentUser.role === "Bücherei-Lehrer/in")
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-gray-800 selection:bg-indigo-100 selection:text-indigo-900">
      
      {/* Top Banner / Navigation Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            
            {/* Logo brand */}
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-xs">
                <Library className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <span className="block text-xs uppercase tracking-widest text-indigo-400 font-extrabold leading-none">
                  LesePortal
                </span>
                <h1 className="text-base font-bold text-white tracking-tight">
                  Bücherei & Ausleihe Manager
                </h1>
              </div>
            </div>

            {/* View navigation tabs */}
            <nav className="hidden md:flex space-x-1" aria-label="Tabs">
              <button
                onClick={() => { setActiveTab("dashboard"); consumeScannedPreset(); }}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === "dashboard" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-300 hover:text-white hover:bg-slate-800"
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Dashboard</span>
              </button>

              <button
                onClick={() => setActiveTab("books")}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === "books" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-300 hover:text-white hover:bg-slate-800"
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>Bücherbestand</span>
              </button>

              <button
                onClick={() => { setActiveTab("loans"); consumeScannedPreset(); }}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === "loans" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-300 hover:text-white hover:bg-slate-800"
                }`}
              >
                <RefreshCw className="w-4 h-4" />
                <span>Ausleihe & Fristen</span>
              </button>

              <button
                onClick={() => { setActiveTab("members"); consumeScannedPreset(); }}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === "members" ? "bg-indigo-600 text-white shadow-xs" : "text-slate-300 hover:text-white hover:bg-slate-800"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Karten / Mitglieder</span>
              </button>
            </nav>

            {/* Quick stats / online badge / Admin Logout */}
            <div className="flex items-center gap-3">
              <span className="hidden lg:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Live Cloud-Speicher aktiv
              </span>
              <div className="flex items-center gap-2 border-l border-slate-800 pl-3">
                <div className="text-right hidden lg:block">
                  <p className="text-xs font-bold text-slate-100 leading-none">{currentUser.name}</p>
                  <p className="text-[9px] text-indigo-400 font-medium mt-0.5">Bibliotheksaufsicht • Code: {currentUser.schoolCode || "DEMO123"}</p>
                </div>
                <button
                  onClick={() => {
                    setCurrentUser(null);
                    localStorage.removeItem("library_current_user");
                    triggerNotification("Erfolgreich abgemeldet.");
                  }}
                  className="p-2 bg-slate-800 hover:bg-red-950 border border-slate-700 hover:border-red-900 rounded-xl text-slate-300 hover:text-white transition-colors"
                  title="Abmelden"
                >
                  <LogOut className="w-4.5 h-4.5" />
                </button>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* Sub Header for Mobile Devices navigation */}
      <div className="md:hidden bg-slate-800 border-t border-slate-700 grid grid-cols-4 p-1 sticky top-16 z-30 shadow-xs">
        <button
          onClick={() => { setActiveTab("dashboard"); consumeScannedPreset(); }}
          className={`py-2 text-[10px] font-bold rounded-lg text-center flex flex-col items-center justify-center ${
            activeTab === "dashboard" ? "bg-indigo-600 text-white" : "text-slate-400"
          }`}
        >
          <LayoutDashboard className="w-4 h-4 mb-0.5" />
          Dashboard
        </button>
        <button
          onClick={() => setActiveTab("books")}
          className={`py-2 text-[10px] font-bold rounded-lg text-center flex flex-col items-center justify-center ${
            activeTab === "books" ? "bg-indigo-600 text-white" : "text-slate-400"
          }`}
        >
          <BookOpen className="w-4 h-4 mb-0.5" />
          Bestand
        </button>
        <button
          onClick={() => { setActiveTab("loans"); consumeScannedPreset(); }}
          className={`py-2 text-[10px] font-bold rounded-lg text-center flex flex-col items-center justify-center ${
            activeTab === "loans" ? "bg-indigo-600 text-white" : "text-slate-400"
          }`}
        >
          <RefreshCw className="w-4 h-4 mb-0.5" />
          Fristen
        </button>
        <button
          onClick={() => { setActiveTab("members"); consumeScannedPreset(); }}
          className={`py-2 text-[10px] font-bold rounded-lg text-center flex flex-col items-center justify-center ${
            activeTab === "members" ? "bg-indigo-600 text-white" : "text-slate-400"
          }`}
        >
          <Users className="w-4 h-4 mb-0.5" />
          Mitglieder
        </button>
      </div>

      {/* Notifications overlay system */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full mt-4 empty:hidden">
        {successMessage && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center gap-3 text-emerald-800 text-sm shadow-xs animate-slide-in">
            <Check className="w-5 h-5 text-emerald-600 shrink-0" />
            <p className="font-medium">{successMessage}</p>
          </div>
        )}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 flex items-center gap-3 text-red-800 text-sm shadow-xs">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
            <p className="font-medium">{error}</p>
          </div>
        )}
      </div>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-gray-600 font-semibold">Bücherei-Datenbank wird synchronisiert...</p>
            <span className="text-xs text-gray-400 mt-1">Lade Bestände, Karten und aktive Ausleihen</span>
          </div>
        ) : (
          <div>
            {/* View Switching */}
            {activeTab === "dashboard" && (
              <DashboardOverview
                books={books}
                loans={loans}
                members={members}
                currentUser={currentUser}
                openingHours={openingHours}
                onSaveOpeningHours={handleSaveOpeningHours}
                onReturnBook={handleReturnBook}
                onExtendBook={handleExtendBook}
                onNavigateToTab={(tab) => {
                  setActiveTab(tab);
                  consumeScannedPreset();
                }}
              />
            )}

            {activeTab === "books" && (
              <div>
                {/* Scanned injection block */}
                {scannedBookPreset && (
                  <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-4 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
                        <Sparkles className="w-5 h-5 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-bold text-indigo-900 text-sm">
                          Buchdaten durch Scannen eingelesen!
                        </h4>
                        <p className="text-xs text-indigo-700">
                          Wir haben Details zu <strong>"{scannedBookPreset.title}"</strong> gefunden. Drücke unten auf "Formular öffnen", um sie zu bestätigen oder anzupassen.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          // Handled via state consumption inside the components
                          consumeScannedPreset();
                        }}
                        className="px-3 py-1.5 text-xs text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors font-medium"
                      >
                        Verwerfen
                      </button>
                    </div>
                  </div>
                )}

                <BookCatalog
                  books={books}
                  onAddBook={handleAddBook}
                  onDeleteBook={handleDeleteBook}
                  onOpenScanner={() => setIsScannerOpen(true)}
                />

                {/* If scannedBookPreset exists, we can inject a quick custom renderer inside catalog to pre-fill */}
                {scannedBookPreset && (
                  <div className="bg-slate-100 p-6 rounded-2xl border border-gray-300 mt-6 shadow-inner animate-fade-in">
                    <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
                      <span>Bestätige/Bearbeite Scandaten für Katalogeintrag</span>
                    </h3>
                    <form
                      key={scannedBookPreset.isbn || "scanned-form"}
                      onSubmit={(e) => {
                        e.preventDefault();
                        const finalTitle = (e.currentTarget.elements.namedItem("title") as HTMLInputElement).value.trim();
                        const finalAuthor = (e.currentTarget.elements.namedItem("author") as HTMLInputElement).value.trim();
                        const finalIsbn = (e.currentTarget.elements.namedItem("isbn") as HTMLInputElement).value.trim();
                        const finalGenre = (e.currentTarget.elements.namedItem("genre") as HTMLInputElement).value.trim() || "Romane";
                        const finalPrice = parseFloat((e.currentTarget.elements.namedItem("price") as HTMLInputElement).value) || 14.99;
                        const finalPages = parseInt((e.currentTarget.elements.namedItem("pages") as HTMLInputElement).value, 10) || 160;
                        const finalDesc = (e.currentTarget.elements.namedItem("description") as HTMLTextAreaElement)?.value.trim() || "";
                        
                        if (!finalTitle) {
                          triggerNotification("Buchtitel ist erforderlich!", "error");
                          return;
                        }

                        const newBook: Book = {
                          id: finalIsbn || scannedBookPreset.isbn || `manual-${Date.now()}`,
                          isbn: finalIsbn || scannedBookPreset.isbn || "",
                          title: finalTitle,
                          author: finalAuthor || "Unbekannter Autor",
                          description: finalDesc,
                          genre: finalGenre,
                          price: finalPrice,
                          pages: finalPages,
                          status: "available",
                          borrowerId: null,
                          borrowerName: null,
                          dueDate: null,
                          createdAt: new Date().toISOString()
                        };
                        handleAddBook(newBook);
                        consumeScannedPreset();
                      }}
                      className="grid grid-cols-1 sm:grid-cols-4 gap-4"
                    >
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-medium text-gray-700 mb-1">Titel *</label>
                        <input
                          type="text"
                          name="title"
                          required
                          defaultValue={scannedBookPreset.title || ""}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          placeholder="Buchtitel eingeben"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-medium text-gray-700 mb-1">Autor</label>
                        <input
                          type="text"
                          name="author"
                          defaultValue={scannedBookPreset.author || ""}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          placeholder="Autor eingeben"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">ISBN / Schul-ISBN / Barcode</label>
                        <input
                          type="text"
                          name="isbn"
                          defaultValue={scannedBookPreset.isbn || ""}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          placeholder="z.B. 9783453148643 oder SCH-101"
                        />
                        <span className="text-[10px] text-gray-400 mt-1 block leading-tight">
                          Schulinterne Barcode-Nummern werden voll unterstützt.
                        </span>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Kategorie / Genre *</label>
                        <input
                          type="text"
                          name="genre"
                          required
                          defaultValue={scannedBookPreset.genre || "Romane"}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Seitenanzahl</label>
                        <input
                          type="number"
                          name="pages"
                          defaultValue={scannedBookPreset.pages || 160}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Anschaffungspreis (€) *</label>
                        <input
                          type="number"
                          step="0.01"
                          name="price"
                          required
                          defaultValue={scannedBookPreset.price || "14.99"}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        />
                      </div>
                      <div className="sm:col-span-4">
                        <label className="block text-xs font-medium text-gray-700 mb-1">Inhaltsangabe / Beschreibung</label>
                        <textarea
                          name="description"
                          rows={3}
                          defaultValue={scannedBookPreset.description || ""}
                          className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          placeholder="Kurze Zusammenfassung des Inhalts..."
                        />
                      </div>
                      <div className="sm:col-span-4 flex justify-end gap-2 mt-2">
                        <button
                          type="button"
                          onClick={consumeScannedPreset}
                          className="px-4 py-2 text-sm text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                          Abbrechen
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                        >
                          Katalogisieren & Hinzufügen
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </div>
            )}

            {activeTab === "loans" && (
              <BorrowReturn
                books={books}
                loans={loans}
                members={members}
                onBorrowBook={handleBorrowBook}
                onReturnBook={handleReturnBook}
                onExtendBook={handleExtendBook}
              />
            )}

            {activeTab === "members" && (
              <MemberManagement
                members={members}
                onAddMember={handleAddMember}
                onDeleteMember={handleDeleteMember}
              />
            )}
          </div>
        )}
      </main>

      {/* Embedded Camera / Barcode Scanner Dialog */}
      <ScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onBookDetected={handleBookDetected}
      />

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6 mt-12 text-center text-xs text-gray-400">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2026 LesePortal • Alle Rechte vorbehalten.</p>
          <p className="mt-1">
            Entwickelt für effizientes Bestandsmanagement mit scannbaren Code-39 Ausweisen und intelligentem AI-Lookup.
          </p>
        </div>
      </footer>

    </div>
  );
}
