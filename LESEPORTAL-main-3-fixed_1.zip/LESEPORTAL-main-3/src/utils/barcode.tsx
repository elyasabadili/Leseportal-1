import React from "react";

// Code 39 Barcode Map (bars and spaces)
// '1' indicates a bar or space depending on position, but we can simplify:
// A simpler robust binary pattern for bars. Each character is represented by 9 elements (5 bars, 4 spaces).
// 0 = narrow bar/space, 1 = wide bar/space.
// We map standard characters to their 9-character code 39 patterns.
// Element order: Bar, Space, Bar, Space, Bar, Space, Bar, Space, Bar
const CODE39_PATTERNS: Record<string, string> = {
  "0": "000110100", "1": "100100001", "2": "001100001", "3": "101100000",
  "4": "000110001", "5": "100110000", "6": "001110000", "7": "000100101",
  "8": "100100100", "9": "001100100", "A": "100001001", "B": "001001001",
  "C": "101001000", "D": "000011001", "E": "100011000", "F": "001011000",
  "G": "000001101", "H": "100001100", "I": "001001100", "J": "000011100",
  "K": "100000011", "L": "001000011", "M": "101000010", "N": "000010011",
  "O": "100010010", "P": "001010010", "Q": "000000111", "R": "100000110",
  "S": "001000110", "T": "000010110", "U": "110000001", "V": "011000001",
  "W": "111000000", "X": "010010001", "Y": "110010000", "Z": "011010000",
  "-": "010000101", ".": "110000100", " ": "011000100", "*": "010010100"
};

interface BarcodeProps {
  value: string;
  width?: number;
  height?: number;
  showText?: boolean;
}

export const Barcode: React.FC<BarcodeProps> = ({
  value,
  width = 2,
  height = 70,
  showText = true,
}) => {
  // Convert value to uppercase and sanitize
  const formattedValue = `*${value.toUpperCase().replace(/[^0-9A-Z-. ]/g, "")}*`;

  // Draw parameters
  const narrowWidth = width;
  const wideWidth = width * 2.5;
  const gapWidth = width; // Inter-character gap

  let x = 10; // Left margin
  const bars: React.ReactNode[] = [];

  for (let i = 0; i < formattedValue.length; i++) {
    const char = formattedValue[i];
    const pattern = CODE39_PATTERNS[char];

    if (!pattern) continue;

    // A character pattern has 9 elements: 5 bars, 4 spaces
    // e.g., "100100001"
    for (let j = 0; j < 9; j++) {
      const isBar = j % 2 === 0;
      const isWide = pattern[j] === "1";
      const elemWidth = isWide ? wideWidth : narrowWidth;

      if (isBar) {
        bars.push(
          <rect
            key={`${i}-${j}`}
            x={x}
            y={5}
            width={elemWidth}
            height={height}
            fill="#000000"
          />
        );
      }

      x += elemWidth;
    }

    // Inter-character gap
    x += gapWidth;
  }

  const svgWidth = x + 10;
  const svgHeight = height + (showText ? 25 : 10);

  return (
    <div className="flex flex-col items-center select-none bg-white p-2 rounded border border-gray-100">
      <svg
        width="100%"
        height={svgHeight}
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        preserveAspectRatio="xMidYMid meet"
        className="max-w-full"
      >
        <g>{bars}</g>
        {showText && (
          <text
            x={svgWidth / 2}
            y={height + 20}
            textAnchor="middle"
            fontFamily="monospace"
            fontSize="14"
            fontWeight="bold"
            fill="#1f2937"
            letterSpacing="2"
          >
            {value.toUpperCase()}
          </text>
        )}
      </svg>
    </div>
  );
};
