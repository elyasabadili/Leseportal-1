import React, { useState } from "react";
import { BookOpen, User, Calendar, RotateCcw, Plus, CheckCircle, Search, AlertCircle, Sparkles } from "lucide-react";
import { Book, Loan, Member } from "../types";

interface BorrowReturnProps {
  books: Book[];
  loans: Loan[];
  members: Member[];
  onBorrowBook: (loan: Loan) => void;
  onReturnBook: (loanId: string) => void;
  onExtendBook: (loanId: string, newDueDate: string) => void;
}

export const BorrowReturn: React.FC<BorrowReturnProps> = ({
  books,
  loans,
  members,
  onBorrowBook,
  onReturnBook,
  onExtendBook,
}) => {
  const [activeTab, setActiveTab] = useState<"issue" | "list">("issue");
  
  // Selection states for borrowing
  const [selectedBookId, setSelectedBookId] = useState("");
  const [selectedMemberId, setSelectedMemberId] = useState("");
  const [durationDays, setDurationDays] = useState("14");
  const [customDueDate, setCustomDueDate] = useState("");

  // Search/Filters for loans list
  const [loanSearchQuery, setLoanSearchQuery] = useState("");
  const [loanStatusFilter, setLoanStatusFilter] = useState("all");

  // Custom extension/deadline editor
  const [editingLoanId, setEditingLoanId] = useState<string | null>(null);
  const [newDeadline, setNewDeadline] = useState("");

  // Card Scanning State
  const [scannedId, setScannedId] = useState("");

  // Available books and registered members
  const availableBooks = books.filter((b) => b.status === "available");

  // Look up scanned member
  const scannedMember = members.find(
    (m) =>
      m.id.toLowerCase() === scannedId.trim().toLowerCase() ||
      (m.barcode && m.barcode.toLowerCase() === scannedId.trim().toLowerCase())
  );

  // Active loans for scanned member
  const memberActiveLoans = scannedMember
    ? loans.filter((l) => l.memberId === scannedMember.id && !l.returnDate)
    : [];

  // Active loans list for all members to track "sehen wer noch Bücher ausgeliehen hat"
  const activeLoansList = loans.filter((l) => !l.returnDate);
  const activeBorrowerIds = Array.from(new Set(activeLoansList.map((l) => l.memberId)));
  const activeBorrowers = activeBorrowerIds
    .map((memberId) => {
      const member = members.find((m) => m.id === memberId);
      const count = activeLoansList.filter((l) => l.memberId === memberId).length;
      return {
        id: memberId,
        name: member?.name || "Unbekanntes Mitglied",
        role: member?.role || "Schüler",
        classOrSubject: member?.classOrSubject || "",
        activeLoanCount: count,
      };
    })
    .sort((a, b) => b.activeLoanCount - a.activeLoanCount);

  // Handle changing selected member to auto-adjust standard duration (Lehrer = 28 Tage, Schüler = 14 Tage)
  const handleMemberChange = (memberId: string) => {
    setSelectedMemberId(memberId);
    const member = members.find((m) => m.id === memberId);
    if (member) {
      if (member.role === "Lehrer") {
        setDurationDays("28");
      } else {
        setDurationDays("14");
      }
    }
  };

  const handleIssueLoan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBookId || !selectedMemberId) return;

    const book = books.find((b) => b.id === selectedBookId);
    const member = members.find((m) => m.id === selectedMemberId);

    if (!book || !member) return;

    // Calculate due date
    let dueDateStr = "";
    if (durationDays === "custom" && customDueDate) {
      dueDateStr = customDueDate;
    } else {
      const days = parseInt(durationDays, 10) || 14;
      const today = new Date();
      today.setDate(today.getDate() + days);
      dueDateStr = today.toISOString().split("T")[0];
    }

    const newLoan: Loan = {
      id: `loan_${Date.now()}`,
      bookId: book.id,
      bookTitle: book.title,
      memberId: member.id,
      memberName: member.name,
      memberRole: member.role,
      loanDate: new Date().toISOString().split("T")[0],
      dueDate: dueDateStr,
      returnDate: null,
      extendedCount: 0,
      status: "active",
    };

    onBorrowBook(newLoan);
    
    // Reset states
    setSelectedBookId("");
    setSelectedMemberId("");
    setDurationDays("14");
    setCustomDueDate("");
    setActiveTab("list");
  };

  const handleExtendStandard = (loan: Loan) => {
    const current = new Date(loan.dueDate);
    current.setDate(current.getDate() + 14);
    const updatedStr = current.toISOString().split("T")[0];
    onExtendBook(loan.id, updatedStr);
  };

  const handleOpenExtendCustom = (loan: Loan) => {
    setEditingLoanId(loan.id);
    setNewDeadline(loan.dueDate);
  };

  const handleSaveCustomDeadline = () => {
    if (editingLoanId && newDeadline) {
      onExtendBook(editingLoanId, newDeadline);
      setEditingLoanId(null);
      setNewDeadline("");
    }
  };

  // Filter loans
  const filteredLoans = loans.filter((loan) => {
    const matchesSearch =
      loan.bookTitle.toLowerCase().includes(loanSearchQuery.toLowerCase()) ||
      loan.memberName.toLowerCase().includes(loanSearchQuery.toLowerCase()) ||
      loan.memberId.toLowerCase().includes(loanSearchQuery.toLowerCase());

    const isReturned = !!loan.returnDate;
    const isOverdue = !isReturned && loan.dueDate < "2026-06-24";

    let matchesStatus = true;
    if (loanStatusFilter === "active") {
      matchesStatus = !isReturned;
    } else if (loanStatusFilter === "overdue") {
      matchesStatus = isOverdue;
    } else if (loanStatusFilter === "returned") {
      matchesStatus = isReturned;
    }

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Ausleih- & Fristen-Schalter</h2>
          <p className="text-sm text-gray-500">
            Ausleihen für Schüler und Lehrer vornehmen, Fristen verlängern, ändern und Rückgaben verbuchen.
          </p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            onClick={() => setActiveTab("issue")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === "issue" ? "bg-white text-gray-900 shadow-xs" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            Buch ausleihen
          </button>
          <button
            onClick={() => setActiveTab("list")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === "list" ? "bg-white text-gray-900 shadow-xs" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            Vorgänge / Ausleihregister
          </button>
        </div>
      </div>

      {activeTab === "issue" ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Loan Creation Form - Left Column (Colspan 2) */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-200 shadow-xs p-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5 text-indigo-600" />
              <span>Neue Ausleihe buchen</span>
            </h3>

            <form onSubmit={handleIssueLoan} className="space-y-5">
              
              {/* Select Book */}
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  1. Buch auswählen (nur verfügbare) *
                </label>
                {availableBooks.length === 0 ? (
                  <p className="text-xs text-red-500 bg-red-50 p-2.5 rounded-lg border border-red-100">
                    Aktuell sind keine freien Bücher im Bestand. Registriere ein neues Buch oder verbuchen eine Rückgabe!
                  </p>
                ) : (
                  <select
                    required
                    value={selectedBookId}
                    onChange={(e) => setSelectedBookId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="">-- Buch auswählen --</option>
                    {availableBooks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title} (von {b.author}) — [{b.genre}]
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Select Member */}
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  2. Ausleiher auswählen (Schüler / Lehrperson) *
                </label>
                {members.length === 0 ? (
                  <p className="text-xs text-red-500 bg-red-50 p-2.5 rounded-lg border border-red-100">
                    Es gibt noch keine registrierten Mitglieder. Füge zuerst Schüler oder Lehrer hinzu!
                  </p>
                ) : (
                  <select
                    required
                    value={selectedMemberId}
                    onChange={(e) => handleMemberChange(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="">-- Mitglied auswählen --</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.role} • {m.classOrSubject})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Select Duration */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">
                    3. Leihfrist / Dauer
                  </label>
                  <select
                    value={durationDays}
                    onChange={(e) => setDurationDays(e.target.value)}
                    className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
                  >
                    <option value="14">14 Tage (Standard Schüler)</option>
                    <option value="28">28 Tage (Standard Lehrer)</option>
                    <option value="42">6 Wochen</option>
                    <option value="custom">Manuelles Datum festlegen...</option>
                  </select>
                </div>

                {durationDays === "custom" && (
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Rückgabedatum festlegen *
                    </label>
                    <input
                      type="date"
                      required
                      min="2026-06-24"
                      value={customDueDate}
                      onChange={(e) => setCustomDueDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
                    />
                  </div>
                )}
              </div>

              {/* Submit Action */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={!selectedBookId || !selectedMemberId}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl transition-all shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Ausleihe aktivieren
                </button>
              </div>

            </form>
          </div>

          {/* Interactive Card Scanner & Active Borrowers Center - Right Column */}
          <div className="space-y-6">
            
            {/* 1. CARD SCANNER WORKSPACE */}
            <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 p-6 shadow-md relative overflow-hidden">
              {/* Laser scanning visualization line */}
              <div className="absolute inset-x-0 top-0 h-0.5 bg-red-500 opacity-60 animate-bounce" />
              
              <h4 className="font-bold text-slate-100 text-sm mb-1.5 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                <span>Mitgliedsausweis scannen</span>
              </h4>
              <p className="text-slate-400 text-xs mb-4">
                Scanne den Ausweis-Barcode oder gib die ID manuell ein, um das Profil und ausgeliehene Bücher zu prüfen.
              </p>

              {/* Scan input field */}
              <div className="relative mb-4">
                <input
                  type="text"
                  placeholder="Ausweis scannen (z.B. S-10021)..."
                  value={scannedId}
                  onChange={(e) => setScannedId(e.target.value)}
                  className="w-full bg-slate-950 text-emerald-400 placeholder-slate-700 border border-slate-700 rounded-xl px-4 py-3 text-sm font-mono tracking-wider focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[9px] bg-slate-850 text-slate-300 px-2 py-1 rounded font-mono border border-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  BEREIT
                </div>
              </div>

              {/* Fast simulator buttons */}
              <div className="mb-4">
                <span className="block text-[10px] text-slate-500 font-semibold uppercase tracking-wider mb-2">
                  Schnell-Test (Ausweis-Scan simulieren):
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {members.slice(0, 4).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setScannedId(m.id)}
                      className={`px-2.5 py-1 text-[10px] font-semibold rounded border transition-colors ${
                        scannedId.trim().toLowerCase() === m.id.toLowerCase()
                          ? "bg-indigo-600 text-white border-indigo-500"
                          : "bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700 hover:text-white"
                      }`}
                    >
                      💳 {m.name.split(" ")[0]} ({m.role})
                    </button>
                  ))}
                </div>
              </div>

              {/* Scan result card */}
              {scannedMember ? (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3.5 animate-fade-in">
                  <div className="flex items-start justify-between border-b border-slate-800/80 pb-2.5">
                    <div>
                      <h5 className="font-bold text-slate-100 text-xs">{scannedMember.name}</h5>
                      <p className="text-[10px] text-slate-400 font-medium">
                        {scannedMember.role} &bull; {scannedMember.classOrSubject}
                      </p>
                    </div>
                    <span className="text-[10px] font-mono bg-slate-900 border border-slate-850 text-indigo-400 px-2 py-0.5 rounded">
                      {scannedMember.id}
                    </span>
                  </div>

                  {/* Active books list */}
                  <div>
                    <span className="block text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-2">
                      Aktuell entliehene Bücher:
                    </span>
                    {memberActiveLoans.length === 0 ? (
                      <div className="text-[11px] text-emerald-400 font-medium bg-emerald-950/20 px-3 py-2 rounded-lg border border-emerald-900/30">
                        Keine aktiven Ausleihen vorliegend.
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                        {memberActiveLoans.map((loan) => {
                          const isOverdue = loan.dueDate < "2026-06-24";
                          return (
                            <div key={loan.id} className="flex items-center justify-between text-[11px] bg-slate-900 border border-slate-800/80 p-2.5 rounded-lg">
                              <div className="flex flex-col min-w-0 pr-2">
                                <span className="font-semibold text-slate-200 truncate">{loan.bookTitle}</span>
                                <span className={`text-[9px] font-mono mt-0.5 ${isOverdue ? 'text-red-400 font-bold' : 'text-slate-400'}`}>
                                  Frist: {loan.dueDate.split("-").reverse().join(".")} {isOverdue ? '(ÜBERFÄLLIG)' : ''}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  onReturnBook(loan.id);
                                }}
                                className="shrink-0 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold rounded-md transition-colors"
                              >
                                Rückgabe
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Actions for borrow form filling */}
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedMemberId(scannedMember.id);
                        if (scannedMember.role === "Lehrer") {
                          setDurationDays("28");
                        } else {
                          setDurationDays("14");
                        }
                      }}
                      className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold rounded-lg transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-98"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Als Ausleiher übernehmen
                    </button>
                    <button
                      type="button"
                      onClick={() => setScannedId("")}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-[11px] rounded-lg transition-colors border border-slate-700"
                    >
                      Löschen
                    </button>
                  </div>
                </div>
              ) : (
                <div className="border border-dashed border-slate-800 rounded-xl p-6 text-center text-slate-500 flex flex-col items-center justify-center bg-slate-950/40">
                  <User className="w-8 h-8 stroke-1 text-slate-700 mb-2" />
                  <p className="text-[11px] font-medium leading-normal max-w-[200px]">
                    Scanne einen gedruckten Ausweis oder wähle oben einen Test-Ausweis zum Einlesen.
                  </p>
                </div>
              )}
            </div>

            {/* 2. OVERVIEW OF ACTIVE BORROWERS ("sehen wer noch Bücher ausgeliehen hat") */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-xs">
              <h4 className="font-semibold text-gray-950 text-sm mb-3 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                <span>Aktive Ausleiher im Überblick</span>
              </h4>
              
              {activeBorrowers.length === 0 ? (
                <p className="text-xs text-gray-400 italic bg-slate-50 border border-slate-100 p-3 rounded-xl text-center">
                  Aktuell hat niemand Bücher ausgeliehen.
                </p>
              ) : (
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {activeBorrowers.map((borrower) => (
                    <div key={borrower.id} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between text-xs hover:bg-slate-100/50 transition-colors">
                      <div className="min-w-0 pr-2">
                        <span className="font-bold text-gray-800 block truncate">{borrower.name}</span>
                        <span className="text-[10px] text-gray-400 block font-mono">
                          {borrower.role} ({borrower.classOrSubject})
                        </span>
                        <span className="text-[10px] text-indigo-600 font-semibold block mt-0.5">
                          {borrower.activeLoanCount} Buch/Bücher entliehen
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setScannedId(borrower.id)}
                        className="shrink-0 px-2 py-1 bg-white hover:bg-indigo-50 border border-gray-200 hover:border-indigo-200 text-[10px] font-bold text-indigo-600 rounded-md transition-colors shadow-2xs"
                      >
                        Details / Scan
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 3. RULES */}
            <div className="bg-slate-50 rounded-2xl border border-gray-200 p-5">
              <h4 className="font-semibold text-gray-900 text-xs mb-2.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                <span>Leihfristen</span>
              </h4>
              <ul className="text-[11px] text-gray-600 space-y-1.5 leading-relaxed">
                <li>&bull; <strong>Schüler</strong> erhalten standardmäßig <strong>14 Tage</strong>.</li>
                <li>&bull; <strong>Lehrer</strong> erhalten standardmäßig <strong>28 Tage</strong>.</li>
                <li>&bull; Verlängerungen sind flexibel möglich.</li>
              </ul>
            </div>
          </div>

        </div>
      ) : (
        <div className="space-y-6">
          
          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-white p-4 rounded-xl border border-gray-200">
            <div className="sm:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buch, Name oder ID suchen..."
                value={loanSearchQuery}
                onChange={(e) => setLoanSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none"
              />
            </div>
            <div>
              <select
                value={loanStatusFilter}
                onChange={(e) => setLoanStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none bg-white"
              >
                <option value="all">Alle Vorgänge</option>
                <option value="active">Nur Aktive (Ausgeliehen)</option>
                <option value="overdue">Nur Überfällige (Mahnwesen)</option>
                <option value="returned">Bereits Zurückgegeben</option>
              </select>
            </div>
          </div>

          {/* List Table */}
          <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-xs">
            {filteredLoans.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center text-gray-400">
                <RotateCcw className="w-16 h-16 stroke-1 mb-3" />
                <p className="text-base font-semibold">Keine Vorgänge im Filter gefunden</p>
                <p className="text-xs max-w-xs mt-1">Passe deine Suche an oder erstelle neue Ausleihen.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 bg-slate-50 text-xs text-gray-400 uppercase font-semibold">
                      <th className="px-6 py-4">Buch</th>
                      <th className="px-6 py-4">Mitglied</th>
                      <th className="px-6 py-4">Ausleih-Datum</th>
                      <th className="px-6 py-4">Frist / Rückgabe</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Aktionen</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredLoans.map((loan) => {
                      const isReturned = !!loan.returnDate;
                      const isOverdue = !isReturned && loan.dueDate < "2026-06-24";
                      const isEditing = editingLoanId === loan.id;

                      return (
                        <tr key={loan.id} className="hover:bg-slate-50/50 transition-colors">
                          
                          {/* Book info */}
                          <td className="px-6 py-4.5">
                            <div className="flex flex-col">
                              <span className="font-semibold text-gray-950">{loan.bookTitle}</span>
                              <span className="text-[11px] text-gray-400 font-mono">Buch ID: {loan.bookId}</span>
                            </div>
                          </td>

                          {/* Member info */}
                          <td className="px-6 py-4.5">
                            <div className="flex flex-col">
                              <span className="font-semibold text-xs text-gray-900">{loan.memberName}</span>
                              <span className="text-[10px] text-gray-400">
                                {loan.memberRole} • {loan.memberId}
                              </span>
                            </div>
                          </td>

                          {/* Loan Date */}
                          <td className="px-6 py-4.5 font-mono text-xs">
                            {loan.loanDate.split("-").reverse().join(".")}
                          </td>

                          {/* Due date / returned date */}
                          <td className="px-6 py-4.5">
                            {isReturned ? (
                              <div className="flex flex-col text-emerald-700">
                                <span className="text-xs font-semibold flex items-center gap-1">
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  Zurückgegeb.
                                </span>
                                <span className="text-[10px] font-mono mt-0.5">
                                  am {loan.returnDate?.split("-").reverse().join(".")}
                                </span>
                              </div>
                            ) : isEditing ? (
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="date"
                                  value={newDeadline}
                                  onChange={(e) => setNewDeadline(e.target.value)}
                                  className="px-2 py-1 border border-gray-300 rounded text-xs focus:outline-none"
                                />
                                <button
                                  onClick={handleSaveCustomDeadline}
                                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold rounded"
                                >
                                  OK
                                </button>
                                <button
                                  onClick={() => setEditingLoanId(null)}
                                  className="px-2 py-1 bg-gray-200 hover:bg-gray-300 text-gray-700 text-[11px] font-semibold rounded"
                                >
                                  X
                                </button>
                              </div>
                            ) : (
                              <div className="flex flex-col">
                                <span className="text-xs font-mono font-semibold text-gray-900">
                                  {loan.dueDate.split("-").reverse().join(".")}
                                </span>
                                {loan.extendedCount > 0 && (
                                  <span className="text-[9px] text-indigo-500 font-semibold mt-0.5">
                                    {loan.extendedCount}x verlängert
                                  </span>
                                )}
                              </div>
                            )}
                          </td>

                          {/* Status */}
                          <td className="px-6 py-4.5">
                            {isReturned ? (
                              <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                                Erledigt
                              </span>
                            ) : isOverdue ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-100 text-red-800 animate-pulse">
                                <AlertCircle className="w-3 h-3" />
                                Überfällig
                              </span>
                            ) : (
                              <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800">
                                Aktiv Leihfrist
                              </span>
                            )}
                          </td>

                          {/* Action panel */}
                          <td className="px-6 py-4.5 text-right whitespace-nowrap space-x-1">
                            {!isReturned && (
                              <>
                                <button
                                  onClick={() => handleExtendStandard(loan)}
                                  className="px-2 py-1 text-[11px] font-semibold text-indigo-600 hover:bg-indigo-50 border border-indigo-200 hover:border-indigo-300 rounded transition-colors"
                                  title="Schnelle Verlängerung um +14 Tage"
                                >
                                  Frist +14 Tage
                                </button>
                                <button
                                  onClick={() => handleOpenExtendCustom(loan)}
                                  className="px-2 py-1 text-[11px] font-semibold text-amber-700 hover:bg-amber-50 border border-amber-200 hover:border-amber-300 rounded transition-colors"
                                  title="Anderes individuelles Datum festlegen"
                                >
                                  Frist ändern
                                </button>
                                <button
                                  onClick={() => onReturnBook(loan.id)}
                                  className="px-2.5 py-1 text-[11px] font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded transition-colors shadow-xs"
                                >
                                  Zurückgeben
                                </button>
                              </>
                            )}
                          </td>

                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};
