import React, { useState, useEffect } from "react";
import {
  School,
  Users,
  Search,
  Plus,
  LogOut,
  AlertCircle,
  CheckCircle2,
  Shield,
  Filter,
  UserCheck,
  UserX,
  Lock,
  Unlock,
  Building,
  RefreshCw,
  Clock,
  BookOpen,
  Trash2
} from "lucide-react";
import { LibraryUser, School as SchoolType } from "../types";
import { LibraryDB } from "../services/db";

interface SuperadminDashboardProps {
  currentUser: LibraryUser;
  onLogout: () => void;
}

export default function SuperadminDashboard({
  currentUser,
  onLogout,
}: SuperadminDashboardProps) {
  // Database States
  const [schools, setSchools] = useState<SchoolType[]>([]);
  const [users, setUsers] = useState<LibraryUser[]>([]);
  const [loading, setLoading] = useState(true);

  // Form States for creating a School
  const [newSchoolCode, setNewSchoolCode] = useState("");
  const [newSchoolName, setNewSchoolName] = useState("");

  // Filters & Search States
  const [userSearch, setUserSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("ALL");
  const [schoolFilter, setSchoolFilter] = useState<string>("ALL");

  // Notifications
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Confirmation for Deletions
  const [deleteSchoolConfirmId, setDeleteSchoolConfirmId] = useState<string | null>(null);
  const [deleteUserConfirmId, setDeleteUserConfirmId] = useState<string | null>(null);

  // Load database arrays
  const loadData = async () => {
    setLoading(true);
    try {
      const fetchedSchools = await LibraryDB.getSchools();
      const fetchedUsers = await LibraryDB.getUsers();
      setSchools(fetchedSchools);
      setUsers(fetchedUsers);
    } catch (err) {
      showError("Daten konnten nicht geladen werden.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(null), 4000);
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  // Create a new School
  const handleCreateSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    const codeClean = newSchoolCode.trim().toUpperCase();
    const nameClean = newSchoolName.trim();

    if (!codeClean || !nameClean) {
      showError("Bitte füllen Sie beide Felder aus!");
      return;
    }

    if (codeClean === "SYSTEM") {
      showError("Der Code 'SYSTEM' ist für globale Zwecke reserviert.");
      return;
    }

    // Check duplicate
    if (schools.some((s) => s.id === codeClean)) {
      showError(`Eine Schule mit dem Code "${codeClean}" existiert bereits.`);
      return;
    }

    try {
      const newSchool: SchoolType = {
        id: codeClean,
        name: nameClean,
        isActive: true,
        createdAt: new Date().toISOString(),
      };

      await LibraryDB.saveSchool(newSchool);
      setNewSchoolCode("");
      setNewSchoolName("");
      showSuccess(`Schule "${nameClean}" (Code: ${codeClean}) erfolgreich registriert!`);
      await loadData();
    } catch (err) {
      showError("Fehler beim Speichern der Schule.");
    }
  };

  // Toggle School active/paused state
  const handleToggleSchoolStatus = async (school: SchoolType) => {
    try {
      const updatedSchool: SchoolType = {
        ...school,
        isActive: !school.isActive,
      };
      await LibraryDB.saveSchool(updatedSchool);
      showSuccess(
        `Schulcode "${school.id}" wurde erfolgreich ${
          updatedSchool.isActive ? "aktiviert" : "pausiert"
        }!`
      );
      await loadData();
    } catch (err) {
      showError("Fehler beim Ändern des Schul-Status.");
    }
  };

  // Toggle User active/paused state
  const handleToggleUserStatus = async (user: LibraryUser) => {
    if (user.role === "Superadmin") {
      showError("Superadmin-Konten können nicht pausiert werden!");
      return;
    }

    try {
      const updatedUser: LibraryUser = {
        ...user,
        isActive: user.isActive === false ? true : false,
      };
      await LibraryDB.saveUser(updatedUser);
      showSuccess(
        `Konto von "${user.name}" wurde erfolgreich ${
          updatedUser.isActive ? "aktiviert" : "pausiert"
        }!`
      );
      await loadData();
    } catch (err) {
      showError("Fehler beim Ändern des Benutzer-Status.");
    }
  };

  // Delete School
  const handleDeleteSchool = async (schoolId: string) => {
    try {
      await LibraryDB.deleteSchool(schoolId);
      showSuccess(`Schule mit Code "${schoolId}" wurde erfolgreich gelöscht.`);
      setDeleteSchoolConfirmId(null);
      await loadData();
    } catch (err) {
      showError("Fehler beim Löschen der Schule.");
    }
  };

  // Delete User
  const handleDeleteUser = async (user: LibraryUser) => {
    if (user.role === "Superadmin") {
      showError("Superadmin-Konten können nicht gelöscht werden!");
      return;
    }

    try {
      await LibraryDB.deleteUser(user.id);
      showSuccess(`Benutzerkonto von "${user.name}" wurde erfolgreich gelöscht.`);
      setDeleteUserConfirmId(null);
      await loadData();
    } catch (err) {
      showError("Fehler beim Löschen des Benutzers.");
    }
  };

  // Stats Counters
  const activeSchoolsCount = schools.filter((s) => s.isActive).length;
  const pausedSchoolsCount = schools.filter((s) => !s.isActive).length;

  const totalStudents = users.filter((u) => u.role === "Schüler").length;
  const totalTeachers = users.filter((u) => u.role === "Lehrer").length;
  const totalSchoolAdmins = users.filter((u) => u.role === "Bücherei-Lehrer/in").length;

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    // Exclude self (the active Superadmin) to keep the list clean, or show everything
    const matchesSearch =
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.schoolCode.toLowerCase().includes(userSearch.toLowerCase());

    const matchesRole = roleFilter === "ALL" || u.role === roleFilter;
    const matchesSchool = schoolFilter === "ALL" || u.schoolCode === schoolFilter;

    return matchesSearch && matchesRole && matchesSchool;
  });

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header className="bg-slate-950 border-b border-slate-800 py-4 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 rounded-xl text-white shadow-md shadow-indigo-600/20">
              <Shield className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="block text-[10px] uppercase tracking-widest text-indigo-400 font-extrabold leading-none">
                LesePortal Central
              </span>
              <h1 className="text-base font-black text-white tracking-tight">
                Superadmin Dashboard
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-100">{currentUser.name}</p>
              <span className="inline-flex items-center gap-1 text-[9px] px-2 py-0.5 rounded-full bg-red-500/20 border border-red-500/30 text-red-400 font-semibold uppercase tracking-wider mt-0.5">
                👑 Global Superadmin
              </span>
            </div>

            <button
              onClick={onLogout}
              className="px-3.5 py-2 bg-slate-800 hover:bg-red-950 border border-slate-700 hover:border-red-900 rounded-xl text-slate-300 hover:text-white transition-all text-xs font-bold flex items-center gap-1.5"
            >
              <LogOut className="w-4 h-4" />
              <span>Abmelden</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full space-y-8">
        {/* Messages */}
        <div className="empty:hidden space-y-3">
          {errorMsg && (
            <div className="bg-red-900/40 border border-red-800 rounded-2xl p-4 flex items-start gap-3 text-red-200 text-sm shadow-xl">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Aktion fehlgeschlagen</p>
                <p className="text-xs text-red-300/90 mt-0.5">{errorMsg}</p>
              </div>
            </div>
          )}
          {successMsg && (
            <div className="bg-emerald-950/40 border border-emerald-800 rounded-2xl p-4 flex items-start gap-3 text-emerald-200 text-sm shadow-xl">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Erfolgreich</p>
                <p className="text-xs text-emerald-300/90 mt-0.5">{successMsg}</p>
              </div>
            </div>
          )}
        </div>

        {/* Global Stats Overview */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-slate-950/50 border border-slate-800 p-4.5 rounded-2xl flex items-center gap-4 hover:border-slate-700 transition-colors">
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Schulen Gesamt</span>
              <span className="text-xl font-black text-white">{schools.length}</span>
              <span className="text-[9px] text-slate-400 block mt-0.5">({activeSchoolsCount} aktiv, {pausedSchoolsCount} pausiert)</span>
            </div>
          </div>

          <div className="bg-slate-950/50 border border-slate-800 p-4.5 rounded-2xl flex items-center gap-4 hover:border-slate-700 transition-colors">
            <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Benutzer Gesamt</span>
              <span className="text-xl font-black text-white">{users.length}</span>
              <span className="text-[9px] text-slate-400 block mt-0.5">inklusive Superadmin</span>
            </div>
          </div>

          <div className="bg-slate-950/50 border border-slate-800 p-4.5 rounded-2xl flex items-center gap-4 hover:border-slate-700 transition-colors">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Schul-Admins</span>
              <span className="text-xl font-black text-white">{totalSchoolAdmins}</span>
              <span className="text-[9px] text-slate-400 block mt-0.5">Bücherei-Lehrer/innen</span>
            </div>
          </div>

          <div className="bg-slate-950/50 border border-slate-800 p-4.5 rounded-2xl flex items-center gap-4 hover:border-slate-700 transition-colors">
            <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Schüler</span>
              <span className="text-xl font-black text-white">{totalStudents}</span>
              <span className="text-[9px] text-slate-400 block mt-0.5">Selbstausleiher registriert</span>
            </div>
          </div>

          <div className="bg-slate-950/50 border border-slate-800 p-4.5 rounded-2xl col-span-2 lg:col-span-1 flex items-center gap-4 hover:border-slate-700 transition-colors">
            <div className="p-3 bg-teal-500/10 border border-teal-500/20 text-teal-400 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Lehrer</span>
              <span className="text-xl font-black text-white">{totalTeachers}</span>
              <span className="text-[9px] text-slate-400 block mt-0.5">Kollegiumskarten aktiv</span>
            </div>
          </div>
        </div>

        {/* Section: Schools Code Management */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Create Code Form */}
          <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-6 h-fit space-y-6">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-500" />
                Schulcode registrieren
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Erstellen Sie einen eindeutigen Code, um eine neue Schule für das LesePortal freizugeben.
              </p>
            </div>

            <form onSubmit={handleCreateSchool} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Eindeutiger Schulcode (z.B. GOETHE-2026)
                </label>
                <input
                  type="text"
                  required
                  value={newSchoolCode}
                  onChange={(e) => setNewSchoolCode(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-slate-800 text-white font-mono uppercase tracking-wider placeholder:text-slate-600"
                  placeholder="z.B. GYM-MÜNCHEN"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Name der Schule
                </label>
                <input
                  type="text"
                  required
                  value={newSchoolName}
                  onChange={(e) => setNewSchoolName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-slate-800 text-white placeholder:text-slate-600"
                  placeholder="z.B. Städtisches Goethe-Gymnasium"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-xs font-bold text-white transition-all shadow-md shadow-indigo-600/10 flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Registrieren & Freigeben</span>
              </button>
            </form>
          </div>

          {/* List of Schools */}
          <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-6 lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <School className="w-5 h-5 text-indigo-500" />
                  Registrierte Schulcodes ({schools.length})
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Pausierte Schulcodes verwehren allen Benutzern dieser Schule den Zugang.
                </p>
              </div>

              <button
                onClick={loadData}
                className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
                title="Aktualisieren"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-bold">
                    <th className="pb-3 pr-2">Schulcode</th>
                    <th className="pb-3 pr-2">Name der Schule</th>
                    <th className="pb-3 pr-2">Erstellt am</th>
                    <th className="pb-3 pr-2 text-center">Status</th>
                    <th className="pb-3 text-right">Aktion</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {schools.map((school) => (
                    <tr key={school.id} className="hover:bg-slate-800/20 transition-colors">
                      <td className="py-3.5 pr-2 font-mono font-bold text-indigo-400 uppercase tracking-wider">
                        {school.id}
                      </td>
                      <td className="py-3.5 pr-2 font-medium text-white">
                        {school.name}
                      </td>
                      <td className="py-3.5 pr-2 text-slate-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 shrink-0 text-slate-600" />
                        <span>{new Date(school.createdAt).toLocaleDateString("de-DE")}</span>
                      </td>
                      <td className="py-3.5 pr-2 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            school.isActive
                              ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20"
                              : "bg-red-500/15 text-red-400 border border-red-500/20"
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${school.isActive ? "bg-emerald-400 animate-pulse" : "bg-red-400"}`} />
                          {school.isActive ? "Aktiviert" : "Pausiert"}
                        </span>
                      </td>
                      <td className="py-3.5 text-right flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleToggleSchoolStatus(school)}
                          className={`px-3 py-1.5 rounded-xl text-[10px] font-bold transition-all inline-flex items-center gap-1.5 ${
                            school.isActive
                              ? "bg-amber-500/10 hover:bg-amber-500/25 border border-amber-500/20 hover:border-amber-500/40 text-amber-400"
                              : "bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/20 hover:border-emerald-500/40 text-emerald-400"
                          }`}
                        >
                          {school.isActive ? (
                            <>
                              <Lock className="w-3.5 h-3.5" />
                              <span>Pausieren</span>
                            </>
                          ) : (
                            <>
                              <Unlock className="w-3.5 h-3.5" />
                              <span>Reaktivieren</span>
                            </>
                          )}
                        </button>

                        {deleteSchoolConfirmId === school.id ? (
                          <div className="inline-flex items-center gap-1 bg-red-950/80 border border-red-800 px-2 py-1 rounded-xl">
                            <span className="text-[9px] text-red-300 font-bold mr-1">Löschen?</span>
                            <button
                              onClick={() => handleDeleteSchool(school.id)}
                              className="px-2 py-0.5 bg-red-600 hover:bg-red-500 text-white rounded text-[9px] font-bold"
                            >
                              Ja
                            </button>
                            <button
                              onClick={() => setDeleteSchoolConfirmId(null)}
                              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded text-[9px] font-bold"
                            >
                              Nein
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteSchoolConfirmId(school.id)}
                            className="p-1.5 bg-red-500/10 hover:bg-red-500/25 border border-red-500/20 hover:border-red-500/40 text-red-400 rounded-xl transition-all"
                            title="Schule löschen"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Section: Users Management across all schools */}
        <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-500" />
                Benutzerkonten verwalten & kontrollieren ({filteredUsers.length})
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Sichten Sie alle Schüler, Lehrer und Administratoren. Pausieren Sie Konten bei Verstößen oder Bedarf.
              </p>
            </div>

            {/* User filters */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Search */}
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Suche Name, Schule..."
                  className="pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-600 focus:border-indigo-600 w-44 transition-all"
                />
              </div>

              {/* Role filter */}
              <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-xl text-xs text-slate-300">
                <Filter className="w-3.5 h-3.5 text-slate-500" />
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="bg-transparent border-none text-xs focus:outline-none text-slate-200 font-medium"
                >
                  <option value="ALL" className="bg-slate-950 text-slate-200">Alle Rollen</option>
                  <option value="Bücherei-Lehrer/in" className="bg-slate-950 text-slate-200">Bücherei-Admins</option>
                  <option value="Lehrer" className="bg-slate-950 text-slate-200">Lehrer</option>
                  <option value="Schüler" className="bg-slate-950 text-slate-200">Schüler</option>
                  <option value="Superadmin" className="bg-slate-950 text-slate-200">Superadmins</option>
                </select>
              </div>

              {/* School filter */}
              <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-xl text-xs text-slate-300">
                <School className="w-3.5 h-3.5 text-slate-500" />
                <select
                  value={schoolFilter}
                  onChange={(e) => setSchoolFilter(e.target.value)}
                  className="bg-transparent border-none text-xs focus:outline-none text-slate-200 font-medium max-w-[120px]"
                >
                  <option value="ALL" className="bg-slate-950 text-slate-200">Alle Schulen</option>
                  <option value="SYSTEM" className="bg-slate-950 text-slate-200">SYSTEM</option>
                  {schools.map((s) => (
                    <option key={s.id} value={s.id} className="bg-slate-950 text-slate-200">
                      {s.id}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-bold">
                  <th className="pb-3 pr-2">Benutzername</th>
                  <th className="pb-3 pr-2">Name</th>
                  <th className="pb-3 pr-2">Schule / Code</th>
                  <th className="pb-3 pr-2">Rolle & Klasse/Fach</th>
                  <th className="pb-3 pr-2">Mitgliedskarte</th>
                  <th className="pb-3 pr-2 text-center">Status</th>
                  <th className="pb-3 text-right">Sperren / Freigeben</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-800/20 transition-colors">
                    <td className="py-3.5 pr-2 font-mono text-slate-300">
                      @{user.username}
                    </td>
                    <td className="py-3.5 pr-2 font-bold text-white">
                      {user.name}
                    </td>
                    <td className="py-3.5 pr-2">
                      <span className="font-mono text-xs font-bold text-indigo-400 uppercase tracking-wide bg-indigo-500/5 border border-indigo-500/10 px-2 py-0.5 rounded-md">
                        {user.schoolCode}
                      </span>
                    </td>
                    <td className="py-3.5 pr-2 space-y-0.5">
                      <div className="font-semibold text-slate-200">{user.role}</div>
                      <div className="text-[10px] text-slate-400">{user.classOrSubject}</div>
                    </td>
                    <td className="py-3.5 pr-2 font-mono text-slate-400">
                      {user.memberId || <span className="text-slate-600">—</span>}
                    </td>
                    <td className="py-3.5 pr-2 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          user.isActive !== false
                            ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20"
                            : "bg-red-500/15 text-red-400 border border-red-500/20"
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${user.isActive !== false ? "bg-emerald-400" : "bg-red-400"}`} />
                        {user.isActive !== false ? "Aktiv" : "Pausiert"}
                      </span>
                    </td>
                    <td className="py-3.5 text-right flex items-center justify-end gap-2">
                      {user.role === "Superadmin" ? (
                        <span className="text-[10px] text-slate-600 font-bold italic pr-3">System-Konto</span>
                      ) : (
                        <>
                          <button
                            onClick={() => handleToggleUserStatus(user)}
                            className={`px-3 py-1.5 rounded-xl text-[10px] font-bold transition-all inline-flex items-center gap-1.5 ${
                              user.isActive !== false
                                ? "bg-red-500/10 hover:bg-red-500/25 border border-red-500/20 hover:border-red-500/40 text-red-400"
                                : "bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/20 hover:border-emerald-500/40 text-emerald-400"
                            }`}
                          >
                            {user.isActive !== false ? (
                              <>
                                <UserX className="w-3.5 h-3.5" />
                                <span>Pausieren</span>
                              </>
                            ) : (
                              <>
                                <UserCheck className="w-3.5 h-3.5" />
                                <span>Aktivieren</span>
                              </>
                            )}
                          </button>

                          {deleteUserConfirmId === user.id ? (
                            <div className="inline-flex items-center gap-1 bg-red-950/80 border border-red-800 px-2 py-1 rounded-xl">
                              <span className="text-[9px] text-red-300 font-bold mr-1">Löschen?</span>
                              <button
                                onClick={() => handleDeleteUser(user)}
                                className="px-2 py-0.5 bg-red-600 hover:bg-red-500 text-white rounded text-[9px] font-bold"
                              >
                                Ja
                              </button>
                              <button
                                onClick={() => setDeleteUserConfirmId(null)}
                                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded text-[9px] font-bold"
                              >
                                Nein
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteUserConfirmId(user.id)}
                              className="p-1.5 bg-red-500/10 hover:bg-red-500/25 border border-red-500/20 hover:border-red-500/40 text-red-400 rounded-xl transition-all"
                              title="Benutzer löschen"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}

                {filteredUsers.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500 text-xs">
                      Keine passenden Benutzerkonten gefunden.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 py-6 text-center text-xs text-slate-500 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 LesePortal Central • Superadmin Panel.</p>
          <div className="flex items-center gap-1.5 text-[10px] text-slate-600">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Multi-School Security Engine active</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
