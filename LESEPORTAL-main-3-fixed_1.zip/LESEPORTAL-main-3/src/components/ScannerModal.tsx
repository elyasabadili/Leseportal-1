import React, { useState, useEffect, useRef } from "react";
import { X, Camera, Sparkles, BookOpen, AlertCircle, Check } from "lucide-react";
import { Book } from "../types";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBookDetected: (bookData: Partial<Book>) => void;
}

// Popular sample books that can be "scanned" instantly for demo convenience
const DEMO_BARCODES = [
  { code: "9783551551672", title: "Harry Potter und der Stein der Weisen", author: "J.K. Rowling" },
  { code: "9783446150638", title: "Die unendliche Geschichte", author: "Michael Ende" },
  { code: "9783462025972", title: "Der Vorleser", author: "Bernhard Schlink" },
  { code: "9783423124430", title: "Sofies Welt", author: "Jostein Gaarder" },
  { code: "9783596219179", title: "Die Physiker", author: "Friedrich Dürrenmatt" },
];

export const ScannerModal: React.FC<ScannerModalProps> = ({
  isOpen,
  onClose,
  onBookDetected,
}) => {
  const [activeTab, setActiveTab] = useState<"camera" | "input">("camera");
  const [manualQuery, setManualQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);

  // Clean up states when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setManualQuery("");
      setError(null);
      setSuccessMsg(null);
      setLoading(false);
      setCameraError(null);
    }
  }, [isOpen]);

  const handleLookup = async (queryStr: string) => {
    if (!queryStr.trim()) return;
    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await fetch("/api/book-lookup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: queryStr }),
      });

      if (!res.ok) {
        throw new Error("Konnte Buchdaten nicht abrufen");
      }

      const bookData = await res.json();
      if (bookData.error) {
        throw new Error(bookData.error);
      }

      setSuccessMsg(`Gefunden: "${bookData.title}" von ${bookData.author}`);
      
      // Short delay to show success before returning
      setTimeout(() => {
        onBookDetected(bookData);
        onClose();
      }, 1500);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Fehler beim Nachschlagen des Buches. Bitte manuell eingeben.");
    } finally {
      setLoading(false);
    }
  };

  const simulateCameraScan = (code: string) => {
    setLoading(true);
    // Simulate scanner sound beep and delay
    setTimeout(() => {
      handleLookup(code);
    }, 1000);
  };

  // Start / stop real camera scanner using html5-qrcode
  useEffect(() => {
    let isActive = true;

    if (isOpen && activeTab === "camera") {
      setCameraError(null);
      setIsScanning(false);

      const startScanner = async () => {
        // Wait briefly for DOM to render the container div
        await new Promise((resolve) => setTimeout(resolve, 350));
        if (!isActive) return;

        const container = document.getElementById("camera-scanner-view");
        if (!container) return;

        try {
          // Initialize scanner with barcode support configuration
          const scannerInstance = new Html5Qrcode("camera-scanner-view", {
            formatsToSupport: [
              Html5QrcodeSupportedFormats.EAN_13,
              Html5QrcodeSupportedFormats.EAN_8,
              Html5QrcodeSupportedFormats.CODE_128,
              Html5QrcodeSupportedFormats.CODE_39,
              Html5QrcodeSupportedFormats.UPC_A,
              Html5QrcodeSupportedFormats.UPC_E,
              Html5QrcodeSupportedFormats.QR_CODE
            ],
            useBarCodeDetectorIfSupported: true,
            verbose: false
          });

          if (!isActive) {
            try {
              scannerInstance.clear();
            } catch (e) {}
            return;
          }

          scannerRef.current = scannerInstance;
          setIsScanning(true);

          const onScanSuccess = (decodedText: string) => {
            console.log("Barcode scanned successfully:", decodedText);
            // Trigger lookup
            handleLookup(decodedText);
            
            // Stop scanning on success
            if (scannerInstance && scannerInstance.isScanning) {
              scannerInstance.stop()
                .then(() => {
                  try {
                    scannerInstance.clear();
                  } catch (e) {}
                })
                .catch((e) => console.error("Error stopping scanner:", e));
              setIsScanning(false);
            }
          };

          const onScanFailure = () => {
            // Ignore continuous scan failure noise
          };

          // Try environment camera first, fall back to user camera, then fall back to default
          try {
            await scannerInstance.start(
              { facingMode: "environment" },
              {
                fps: 15,
                qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
                  // Barcodes are wide and short. Take 85% width and 45% height.
                  const width = Math.floor(viewfinderWidth * 0.85);
                  const height = Math.floor(viewfinderHeight * 0.45);
                  return { width, height };
                },
              },
              onScanSuccess,
              onScanFailure
            );
          } catch (firstErr) {
            console.log("FacingMode environment failed, trying facingMode user...", firstErr);
            if (!isActive) return;

            try {
              await scannerInstance.start(
                { facingMode: "user" },
                {
                  fps: 15,
                  qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
                    const width = Math.floor(viewfinderWidth * 0.85);
                    const height = Math.floor(viewfinderHeight * 0.45);
                    return { width, height };
                  },
                },
                onScanSuccess,
                onScanFailure
              );
            } catch (secondErr) {
              console.log("FacingMode user failed, trying any available camera...", secondErr);
              if (!isActive) return;

              await scannerInstance.start(
                {}, // empty constraints defaults to first available
                {
                  fps: 15,
                  qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
                    const width = Math.floor(viewfinderWidth * 0.85);
                    const height = Math.floor(viewfinderHeight * 0.45);
                    return { width, height };
                  },
                },
                onScanSuccess,
                onScanFailure
              );
            }
          }
        } catch (err: any) {
          console.error("Failed to start camera scanner:", err);
          if (isActive) {
            setCameraError(
              "Kamera-Zugriff fehlgeschlagen oder nicht erlaubt. Nutze den Suchen-Tab oder klicke unten auf eine Schnell-Vorlage."
            );
            setIsScanning(false);
          }
        }
      };

      startScanner();
    }

    return () => {
      isActive = false;
      const scannerInstance = scannerRef.current;
      if (scannerInstance) {
        if (scannerInstance.isScanning) {
          scannerInstance.stop()
            .then(() => {
              try {
                scannerInstance.clear();
              } catch (e) {}
            })
            .catch((e) => console.error("Error stopping scanner on cleanup:", e));
        } else {
          try {
            scannerInstance.clear();
          } catch (e) {
            // Ignore clear errors if it wasn't running
          }
        }
        scannerRef.current = null;
      }
      setIsScanning(false);
    };
  }, [isOpen, activeTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      {/* Inject custom CSS to make video feed fit nicely in the rounded preview container */}
      {/* Inject custom CSS to make video feed fit nicely in the rounded preview container */}
      <style dangerouslySetInnerHTML={{ __html: `
        #camera-scanner-view video {
          width: 100% !important;
          height: 100% !important;
          object-fit: contain !important;
          background-color: #020617 !important;
          border-radius: 12px;
        }
      `}} />

      <div className="w-full max-w-xl bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-950">Buch scannen / hinzufügen</h3>
              <p className="text-xs text-gray-500">ISBN-Barcode scannen oder nachschlagen</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 text-gray-500 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-gray-100 bg-slate-50/50">
          <button
            onClick={() => setActiveTab("camera")}
            className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "camera"
                ? "border-indigo-600 text-indigo-600 bg-white"
                : "border-transparent text-gray-500 hover:text-gray-900"
            }`}
          >
            Echter Kamera-Scanner
          </button>
          <button
            onClick={() => setActiveTab("input")}
            className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "input"
                ? "border-indigo-600 text-indigo-600 bg-white"
                : "border-transparent text-gray-500 hover:text-gray-900"
            }`}
          >
            ISBN / Titel Suche (AI)
          </button>
        </div>

        {/* Content area */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === "camera" ? (
            <div className="flex flex-col items-center">
              {/* Scan Stage Graphic with live video stream */}
              <div className="relative w-full h-56 bg-slate-950 rounded-xl overflow-hidden flex flex-col items-center justify-center text-white mb-6 border border-slate-800 shadow-inner">
                {/* Real HTML5 camera preview mount point */}
                {activeTab === "camera" && (
                  <div id="camera-scanner-view" className="absolute inset-0 w-full h-full z-0 bg-black" />
                )}

                {/* Laser animation overlay */}
                {isScanning && !loading && !successMsg && !cameraError && (
                  <div className="absolute inset-x-0 top-1/2 h-0.5 bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.9)] animate-bounce z-10 pointer-events-none" />
                )}

                {/* Status messages over the camera feed */}
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 bg-black/40 z-10 pointer-events-none text-center">
                  {cameraError ? (
                    <div className="flex flex-col items-center gap-2 text-rose-400 max-w-xs px-2">
                      <AlertCircle className="w-8 h-8 shrink-0" />
                      <p className="text-xs font-medium leading-relaxed">{cameraError}</p>
                    </div>
                  ) : loading ? (
                    <div className="flex flex-col items-center gap-3 bg-slate-900/95 py-3.5 px-6 rounded-xl border border-slate-700/50 backdrop-blur-md">
                      <div className="w-8 h-8 border-3 border-indigo-400 border-t-transparent rounded-full animate-spin" />
                      <div>
                        <p className="text-xs font-semibold text-slate-200">Datenbankabfrage...</p>
                        <span className="text-[10px] text-slate-400">Google Books & Gemini suchen Buchdaten</span>
                      </div>
                    </div>
                  ) : successMsg ? (
                    <div className="flex flex-col items-center gap-2 bg-slate-900/95 py-4 px-6 rounded-xl border border-emerald-500/30 backdrop-blur-md text-emerald-400">
                      <div className="p-2 bg-emerald-500/10 rounded-full">
                        <Check className="w-6 h-6 animate-pulse" />
                      </div>
                      <p className="font-semibold text-xs text-white">{successMsg}</p>
                      <p className="text-[10px] text-emerald-400/80">Wird eingetragen...</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-slate-300 drop-shadow-md">
                      <BookOpen className="w-7 h-7 text-indigo-400 animate-pulse" />
                      <p className="text-[10px] font-mono tracking-wider text-indigo-300 uppercase font-bold">Kamera-Scanner aktiv</p>
                      <p className="text-[11px] text-slate-300 max-w-xs">
                        Bringe den Barcode (EAN/ISBN) auf der Buchrückseite direkt vor die Kamera.
                      </p>
                    </div>
                  )}
                </div>

                {/* Scanner Target Area Corner Markers */}
                {!cameraError && !loading && !successMsg && (
                  <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
                    <div className="w-[280px] h-[120px] relative border border-white/20 rounded-md">
                      {/* Corner markers */}
                      <div className="absolute -top-1 -left-1 w-4 h-4 border-t-3 border-l-3 border-indigo-500" />
                      <div className="absolute -top-1 -right-1 w-4 h-4 border-t-3 border-r-3 border-indigo-500" />
                      <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-3 border-l-3 border-indigo-500" />
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-3 border-r-3 border-indigo-500" />
                    </div>
                  </div>
                )}
              </div>

              {/* Demo Scan Targets */}
              <div className="w-full">
                <div className="flex items-center gap-1.5 mb-3">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wider">Schnell-Test (Buch scannen simulieren):</h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {DEMO_BARCODES.map((item) => (
                    <button
                      key={item.code}
                      disabled={loading || !!successMsg}
                      onClick={() => simulateCameraScan(item.code)}
                      className="text-left p-2.5 bg-slate-50 hover:bg-indigo-50 border border-gray-100 hover:border-indigo-100 rounded-lg text-xs transition-all flex flex-col justify-between group active:scale-98 disabled:opacity-50"
                    >
                      <span className="font-semibold text-gray-800 group-hover:text-indigo-900 truncate max-w-full">
                        {item.title}
                      </span>
                      <div className="flex justify-between items-center text-gray-500 mt-1">
                        <span>{item.author}</span>
                        <span className="font-mono bg-white group-hover:bg-indigo-100 px-1 py-0.5 rounded text-[10px] text-gray-600 font-bold">
                          {item.code.slice(-5)}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col">
              <p className="text-sm text-gray-600 mb-4">
                Gib eine beliebige <strong>ISBN-Nummer</strong>, einen <strong>Buchtitel</strong> oder einen <strong>Autor</strong> ein. Gemini sucht oder generiert dafür sofort exakte bibliografische Metadaten.
              </p>
              
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleLookup(manualQuery);
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    ISBN, Schul-ISBN, Buchtitel oder Autor
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      disabled={loading}
                      placeholder="z.B. 9783453148643, SCH-101 oder 'Krabat Otfried Preußler'"
                      value={manualQuery}
                      onChange={(e) => setManualQuery(e.target.value)}
                      className="w-full px-4 py-2.5 bg-white border border-gray-300 rounded-lg text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                    />
                    <button
                      type="submit"
                      disabled={loading || !manualQuery.trim()}
                      className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-xs rounded-md transition-colors disabled:opacity-50 flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      Suchen
                    </button>
                  </div>
                </div>
              </form>

              {loading && (
                <div className="mt-8 flex flex-col items-center justify-center py-6 text-center">
                  <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mb-3" />
                  <p className="text-sm text-gray-600 font-medium">Lese Spuren des Buchs...</p>
                  <span className="text-xs text-gray-400">Gemini AI erstellt das Buchprofil</span>
                </div>
              )}

              {successMsg && !loading && (
                <div className="mt-6 p-4 bg-emerald-50 border border-emerald-100 rounded-lg flex items-center gap-3 text-emerald-800">
                  <div className="p-1 bg-emerald-500 text-white rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Buch erfolgreich erkannt!</p>
                    <p className="text-xs text-emerald-700">{successMsg}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="mt-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-start gap-3 text-red-800">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold">Fehler beim Nachschlagen</p>
                <p className="text-xs text-red-700">{error}</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white hover:bg-gray-100 border border-gray-300 rounded-lg transition-colors"
          >
            Abbrechen
          </button>
        </div>

      </div>
    </div>
  );
};
