import React, { useState } from "react";
import {
  Search,
  Plus,
  Trash2,
  Edit3,
  ShieldAlert,
  Check,
  Sparkles,
  BookOpen,
  Download,
  Upload,
  FileText,
  FileSpreadsheet,
  Printer,
  Clipboard,
  Loader,
} from "lucide-react";
import { Book } from "../types";

interface BookCatalogProps {
  books: Book[];
  onAddBook: (book: Book) => void;
  onDeleteBook: (id: string) => void;
  onOpenScanner: () => void;
}

export const BookCatalog: React.FC<BookCatalogProps> = ({
  books,
  onAddBook,
  onDeleteBook,
  onOpenScanner,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All");
  const [selectedStatus, setSelectedStatus] = useState("All");

  // Form states for manual additions / edits
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  // Import/Export States
  const [showImportExport, setShowImportExport] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [importWarning, setImportWarning] = useState<string | null>(null);
  const [importedBooks, setImportedBooks] = useState<Book[]>([]);
  const [selectedImportIndices, setSelectedImportIndices] = useState<number[]>([]);
  const [pasteText, setPasteText] = useState("");

  // Form Fields
  const [isbn, setIsbn] = useState("");
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [description, setDescription] = useState("");
  const [genre, setGenre] = useState("");
  const [price, setPrice] = useState("14.99");
  const [pages, setPages] = useState("250");

  const genres = ["All", ...Array.from(new Set(books.map((b) => b.genre)))];

  // Filter books based on criteria
  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery);

    const matchesGenre = selectedGenre === "All" || book.genre === selectedGenre;
    const matchesStatus =
      selectedStatus === "All" ||
      (selectedStatus === "available" && book.status === "available") ||
      (selectedStatus === "borrowed" && book.status === "borrowed");

    return matchesSearch && matchesGenre && matchesStatus;
  });

  const [isAiAutofilling, setIsAiAutofilling] = useState(false);
  const [aiAutofillError, setAiAutofillError] = useState<string | null>(null);

  const handleAiAutofill = async () => {
    if (!isbn.trim()) return;
    setIsAiAutofilling(true);
    setAiAutofillError(null);
    try {
      const res = await fetch("/api/book-lookup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: isbn }),
      });

      if (!res.ok) {
        throw new Error("Buchdaten konnten von der KI nicht ermittelt werden.");
      }

      const bookData = await res.json();
      if (bookData.error) {
        throw new Error(bookData.error);
      }

      setIsbn(bookData.isbn || isbn);
      setTitle(bookData.title || "");
      setAuthor(bookData.author || "");
      setDescription(bookData.description || "");
      setGenre(bookData.genre || "Romane");
      setPrice(bookData.price ? bookData.price.toString() : "14.99");
      setPages(bookData.pages ? bookData.pages.toString() : "250");
    } catch (err: any) {
      console.error(err);
      setAiAutofillError(err.message || "Fehler beim KI-Abruf. Bitte Daten manuell eingeben.");
    } finally {
      setIsAiAutofilling(false);
    }
  };

  const resetForm = () => {
    setIsbn("");
    setTitle("");
    setAuthor("");
    setDescription("");
    setGenre("");
    setPrice("14.99");
    setPages("250");
    setEditingBook(null);
    setAiAutofillError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !author) return;

    const parsedPrice = parseFloat(price) || 0;
    const parsedPages = parseInt(pages, 10) || 0;
    const cleanIsbn = isbn.replace(/[-\s]/g, "") || Math.floor(Math.random() * 10000000000000).toString();

    const bookData: Book = {
      id: editingBook ? editingBook.id : cleanIsbn,
      isbn: cleanIsbn,
      title,
      author,
      description,
      genre: genre || "Sonstige",
      price: parsedPrice,
      pages: parsedPages,
      status: editingBook ? editingBook.status : "available",
      borrowerId: editingBook ? editingBook.borrowerId : null,
      borrowerName: editingBook ? editingBook.borrowerName : null,
      dueDate: editingBook ? editingBook.dueDate : null,
      createdAt: editingBook ? editingBook.createdAt : new Date().toISOString(),
    };

    onAddBook(bookData);
    resetForm();
    setShowAddForm(false);
  };

  const handleEditClick = (book: Book) => {
    setEditingBook(book);
    setIsbn(book.isbn);
    setTitle(book.title);
    setAuthor(book.author);
    setDescription(book.description);
    setGenre(book.genre);
    setPrice(book.price.toString());
    setPages(book.pages.toString());
    setShowAddForm(true);
  };

  // --- EXPORT HANDLERS ---
  const handleExportCSV = () => {
    if (books.length === 0) return;
    const headers = ["ISBN", "Titel", "Autor", "Kategorie", "Beschreibung", "Preis (€)", "Seitenanzahl", "Status"];
    const rows = books.map((b) => [
      b.isbn || "",
      `"${b.title.replace(/"/g, '""')}"`,
      `"${b.author.replace(/"/g, '""')}"`,
      `"${(b.genre || "Sonstige").replace(/"/g, '""')}"`,
      `"${(b.description || "").replace(/"/g, '""')}"`,
      b.price.toFixed(2),
      b.pages,
      b.status === "available" ? "Verfügbar" : "Ausgeliehen"
    ]);

    // Include BOM for Excel-compatibility on Windows with German Umlauts
    const csvContent = "\ufeff" + [headers.join(";"), ...rows.map((e) => e.join(";"))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Bibliothekskatalog_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportMarkdown = () => {
    if (books.length === 0) return;
    let markdown = `# Bibliothekskatalog\n\nGeneriert am: ${new Date().toLocaleDateString("de-DE")}\nBestand: ${books.length} Bücher\n\n`;
    markdown += "| ISBN | Titel | Autor | Kategorie | Preis | Status |\n";
    markdown += "| --- | --- | --- | --- | --- | --- |\n";
    books.forEach((b) => {
      markdown += `| ${b.isbn || "-"} | ${b.title} | ${b.author} | ${b.genre || "Sonstige"} | ${b.price.toFixed(2)} € | ${b.status === "available" ? "Verfügbar" : "Ausgeliehen"} |\n`;
    });

    const blob = new Blob([markdown], { type: "text/plain;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Bibliothekskatalog_${new Date().toISOString().split("T")[0]}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPDF = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Bitte erlaube Popups, um die Druckansicht zu öffnen.");
      return;
    }

    const bookRows = books
      .map(
        (b) => `
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="padding: 10px; font-weight: 500; color: #1e293b;">${b.title}</td>
        <td style="padding: 10px; color: #475569;">${b.author}</td>
        <td style="padding: 10px; font-family: monospace; font-size: 13px; color: #475569;">${b.isbn || "-"}</td>
        <td style="padding: 10px; color: #64748b;">${b.genre || "Sonstige"}</td>
        <td style="padding: 10px; text-align: right; color: #1e293b;">${b.price.toFixed(2)} €</td>
        <td style="padding: 10px; text-align: center;">
          <span style="padding: 3px 8px; border-radius: 9999px; font-size: 11px; font-weight: 600; ${
            b.status === "available"
              ? "background-color: #dcfce7; color: #15803d;"
              : "background-color: #fee2e2; color: #b91c1c;"
          }">
            ${b.status === "available" ? "Verfügbar" : "Ausgeliehen"}
          </span>
        </td>
      </tr>
    `
      )
      .join("");

    printWindow.document.write(`
      <html>
        <head>
          <title>Bibliothekskatalog - Druckansicht</title>
          <style>
            body {
              font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              color: #1e293b;
              padding: 40px;
              margin: 0;
            }
            header {
              display: flex;
              justify-content: space-between;
              align-items: center;
              border-bottom: 2px solid #e2e8f0;
              padding-bottom: 20px;
              margin-bottom: 30px;
            }
            h1 {
              font-size: 24px;
              margin: 0;
              color: #0f172a;
            }
            .meta {
              font-size: 14px;
              color: #64748b;
              text-align: right;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              font-size: 14px;
            }
            th {
              background-color: #f8fafc;
              border-bottom: 2px solid #cbd5e1;
              padding: 12px 10px;
              font-weight: 600;
              text-align: left;
              color: #475569;
            }
            .footer {
              margin-top: 40px;
              text-align: center;
              font-size: 12px;
              color: #94a3b8;
              border-top: 1px solid #e2e8f0;
              padding-top: 20px;
            }
            @media print {
              body { padding: 0; }
              button { display: none; }
            }
          </style>
        </head>
        <body>
          <header>
            <div>
              <h1>Schulbibliothek Katalogliste</h1>
              <p style="margin: 5px 0 0 0; color: #64748b; font-size: 14px;">Bibliotheksbestand - Vollständige Bestandsliste</p>
            </div>
            <div class="meta">
              <p style="margin: 0;"><b>Datum:</b> ${new Date().toLocaleDateString("de-DE")}</p>
              <p style="margin: 5px 0 0 0;"><b>Büchergesamtanzahl:</b> ${books.length}</p>
            </div>
          </header>
          
          <div style="margin-bottom: 20px; display: flex; justify-content: flex-end;">
            <button onclick="window.print();" style="padding: 10px 20px; background-color: #4f46e5; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
              Drucken / PDF speichern
            </button>
          </div>

          <table>
            <thead>
              <tr>
                <th>Buchtitel</th>
                <th>Autor</th>
                <th>ISBN</th>
                <th>Kategorie</th>
                <th style="text-align: right;">Preis</th>
                <th style="text-align: center;">Status</th>
              </tr>
            </thead>
            <tbody>
              ${bookRows}
            </tbody>
          </table>

          <div class="footer">
            <p>Generiert über das Schulbibliothek-Management-System</p>
          </div>

          <script>
            window.addEventListener('DOMContentLoaded', () => {
              setTimeout(() => {
                window.print();
              }, 500);
            });
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // --- IMPORT HANDLERS ---
  const sendImportRequest = async (fileName: string, fileType: string, base64Data: string, rawText: string) => {
    try {
      setImportWarning(null);
      const response = await fetch("/api/import-file", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fileName,
          fileType,
          base64Data,
          rawText,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Import fehlgeschlagen");
      }

      const data = await response.json();
      if (data.warning) {
        setImportWarning(data.warning);
      }

      if (data.books && Array.isArray(data.books)) {
        const formatted: Book[] = data.books.map((b: any, index: number) => {
          const rawIsbn = (b.isbn || "").replace(/[-\s]/g, "");
          const cleanIsbn = /^\d{10,13}$/.test(rawIsbn) ? rawIsbn : "";
          const generatedId = cleanIsbn || `import_${Date.now()}_${index}_${Math.floor(Math.random() * 10000)}`;
          
          return {
            id: generatedId,
            isbn: cleanIsbn,
            title: b.title || "Unbenanntes Buch",
            author: b.author || "Unbekannter Autor",
            description: b.description || b.description || "",
            genre: b.genre || "Sonstige",
            price: typeof b.price === "number" ? b.price : 9.99,
            pages: typeof b.pages === "number" ? b.pages : 150,
            status: "available",
            borrowerId: null,
            borrowerName: null,
            dueDate: null,
            createdAt: new Date().toISOString(),
          };
        });

        setImportedBooks(formatted);
        setSelectedImportIndices(formatted.map((_, i) => i)); // Select all by default
      } else {
        throw new Error("Keine Bücher in der Datei gefunden.");
      }
    } catch (err: any) {
      setImportError(err.message || "Fehler beim Verarbeiten mit Gemini.");
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileImport = async (file: File) => {
    setIsImporting(true);
    setImportError(null);
    setImportedBooks([]);

    try {
      const fileType = file.type;
      const fileName = file.name;

      if (fileType === "application/pdf") {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64Result = reader.result as string;
          await sendImportRequest(fileName, fileType, baseResultOnly(base64Result), "");
        };
        reader.onerror = () => {
          setImportError("Fehler beim Lesen der PDF-Datei.");
          setIsImporting(false);
        };
        reader.readAsDataURL(file);
      } else if (fileType === "text/csv" || file.name.endsWith(".csv") || fileType === "text/plain" || file.name.endsWith(".txt")) {
        const reader = new FileReader();
        reader.onload = async () => {
          const textResult = reader.result as string;
          await sendImportRequest(fileName, fileType, "", textResult);
        };
        reader.onerror = () => {
          setImportError("Fehler beim Lesen der Datei.");
          setIsImporting(false);
        };
        reader.readAsText(file);
      } else {
        // Fallback: read as text for general text-based files
        const reader = new FileReader();
        reader.onload = async () => {
          const textResult = reader.result as string;
          await sendImportRequest(fileName, fileType, "", textResult);
        };
        reader.onerror = () => {
          setImportError("Datei-Format nicht direkt unterstützt. Versuche den Text zu kopieren.");
          setIsImporting(false);
        };
        reader.readAsText(file);
      }
    } catch (err: any) {
      setImportError(err.message || "Fehler beim Vorbereiten des Dateitransfers.");
      setIsImporting(false);
    }
  };

  const baseResultOnly = (dataUrl: string) => {
    const commaIndex = dataUrl.indexOf(",");
    return commaIndex !== -1 ? dataUrl.substring(commaIndex + 1) : dataUrl;
  };

  const handlePasteImport = async () => {
    if (!pasteText.trim()) return;
    setIsImporting(true);
    setImportError(null);
    setImportedBooks([]);

    await sendImportRequest("pasted_text.txt", "text/plain", "", pasteText);
  };

  const handleSaveImportedBooks = () => {
    const booksToSave = importedBooks.filter((_, index) => selectedImportIndices.includes(index));
    if (booksToSave.length === 0) return;

    booksToSave.forEach((book) => {
      onAddBook(book);
    });

    // Reset and close
    setImportedBooks([]);
    setSelectedImportIndices([]);
    setPasteText("");
    setShowImportExport(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Title Header area */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Bücherbestand verwalten</h2>
          <p className="text-sm text-gray-500">
            Hinzufügen per Barcode-Scanner, Bearbeiten von Preisen und Sichten aller Bibliotheksmedien.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenScanner}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-xl transition-all shadow-xs flex items-center gap-2 active:scale-98"
          >
            <Sparkles className="w-4 h-4" />
            <span>Buch scannen (Scanner)</span>
          </button>
          <button
            onClick={() => {
              resetForm();
              setShowAddForm(!showAddForm);
              setShowImportExport(false);
            }}
            className={`px-4 py-2.5 font-medium text-sm rounded-xl transition-all flex items-center gap-2 active:scale-98 ${
              showAddForm
                ? "bg-indigo-50 text-indigo-700 border border-indigo-200"
                : "bg-white hover:bg-gray-50 text-gray-700 border border-gray-300"
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{showAddForm ? "Formular schließen" : "Manuell hinzufügen"}</span>
          </button>
          <button
            onClick={() => {
              setShowImportExport(!showImportExport);
              setShowAddForm(false);
            }}
            className={`px-4 py-2.5 font-medium text-sm rounded-xl transition-all flex items-center gap-2 active:scale-98 ${
              showImportExport
                ? "bg-indigo-50 text-indigo-700 border border-indigo-200"
                : "bg-white hover:bg-gray-50 text-gray-700 border border-gray-300"
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Import / Export</span>
          </button>
        </div>
      </div>

      {/* Manual Add / Edit Form Modal-like collapse */}
      {showAddForm && (
        <div className="bg-slate-50 p-6 rounded-2xl border border-gray-200 shadow-inner">
          <h3 className="font-semibold text-gray-900 mb-4">
            {editingBook ? "Buchdetails bearbeiten" : "Neues Buch manuell anlegen"}
          </h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-medium text-gray-700">ISBN / Schul-ISBN / Barcode</label>
                {isbn.trim() && (
                  <button
                    type="button"
                    onClick={handleAiAutofill}
                    disabled={isAiAutofilling}
                    className="text-indigo-600 hover:text-indigo-800 text-xs font-bold flex items-center gap-1 transition-all disabled:opacity-50"
                  >
                    {isAiAutofilling ? (
                      <Loader className="w-3 h-3 animate-spin" />
                    ) : (
                      <Sparkles className="w-3 h-3" />
                    )}
                    <span>Mit KI ausfüllen</span>
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="text"
                  placeholder="z.B. 9783453148643 oder SCH-101"
                  value={isbn}
                  onChange={(e) => setIsbn(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 pr-10"
                />
                {isbn.trim() && (
                  <button
                    type="button"
                    onClick={handleAiAutofill}
                    disabled={isAiAutofilling}
                    title="Buchdaten automatisch mit Gemini KI vervollständigen"
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-md transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isAiAutofilling ? (
                      <Loader className="w-4 h-4 animate-spin text-indigo-600" />
                    ) : (
                      <Sparkles className="w-4 h-4" />
                    )}
                  </button>
                )}
              </div>
              <span className="text-[10px] text-gray-400 mt-1 block leading-tight">
                Auch kurze, schulinterne Barcodes/Klassennummerierungen (z.B. "S-101") sind zulässig.
              </span>
              {aiAutofillError && (
                <span className="text-[10px] text-rose-600 block leading-tight mt-1">
                  {aiAutofillError}
                </span>
              )}
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Buchtitel *</label>
              <input
                type="text"
                required
                placeholder="Buchtitel eingeben"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Autor / Verfasser *</label>
              <input
                type="text"
                required
                placeholder="Autor eingeben"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Kategorie / Genre</label>
              <input
                type="text"
                placeholder="z.B. Romane, Klassiker, Sachbuch"
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Preis (€) *</label>
              <input
                type="number"
                step="0.01"
                required
                placeholder="14.99"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Seitenanzahl</label>
              <input
                type="number"
                placeholder="z.B. 350"
                value={pages}
                onChange={(e) => setPages(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div className="md:col-span-3">
              <label className="block text-xs font-medium text-gray-700 mb-1">Inhaltsbeschreibung</label>
              <textarea
                placeholder="Kurze Beschreibung des Buchinhalts..."
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div className="md:col-span-3 flex justify-end gap-2 mt-2">
              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setShowAddForm(false);
                }}
                className="px-4 py-2 text-sm text-gray-700 bg-white hover:bg-gray-100 border border-gray-300 rounded-lg"
              >
                Abbrechen
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
              >
                {editingBook ? "Änderungen speichern" : "Buch registrieren"}
              </button>
            </div>
          </form>
        </div>
      )}

      {showImportExport && (
        <div className="bg-slate-50 p-6 rounded-2xl border border-gray-200 shadow-inner space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Import Section */}
            <div className="bg-white p-5 rounded-xl border border-gray-200 space-y-4">
              <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <Upload className="w-4 h-4 text-indigo-600" />
                <span>Bücher importieren (KI-unterstützt)</span>
              </h3>
              <p className="text-xs text-gray-500">
                Lade eine Datei hoch oder füge Text ein. Die künstliche Intelligenz (Gemini) liest die Struktur automatisch aus und ergänzt fehlende Daten.
              </p>

              {/* Drag and Drop Zone */}
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-indigo-500 transition-colors cursor-pointer relative bg-slate-50/50">
                <input
                  type="file"
                  accept=".pdf,.csv,.txt"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileImport(file);
                  }}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  disabled={isImporting}
                />
                <div className="flex flex-col items-center justify-center gap-2">
                  <div className="p-3 bg-indigo-50 rounded-full text-indigo-600">
                    <FileText className="w-6 h-6" />
                  </div>
                  <span className="text-sm font-medium text-gray-700">PDF, CSV oder TXT auswählen</span>
                  <span className="text-xs text-gray-400">oder Datei hierher ziehen (max. 10MB)</span>
                </div>
              </div>

              <div className="relative flex items-center justify-center">
                <hr className="w-full border-gray-200" />
                <span className="absolute bg-white px-3 text-xs text-gray-400 uppercase font-medium">oder</span>
              </div>

              {/* Text Paste Area */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600">
                  Text kopieren & einfügen (z.B. aus Word/DOCX oder Excel)
                </label>
                <textarea
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder="Füge hier eine Liste von Büchern ein (z.B. &quot;Der Hobbit - J.R.R. Tolkien, ISBN: 978...&quot;)"
                  rows={4}
                  className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-xs"
                  disabled={isImporting}
                />
                <button
                  type="button"
                  onClick={handlePasteImport}
                  disabled={isImporting || !pasteText.trim()}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white font-medium text-xs rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Clipboard className="w-3.5 h-3.5" />
                  <span>Kopierten Text analysieren & importieren</span>
                </button>
              </div>
            </div>

            {/* Export Section */}
            <div className="bg-white p-5 rounded-xl border border-gray-200 space-y-4">
              <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <Download className="w-4 h-4 text-indigo-600" />
                <span>Katalog exportieren</span>
              </h3>
              <p className="text-xs text-gray-500">
                Exportiere den aktuellen Bücherbestand der Schule in ein gängiges Dateiformat zur Weiterverwendung.
              </p>

              <div className="grid grid-cols-1 gap-3">
                <button
                  onClick={handleExportCSV}
                  className="w-full p-3 bg-slate-50 hover:bg-slate-100 border border-gray-200 rounded-xl transition-all flex items-center gap-3 text-left group"
                >
                  <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600 group-hover:bg-emerald-100 transition-colors">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-sm font-semibold text-gray-800">Als CSV exportieren</span>
                    <span className="block text-xs text-gray-400">Kompatibel mit Microsoft Excel, Google Sheets und Numbers (Semicolon-separiert)</span>
                  </div>
                </button>

                <button
                  onClick={handleExportMarkdown}
                  className="w-full p-3 bg-slate-50 hover:bg-slate-100 border border-gray-200 rounded-xl transition-all flex items-center gap-3 text-left group"
                >
                  <div className="p-2 bg-blue-50 rounded-lg text-blue-600 group-hover:bg-blue-100 transition-colors">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-sm font-semibold text-gray-800">Als Markdown (TXT) exportieren</span>
                    <span className="block text-xs text-gray-400">Als übersichtliche Texttabelle im Reintextformat</span>
                  </div>
                </button>

                <button
                  onClick={handlePrintPDF}
                  className="w-full p-3 bg-slate-50 hover:bg-slate-100 border border-gray-200 rounded-xl transition-all flex items-center gap-3 text-left group"
                >
                  <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600 group-hover:bg-indigo-100 transition-colors">
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-sm font-semibold text-gray-800">Als PDF drucken / speichern</span>
                    <span className="block text-xs text-gray-400">Generiert ein druckfertiges Dokument mit dem gesamten Buchbestand</span>
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Loading Indicator */}
          {isImporting && (
            <div className="bg-indigo-50/50 p-6 rounded-xl border border-indigo-100 flex flex-col items-center justify-center gap-3 text-center">
              <Loader className="w-8 h-8 text-indigo-600 animate-spin" />
              <div>
                <span className="block text-sm font-semibold text-gray-800">Datei oder Text wird analysiert...</span>
                <span className="block text-xs text-gray-400 max-w-xs mx-auto">
                  Die künstliche Intelligenz (Gemini 3.5 Flash) liest das Dokument aus und extrahiert Buchtitel, Autoren und ISBNs. Dies kann einige Sekunden dauern.
                </span>
              </div>
            </div>
          )}

          {/* Error Message */}
          {importError && (
            <div className="bg-rose-50 p-4 rounded-xl border border-rose-100 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div>
                <span className="block text-sm font-semibold text-rose-800">Fehler beim Importieren</span>
                <span className="block text-xs text-rose-600">{importError}</span>
              </div>
            </div>
          )}

          {/* Warning/Fallback Message */}
          {importWarning && (
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-amber-500 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <span className="block text-sm font-semibold text-amber-800">Hinweis zum Import (Fallback)</span>
                <span className="block text-xs text-amber-600">{importWarning}</span>
              </div>
            </div>
          )}

          {/* Preview of Imported Books */}
          {importedBooks.length > 0 && (
            <div className="space-y-4 bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
                <div>
                  <h4 className="font-bold text-gray-900">Extrahierte Bücher ({importedBooks.length})</h4>
                  <p className="text-xs text-gray-400">
                    Passe Werte bei Bedarf an und wähle die Bücher aus, die du in die Datenbank importieren möchtest.
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedImportIndices.length === importedBooks.length) {
                        setSelectedImportIndices([]);
                      } else {
                        setSelectedImportIndices(importedBooks.map((_, i) => i));
                      }
                    }}
                    className="px-3 py-1.5 text-xs font-semibold bg-gray-50 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    {selectedImportIndices.length === importedBooks.length ? "Keines auswählen" : "Alle auswählen"}
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveImportedBooks}
                    disabled={selectedImportIndices.length === 0}
                    className="px-4 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors disabled:bg-gray-300 flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{selectedImportIndices.length} Bücher speichern</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto max-h-80 border border-gray-200 rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 bg-slate-50 text-gray-500 font-semibold sticky top-0">
                      <th className="px-4 py-2 text-center w-10">
                        <input
                          type="checkbox"
                          checked={selectedImportIndices.length === importedBooks.length && importedBooks.length > 0}
                          onChange={() => {
                            if (selectedImportIndices.length === importedBooks.length) {
                              setSelectedImportIndices([]);
                            } else {
                              setSelectedImportIndices(importedBooks.map((_, i) => i));
                            }
                          }}
                          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      </th>
                      <th className="px-4 py-2">Buchtitel</th>
                      <th className="px-4 py-2">Autor</th>
                      <th className="px-4 py-2">ISBN</th>
                      <th className="px-4 py-2">Kategorie</th>
                      <th className="px-4 py-2 text-right">Preis</th>
                      <th className="px-4 py-2 text-center">Seiten</th>
                    </tr>
                  </thead>
                  <tbody>
                    {importedBooks.map((b, index) => {
                      const isSelected = selectedImportIndices.includes(index);
                      return (
                        <tr
                          key={index}
                          className={`border-b border-gray-100 hover:bg-slate-50 transition-colors ${
                            isSelected ? "bg-indigo-50/10" : ""
                          }`}
                        >
                          <td className="px-4 py-2.5 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {
                                if (isSelected) {
                                  setSelectedImportIndices(selectedImportIndices.filter((i) => i !== index));
                                } else {
                                  setSelectedImportIndices([...selectedImportIndices, index]);
                                }
                              }}
                              className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                          </td>
                          <td className="px-4 py-2.5 font-medium text-gray-900">
                            <input
                              type="text"
                              value={b.title}
                              onChange={(e) => {
                                const copy = [...importedBooks];
                                copy[index].title = e.target.value;
                                setImportedBooks(copy);
                              }}
                              className="w-full bg-transparent border-0 focus:ring-1 focus:ring-indigo-500 rounded px-1 text-xs"
                            />
                          </td>
                          <td className="px-4 py-2.5 text-gray-700">
                            <input
                              type="text"
                              value={b.author}
                              onChange={(e) => {
                                const copy = [...importedBooks];
                                copy[index].author = e.target.value;
                                setImportedBooks(copy);
                              }}
                              className="w-full bg-transparent border-0 focus:ring-1 focus:ring-indigo-500 rounded px-1 text-xs"
                            />
                          </td>
                          <td className="px-4 py-2.5 font-mono text-gray-500">
                            <input
                              type="text"
                              value={b.isbn}
                              onChange={(e) => {
                                const copy = [...importedBooks];
                                copy[index].isbn = e.target.value;
                                setImportedBooks(copy);
                              }}
                              className="w-full bg-transparent border-0 focus:ring-1 focus:ring-indigo-500 rounded px-1 text-xs"
                            />
                          </td>
                          <td className="px-4 py-2.5 text-gray-500">
                            <input
                              type="text"
                              value={b.genre}
                              onChange={(e) => {
                                const copy = [...importedBooks];
                                copy[index].genre = e.target.value;
                                setImportedBooks(copy);
                              }}
                              className="w-full bg-transparent border-0 focus:ring-1 focus:ring-indigo-500 rounded px-1 text-xs"
                            />
                          </td>
                          <td className="px-4 py-2.5 text-right font-medium text-gray-800">
                            <input
                              type="number"
                              step="0.01"
                              value={b.price}
                              onChange={(e) => {
                                const copy = [...importedBooks];
                                copy[index].price = parseFloat(e.target.value) || 0;
                                setImportedBooks(copy);
                              }}
                              className="w-16 bg-transparent border-0 text-right focus:ring-1 focus:ring-indigo-500 rounded px-1 text-xs"
                            />
                          </td>
                          <td className="px-4 py-2.5 text-center text-gray-500">
                            <input
                              type="number"
                              value={b.pages}
                              onChange={(e) => {
                                const copy = [...importedBooks];
                                copy[index].pages = parseInt(e.target.value, 10) || 0;
                                setImportedBooks(copy);
                              }}
                              className="w-12 bg-transparent border-0 text-center focus:ring-1 focus:ring-indigo-500 rounded px-1 text-xs"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-white p-4 rounded-xl border border-gray-200">
        <div className="sm:col-span-2 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Titel, Autor oder ISBN suchen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder-gray-400"
          />
        </div>
        <div>
          <select
            value={selectedGenre}
            onChange={(e) => setSelectedGenre(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
          >
            {genres.map((g) => (
              <option key={g} value={g}>
                {g === "All" ? "Alle Kategorien" : g}
              </option>
            ))}
          </select>
        </div>
        <div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
          >
            <option value="All">Alle Statuswerte</option>
            <option value="available">Verfügbar</option>
            <option value="borrowed">Ausgeliehen</option>
          </select>
        </div>
      </div>

      {/* Catalog Table */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-xs">
        {filteredBooks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center text-gray-400">
            <BookOpen className="w-16 h-16 stroke-1 mb-3" />
            <p className="text-base font-semibold">Keine Bücher gefunden</p>
            <p className="text-xs max-w-xs mt-1">
              Passe deine Filter an oder füge neue Bücher per Barcode-Scanner hinzu.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-gray-200 bg-slate-50 text-xs text-gray-400 uppercase font-semibold">
                  <th className="px-6 py-4">Buch</th>
                  <th className="px-6 py-4">ISBN</th>
                  <th className="px-6 py-4">Kategorie</th>
                  <th className="px-6 py-4">Preis</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Aktionen</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredBooks.map((book) => (
                  <tr key={book.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4.5">
                      <div className="flex flex-col">
                        <span className="font-semibold text-gray-950 text-sm">{book.title}</span>
                        <span className="text-xs text-gray-500">{book.author} • {book.pages} S.</span>
                        {book.description && (
                          <span className="text-[11px] text-gray-400 mt-1 max-w-[400px] truncate block" title={book.description}>
                            {book.description}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4.5 font-mono text-xs text-gray-600">
                      {book.isbn}
                    </td>
                    <td className="px-6 py-4.5">
                      <span className="inline-block px-2.5 py-1 bg-indigo-50/70 text-indigo-700 text-xs font-medium rounded-full">
                        {book.genre}
                      </span>
                    </td>
                    <td className="px-6 py-4.5 font-mono text-xs font-semibold text-gray-900">
                      {book.price.toFixed(2)} €
                    </td>
                    <td className="px-6 py-4.5">
                      {book.status === "available" ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                          <Check className="w-3.5 h-3.5" />
                          <span>Verfügbar</span>
                        </span>
                      ) : (
                        <div className="flex flex-col">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800 self-start">
                            <ShieldAlert className="w-3.5 h-3.5" />
                            <span>Ausgeliehen</span>
                          </span>
                          <span className="text-[10px] text-gray-400 mt-1">
                            an {book.borrowerName} (bis {book.dueDate?.split("-").reverse().join(".")})
                          </span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4.5 text-right space-x-1.5">
                      <button
                        onClick={() => handleEditClick(book)}
                        className="p-1.5 text-gray-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                        title="Buchpreis oder Details bearbeiten"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        disabled={book.status === "borrowed"}
                        onClick={() => onDeleteBook(book.id)}
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                        title={book.status === "borrowed" ? "Ausgeliehenes Buch kann nicht gelöscht werden" : "Buch löschen"}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
