import React, { useState } from "react";
import { BookOpen, User, Lock, Shield, Info, ArrowRight, UserPlus, LogIn, Sparkles, CheckCircle2 } from "lucide-react";
import { LibraryUser } from "../types";
import { LibraryDB } from "../services/db";

interface LoginSignupProps {
  onLoginSuccess: (user: LibraryUser) => void;
  users: LibraryUser[];
  onRefreshUsers: () => void;
}

export function LoginSignup({ onLoginSuccess, users, onRefreshUsers }: LoginSignupProps) {
  const [activeTab, setActiveTab] = useState<"login" | "signup">("login");
  
  // Login fields
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  
  // Signup fields
  const [signupUsername, setSignupUsername] = useState("");
  const [signupName, setSignupName] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupRole, setSignupRole] = useState<"Schüler" | "Lehrer" | "Bücherei-Lehrer/in">("Schüler");
  const [classOrSubject, setClassOrSubject] = useState("");
  const [signupSchoolCode, setSignupSchoolCode] = useState("");

  // UI state
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUsername || !loginPassword) {
      showError("Bitte füllen Sie alle Felder aus!");
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      // Refresh list to have latest
      const latestUsers = await LibraryDB.getUsers();
      const matched = latestUsers.find(
        (u) =>
          u.username &&
          u.username.trim().toLowerCase() === loginUsername.trim().toLowerCase() &&
          u.passwordHash === loginPassword
      );

      if (matched) {
        // Enforce account active check (unless Superadmin)
        if (matched.role !== "Superadmin" && matched.isActive === false) {
          showError("Ihr Benutzerkonto wurde vorübergehend pausiert oder deaktiviert.");
          setIsSubmitting(false);
          return;
        }

        // Enforce school active check (unless Superadmin)
        if (matched.role !== "Superadmin" && matched.schoolCode !== "SYSTEM") {
          const schools = await LibraryDB.getSchools();
          const userSchool = schools.find(s => s.id && s.id.toUpperCase() === matched.schoolCode?.toUpperCase());
          if (!userSchool) {
            showError("Der Schulcode Ihrer Schule ist im System nicht registriert.");
            setIsSubmitting(false);
            return;
          }
          if (!userSchool.isActive) {
            showError("Ihre Schule wurde vorübergehend pausiert. Login nicht möglich.");
            setIsSubmitting(false);
            return;
          }
        }

        setSuccessMsg(`Willkommen zurück, ${matched.name}!`);
        setTimeout(() => {
          onLoginSuccess(matched);
        }, 1000);
      } else {
        showError("Ungültiger Benutzername oder Passwort! Bitte überprüfen Sie Ihre Eingabe.");
      }
    } catch (err) {
      console.error("Login error details:", err);
      showError("Anmeldefehler. Bitte versuchen Sie es erneut.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupUsername || !signupName || !signupPassword || !signupSchoolCode) {
      showError("Bitte füllen Sie alle Pflichtfelder aus (einschließlich Schulcode)!");
      return;
    }

    if (signupRole !== "Bücherei-Lehrer/in" && !classOrSubject) {
      showError(
        signupRole === "Schüler"
          ? "Bitte geben Sie Ihre Klasse an (z.B. Klasse 10b)."
          : "Bitte geben Sie Ihre Unterrichtsfächer an (z.B. Deutsch, Mathe)."
      );
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const latestUsers = await LibraryDB.getUsers();

      // Check if username already exists
      const exists = latestUsers.some(
        (u) => u.username && u.username.trim().toLowerCase() === signupUsername.trim().toLowerCase()
      );

      if (exists) {
        showError("Dieser Benutzername ist leider bereits vergeben.");
        setIsSubmitting(false);
        return;
      }

      // Admin role constraint: Check if an admin already exists for this school code
      if (signupRole === "Bücherei-Lehrer/in") {
        const adminExists = latestUsers.some(
          (u) =>
            u.role === "Bücherei-Lehrer/in" &&
            u.schoolCode && u.schoolCode.trim().toLowerCase() === signupSchoolCode.trim().toLowerCase()
        );

        if (adminExists) {
          showError(`Für den Schulcode "${signupSchoolCode.toUpperCase()}" wurde bereits ein Admin-Konto erstellt. Pro Schule ist nur ein Admin-Konto erlaubt!`);
          setIsSubmitting(false);
          return;
        }
      }

      // Check if the school code is registered and active
      const registeredSchools = await LibraryDB.getSchools();
      const matchedSchool = registeredSchools.find(
        (s) => s.id && s.id.toUpperCase() === signupSchoolCode.trim().toUpperCase()
      );

      if (!matchedSchool) {
        showError(`Der Schulcode "${signupSchoolCode.toUpperCase()}" ist nicht im System registriert. Bitte wenden Sie sich an die Schulleitung.`);
        setIsSubmitting(false);
        return;
      }

      if (!matchedSchool.isActive) {
        showError(`Der Schulcode "${signupSchoolCode.toUpperCase()}" (${matchedSchool.name}) wurde vorübergehend pausiert.`);
        setIsSubmitting(false);
        return;
      }

      // Generate a linked Library Member Card ID for Pupils/Teachers
      let generatedMemberId: string | null = null;
      if (signupRole === "Schüler") {
        generatedMemberId = `S-${Math.floor(10000 + Math.random() * 90000)}`;
      } else if (signupRole === "Lehrer") {
        generatedMemberId = `L-${Math.floor(20000 + Math.random() * 90000)}`;
      }

      const newUser: LibraryUser = {
        id: `U-${Date.now()}`,
        username: signupUsername.trim(),
        passwordHash: signupPassword,
        name: signupName.trim(),
        role: signupRole,
        classOrSubject: signupRole === "Bücherei-Lehrer/in" ? "Bibliotheksleitung" : classOrSubject.trim(),
        memberId: generatedMemberId,
        schoolCode: signupSchoolCode.trim().toUpperCase(),
        isActive: true,
        createdAt: new Date().toISOString(),
      };

      await LibraryDB.registerUser(newUser);
      onRefreshUsers();

      setSuccessMsg("Konto erfolgreich erstellt! Sie können sich jetzt anmelden.");
      
      // Auto pre-fill login
      setLoginUsername(signupUsername);
      setLoginPassword(signupPassword);
      
      // Switch back to login after delay
      setTimeout(() => {
        setActiveTab("login");
        setSuccessMsg(null);
      }, 1800);

      // Reset form
      setSignupUsername("");
      setSignupName("");
      setSignupPassword("");
      setClassOrSubject("");
      setSignupSchoolCode("");
    } catch (err) {
      showError("Registrierung fehlgeschlagen. Bitte versuchen Sie es erneut.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const showError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(null), 5000);
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center py-10 px-4 sm:px-6 lg:px-8 bg-slate-50 min-h-[80vh]">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-3xl border border-gray-200 shadow-md">
        
        {/* Brand logo header */}
        <div className="text-center">
          <div className="mx-auto h-12 w-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-md mb-4">
            <BookOpen className="w-6 h-6" />
          </div>
          <span className="text-xs uppercase tracking-widest text-indigo-600 font-extrabold leading-none">
            LesePortal
          </span>
          <h2 className="mt-1.5 text-2xl font-black text-gray-950 tracking-tight">
            Schulbibliothek & Ausleihe
          </h2>
          <p className="mt-1.5 text-xs text-gray-500">
            Bitte melden Sie sich an oder registrieren Sie Ihr Schulkonto.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => {
              setActiveTab("login");
              setErrorMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === "login"
                ? "bg-white text-gray-900 shadow-xs"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <LogIn className="w-4 h-4" />
            Anmelden
          </button>
          <button
            onClick={() => {
              setActiveTab("signup");
              setErrorMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === "signup"
                ? "bg-white text-gray-900 shadow-xs"
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            <UserPlus className="w-4 h-4" />
            Registrieren
          </button>
        </div>

        {/* Dynamic feedback messages */}
        {errorMsg && (
          <div className="p-3.5 bg-red-50 border border-red-200 text-red-800 text-xs font-semibold rounded-xl flex items-start gap-2.5 animate-pulse">
            <Info className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab content */}
        {activeTab === "login" ? (
          <form className="mt-8 space-y-5" onSubmit={handleLogin}>
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Benutzername
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                  <User className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900"
                  placeholder="z.B. max oder meyer"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Passwort
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900"
                  placeholder="Passwort eingeben"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5 disabled:bg-slate-400"
            >
              {isSubmitting ? "Wird angemeldet..." : "Jetzt anmelden"}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form className="mt-8 space-y-4" onSubmit={handleSignup}>
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Rolle auswählen
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["Schüler", "Lehrer", "Bücherei-Lehrer/in"] as const).map((role) => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => setSignupRole(role)}
                    className={`py-2 px-1 text-[10px] font-bold rounded-xl border text-center transition-all ${
                      signupRole === role
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-xs"
                        : "bg-slate-50 border-gray-250 text-gray-600 hover:bg-slate-100"
                    }`}
                  >
                    {role === "Bücherei-Lehrer/in" ? "📍 Admin" : role === "Lehrer" ? "🎓 Lehrer" : "🎒 Schüler"}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Schulcode
              </label>
              <input
                type="text"
                required
                value={signupSchoolCode}
                onChange={(e) => setSignupSchoolCode(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900 font-mono uppercase"
                placeholder="z.B. GOETHE-2026"
              />
              <p className="text-[10px] text-indigo-600 font-semibold mt-1 leading-normal">
                {signupRole === "Bücherei-Lehrer/in" 
                  ? "🔒 WICHTIG: Pro Schulcode kann nur EIN Admin-Konto erstellt werden!"
                  : "Gib den Schulcode deiner Schule ein, um dich mit ihr zu verbinden."}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Vollständiger Name
              </label>
              <input
                type="text"
                required
                value={signupName}
                onChange={(e) => setSignupName(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900"
                placeholder="z.B. Max Mustermann"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Gewünschter Benutzername
              </label>
              <input
                type="text"
                required
                value={signupUsername}
                onChange={(e) => setSignupUsername(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900"
                placeholder="z.B. max_mustermann"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Passwort
              </label>
              <input
                type="password"
                required
                value={signupPassword}
                onChange={(e) => setSignupPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900"
                placeholder="Passwort eingeben"
              />
            </div>

            {signupRole !== "Bücherei-Lehrer/in" && (
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  {signupRole === "Schüler" ? "Klasse" : "Fächer / Klassenleitung"}
                </label>
                <input
                  type="text"
                  required
                  value={classOrSubject}
                  onChange={(e) => setClassOrSubject(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900"
                  placeholder={
                    signupRole === "Schüler" ? "z.B. Klasse 10b" : "z.B. Deutsch, Sport (Klasse 9a)"
                  }
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5 disabled:bg-slate-400 mt-2"
            >
              {isSubmitting ? "Konto wird erstellt..." : "Konto erstellen"}
              <UserPlus className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
