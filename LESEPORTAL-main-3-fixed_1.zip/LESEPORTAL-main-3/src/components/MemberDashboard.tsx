import React, { useState } from "react";
import { 
  BookOpen, 
  User, 
  Calendar, 
  AlertCircle, 
  LogOut, 
  Search, 
  History, 
  Sparkles, 
  Clock, 
  BookMarked,
  Barcode,
  CheckCircle,
  HelpCircle
} from "lucide-react";
import { Book, Loan, LibraryUser, Member, LibraryOpeningHours } from "../types";
import { LibraryDB } from "../services/db";

interface MemberDashboardProps {
  currentUser: LibraryUser;
  books: Book[];
  loans: Loan[];
  members: Member[];
  onLogout: () => void;
}

export function MemberDashboard({ currentUser, books, loans, members, onLogout }: MemberDashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("Alle");
  const [openingHours, setOpeningHours] = useState<LibraryOpeningHours | null>(null);

  React.useEffect(() => {
    if (currentUser.schoolCode) {
      LibraryDB.getOpeningHours(currentUser.schoolCode).then(setOpeningHours);
    }
  }, [currentUser.schoolCode]);

  // Get active loans for this specific member
  const memberLoans = loans.filter((l) => l.memberId === currentUser.memberId);
  const activeLoans = memberLoans.filter((l) => !l.returnDate);
  const returnedLoans = memberLoans.filter((l) => l.returnDate);

  // Get unique genres for book catalog filter
  const genres = ["Alle", ...Array.from(new Set(books.map((b) => b.genre)))];

  // Filter book catalog for browsing
  const filteredBooks = books.filter((book) => {
    const matchesSearch = 
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery);
    
    const matchesGenre = selectedGenre === "Alle" || book.genre === selectedGenre;
    
    return matchesSearch && matchesGenre;
  });

  // Calculate stats
  const overdueCount = activeLoans.filter((l) => l.status === "overdue").length;

  return (
    <div className="min-h-screen bg-slate-50 pb-16">
      
      {/* Top Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-45 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-[10px] uppercase tracking-widest text-indigo-400 font-extrabold leading-none">
                  Mein LesePortal
                </span>
                <h1 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  {currentUser.role === "Lehrer" ? "Lehrer-Konto" : "Schüler-Konto"}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-white">{currentUser.name}</p>
                <p className="text-[10px] text-slate-400">{currentUser.classOrSubject} • Code: {currentUser.schoolCode || "DEMO123"}</p>
              </div>
              <button
                onClick={onLogout}
                className="px-3 py-1.5 bg-slate-800 hover:bg-red-900 border border-slate-700 hover:border-red-800 rounded-lg text-xs font-semibold text-slate-300 hover:text-white transition-all flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Abmelden</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
        
        {/* Welcome Section & Quick Alerts */}
        <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-md relative overflow-hidden">
          <div className="absolute right-0 bottom-0 opacity-10 translate-x-10 translate-y-10">
            <BookMarked className="w-80 h-80 stroke-1" />
          </div>
          <div className="relative z-10 max-w-2xl">
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 inline-flex items-center gap-1 mb-4">
              <Sparkles className="w-3 h-3 text-indigo-400" />
              Willkommen zurück
            </span>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Hallo, {currentUser.name}!
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-2 font-medium">
              Hier findest du die Übersicht deiner ausgeliehenen Bücher, Fristen und deinen digitalen Lese-Ausweis für die Bücherei-Theke.
            </p>

            {overdueCount > 0 && (
              <div className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3 text-red-200">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-red-400 animate-pulse" />
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-red-300">
                    Achtung: Leihfrist überschritten!
                  </h4>
                  <p className="text-[11px] mt-0.5 text-red-100">
                    Du hast aktuell <strong>{overdueCount} überfällige/s Buch/Bücher</strong>. Bitte bringe diese zeitnah in die Bücherei zurück oder verlängere die Frist bei den Aufsichtskräften.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Multi-grid section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left / Center - Books and Lending history */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* CURRENT ACTIVE LOANS */}
            <div className="bg-white rounded-3xl border border-gray-250 p-6 sm:p-8 shadow-xs">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-base font-black text-gray-950 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-indigo-600" />
                    <span>Aktuell ausgeliehen ({activeLoans.length})</span>
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">
                    Deine derzeitigen Leihvorgänge und Abgabefristen.
                  </p>
                </div>
              </div>

              {activeLoans.length === 0 ? (
                <div className="border border-dashed border-gray-300 rounded-2xl p-8 text-center bg-slate-50 text-gray-500 flex flex-col items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-emerald-500 stroke-1 mb-2.5" />
                  <p className="text-xs font-bold text-gray-800">Keine aktiven Ausleihen</p>
                  <p className="text-[11px] text-gray-500 max-w-xs mt-1">
                    Du hast im Moment keine Bücher ausgeliehen. Stöbere unten im Bestand, um dein nächstes Lieblingsbuch zu finden!
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {activeLoans.map((loan) => {
                    const isOverdue = loan.status === "overdue";
                    return (
                      <div 
                        key={loan.id} 
                        className={`p-4 border rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all ${
                          isOverdue 
                            ? "bg-red-50/40 border-red-200 hover:bg-red-50/80" 
                            : "bg-slate-50/40 border-gray-200 hover:bg-slate-50"
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 border border-indigo-150 text-indigo-700">
                              Buch-Ausleihe
                            </span>
                            {isOverdue ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700 border border-red-200 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                Überfällig
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                                Aktiv
                              </span>
                            )}
                          </div>
                          <h4 className="font-bold text-sm text-gray-950 truncate leading-snug">
                            {loan.bookTitle}
                          </h4>
                          <p className="text-[11px] text-gray-400 font-medium mt-0.5">
                            Ausgeliehen am: {loan.loanDate.split("-").reverse().join(".")}
                          </p>
                        </div>

                        <div className="sm:text-right shrink-0">
                          <span className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                            Rückgabe-Frist:
                          </span>
                          <span className={`text-xs font-extrabold block mt-0.5 ${isOverdue ? "text-red-600" : "text-gray-900"}`}>
                            {loan.dueDate.split("-").reverse().join(".")}
                          </span>
                          <p className={`text-[10px] font-semibold mt-1 ${isOverdue ? "text-red-500" : "text-gray-400"}`}>
                            {isOverdue 
                              ? "Frist abgelaufen!" 
                              : `Noch bis zum ${loan.dueDate.split("-").reverse().slice(0, 2).join(".")}.`}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* RETURNED LOANS HISTORY */}
            {returnedLoans.length > 0 && (
              <div className="bg-white rounded-3xl border border-gray-250 p-6 sm:p-8 shadow-xs">
                <h3 className="text-base font-black text-gray-950 flex items-center gap-2 mb-1">
                  <History className="w-5 h-5 text-gray-500" />
                  <span>Deine Lesehistorie ({returnedLoans.length})</span>
                </h3>
                <p className="text-xs text-gray-400 mb-5">
                  Bücher, die du in der Vergangenheit ausgeliehen und bereits zurückgegeben hast.
                </p>

                <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                  {returnedLoans.map((loan) => (
                    <div key={loan.id} className="p-3.5 bg-slate-50 border border-slate-150 rounded-xl flex justify-between items-center text-xs hover:bg-slate-100/50 transition-colors">
                      <div className="min-w-0 pr-2">
                        <span className="font-bold text-gray-800 block truncate">{loan.bookTitle}</span>
                        <span className="text-[10px] text-gray-400 font-medium mt-0.5 block">
                          Gelesen von {loan.loanDate.split("-").reverse().join(".")} bis {loan.returnDate?.split("-").reverse().join(".")}
                        </span>
                      </div>
                      <span className="px-2 py-1 bg-emerald-50 text-[10px] font-bold text-emerald-700 rounded-md shrink-0 border border-emerald-150 flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        Zurückgegeben
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Digital Card & Quick Info */}
          <div className="space-y-8">
            
            {/* DIGITAL LIBRARY CARD */}
            <div className="bg-slate-950 text-white rounded-3xl border border-slate-850 p-6 shadow-md relative overflow-hidden flex flex-col justify-between min-h-[340px]">
              {/* Gradient card glow decoration */}
              <div className="absolute right-0 top-0 w-32 h-32 bg-indigo-600 rounded-full blur-3xl opacity-20 -translate-y-5 translate-x-5" />
              <div className="absolute left-0 bottom-0 w-32 h-32 bg-indigo-800 rounded-full blur-3xl opacity-15 translate-y-10 -translate-x-10" />

              {/* Card top banner */}
              <div className="relative z-10">
                <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="block text-[8px] tracking-widest text-indigo-400 font-extrabold leading-none uppercase">
                        Bibliotheks-Ausweis
                      </span>
                      <span className="text-xs font-extrabold tracking-tight text-white">
                        LesePortal Schulbibo
                      </span>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded">
                    AKTIV
                  </span>
                </div>

                {/* Member Identity Details */}
                <div className="space-y-3">
                  <div>
                    <span className="block text-[9px] text-slate-500 font-bold uppercase tracking-wider">
                      Name des Ausweisinhabers
                    </span>
                    <span className="text-sm font-black text-slate-100 block">
                      {currentUser.name}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="block text-[9px] text-slate-500 font-bold uppercase tracking-wider">
                        Rolle / Status
                      </span>
                      <span className="text-xs font-semibold text-slate-300 block">
                        {currentUser.role}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[9px] text-slate-500 font-bold uppercase tracking-wider">
                        {currentUser.role === "Schüler" ? "Klasse" : "Fächer"}
                      </span>
                      <span className="text-xs font-semibold text-slate-300 block truncate">
                        {currentUser.classOrSubject}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Barcode & Scanning slot */}
              <div className="relative z-10 pt-5 border-t border-slate-800/60 mt-4 text-center">
                <span className="block text-[9px] text-indigo-400 font-extrabold uppercase tracking-widest mb-2.5">
                  An der Theke einscannen lassen:
                </span>
                
                {/* Simulated high-quality visual Code-39 Barcode using flex divs for real visual scanner compatibility! */}
                <div className="bg-white p-3 rounded-xl inline-flex flex-col items-center justify-center w-full">
                  <div className="h-10 flex items-stretch gap-[2px] w-full max-w-[210px] bg-white">
                    {/* Unique pseudo-barcode representation of member ID */}
                    {Array.from({ length: 28 }).map((_, i) => {
                      const isBold = (i * 7 + 13) % 5 < 3;
                      const isGap = i % 4 === 0;
                      return (
                        <div 
                          key={i} 
                          className={`flex-1 ${
                            isGap 
                              ? "bg-transparent" 
                              : isBold 
                              ? "bg-slate-950 w-[3px]" 
                              : "bg-slate-900 w-[1px]"
                          }`} 
                        />
                      );
                    })}
                  </div>
                  <span className="text-[10px] font-mono font-black text-slate-900 mt-2 tracking-[4px]">
                    *{currentUser.memberId}*
                  </span>
                </div>

                <div className="flex items-center justify-center gap-1 mt-2.5 text-[9px] text-slate-400">
                  <Barcode className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                  <span>ID: {currentUser.memberId}</span>
                </div>
              </div>
            </div>

            {/* OPENING HOURS */}
            {openingHours && (
              <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-xs">
                <h4 className="font-bold text-gray-950 text-xs mb-3.5 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <span>Öffnungszeiten</span>
                </h4>
                <div className="space-y-2 text-xs text-gray-600">
                  <div className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-medium text-gray-500">Montag</span>
                    <span className="font-semibold text-gray-800">{openingHours.monday}</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-medium text-gray-500">Dienstag</span>
                    <span className="font-semibold text-gray-800">{openingHours.tuesday}</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-medium text-gray-500">Mittwoch</span>
                    <span className="font-semibold text-gray-800">{openingHours.wednesday}</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-medium text-gray-500">Donnerstag</span>
                    <span className="font-semibold text-gray-800">{openingHours.thursday}</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-medium text-gray-500">Freitag</span>
                    <span className="font-semibold text-gray-800">{openingHours.friday}</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-medium text-gray-500">Samstag</span>
                    <span className="font-semibold text-gray-400">{openingHours.saturday}</span>
                  </div>
                  <div className="flex justify-between items-center py-1">
                    <span className="font-medium text-gray-500">Sonntag</span>
                    <span className="font-semibold text-gray-400">{openingHours.sunday}</span>
                  </div>
                  {openingHours.additionalInfo && (
                    <div className="mt-2.5 p-2.5 bg-indigo-50/50 rounded-xl border border-indigo-100/50 text-[11px] text-slate-500 italic font-medium leading-relaxed">
                      {openingHours.additionalInfo}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* QUICK INFO FAQS */}
            <div className="bg-white rounded-3xl border border-gray-250 p-6 shadow-xs">
              <h4 className="font-bold text-gray-950 text-xs mb-3.5 uppercase tracking-wider flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-indigo-600" />
                <span>Bücherei FAQ & Regeln</span>
              </h4>
              <ul className="text-xs text-gray-600 space-y-2.5 leading-relaxed">
                <li className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl">
                  <span className="font-bold text-gray-800 block mb-0.5">Wie leihe ich Bücher aus?</span>
                  <span>Komme einfach mit diesem geöffneten Ausweis-Barcode an die Theke. Die Aufsicht scannt dich und dein Wunschbuch sofort ab.</span>
                </li>
                <li className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl">
                  <span className="font-bold text-gray-800 block mb-0.5">Wie lange darf ich Bücher behalten?</span>
                  <span>Schüler haben <strong>14 Tage</strong>, Lehrer haben <strong>28 Tage</strong> Leihfrist. Du kannst deine Fristen bei der Aufsicht verlängern lassen.</span>
                </li>
              </ul>
            </div>

          </div>
        </div>

        {/* SECTION 2: BROWSE BOOK CATALOG (Read-only for pupils/teachers) */}
        <div id="catalog-browse" className="bg-white rounded-3xl border border-gray-250 p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-lg font-black text-gray-950 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                <span>Bücher im Bestand stöbern ({books.length})</span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Sieh nach, welche Bücher im LesePortal verfügbar sind, um sie als nächstes auszuleihen.
              </p>
            </div>
          </div>

          {/* Search bar & filter pill buttons */}
          <div className="flex flex-col md:flex-row gap-3.5 mb-6">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Suche nach Titel, Autor oder ISBN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-gray-250 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all text-gray-900 font-medium placeholder-gray-400"
              />
            </div>

            {/* Genre Pill filters */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full">
              {genres.map((genre) => (
                <button
                  key={genre}
                  type="button"
                  onClick={() => setSelectedGenre(genre)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap shrink-0 border ${
                    selectedGenre === genre
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-2xs"
                      : "bg-slate-50 text-gray-600 border-gray-200 hover:bg-slate-100"
                  }`}
                >
                  {genre}
                </button>
              ))}
            </div>
          </div>

          {/* Results grid */}
          {filteredBooks.length === 0 ? (
            <div className="py-12 text-center text-gray-400 italic">
              Keine passenden Bücher im Bestand gefunden.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredBooks.map((book) => {
                const isAvailable = book.status === "available";
                return (
                  <div 
                    key={book.id} 
                    className="p-4 rounded-2xl border border-gray-150 bg-slate-50/30 hover:bg-white hover:border-indigo-150 transition-all shadow-2xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-indigo-50 border border-indigo-100 text-indigo-700">
                          {book.genre}
                        </span>
                        {isAvailable ? (
                          <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-150">
                            Verfügbar
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-amber-50 text-amber-700 border border-amber-150">
                            Ausgeliehen
                          </span>
                        )}
                      </div>

                      <h4 className="font-bold text-xs text-gray-950 line-clamp-1 leading-normal">
                        {book.title}
                      </h4>
                      <p className="text-[10px] text-gray-400 font-medium mt-0.5">
                        von {book.author}
                      </p>

                      {book.description && (
                        <p className="text-[10px] text-gray-500 mt-2 line-clamp-2 leading-relaxed">
                          {book.description}
                        </p>
                      )}
                    </div>

                    <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-[10px] text-gray-400 font-medium">
                      <span>ISBN: {book.isbn || "Keine"}</span>
                      <span>{book.pages} Seiten</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </main>
    </div>
  );
}
