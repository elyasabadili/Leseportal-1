import React, { useState } from "react";
import {
  BookOpen,
  UserCheck,
  AlertTriangle,
  Coins,
  RefreshCw,
  Calendar,
  ArrowRight,
  Download,
  TrendingUp,
  BarChart2,
  PieChart as PieIcon,
  Clock
} from "lucide-react";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  AreaChart,
  Area
} from "recharts";
import { Book, Loan, Member, LibraryUser, LibraryOpeningHours } from "../types";

interface DashboardOverviewProps {
  books: Book[];
  loans: Loan[];
  members: Member[];
  currentUser: LibraryUser;
  openingHours: LibraryOpeningHours | null;
  onSaveOpeningHours: (hours: LibraryOpeningHours) => void;
  onReturnBook: (loanId: string) => void;
  onExtendBook: (loanId: string, newDueDate: string) => void;
  onNavigateToTab: (tab: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  books,
  loans,
  members,
  currentUser,
  openingHours,
  onSaveOpeningHours,
  onReturnBook,
  onExtendBook,
  onNavigateToTab,
}) => {
  const [isEditingHours, setIsEditingHours] = useState(false);
  const totalBooks = books.length;
  const borrowedBooks = books.filter((b) => b.status === "borrowed").length;
  const totalMembers = members.length;

  // Active and overdue loans
  const activeLoans = loans.filter((l) => !l.returnDate);
  const overdueLoans = activeLoans.filter((l) => l.dueDate < "2026-06-24");

  // Sum of book values in stock
  const totalStockValue = books.reduce((sum, b) => sum + (b.price || 0), 0);

  const currentHours = openingHours || {
    schoolCode: currentUser.schoolCode,
    monday: "08:00 - 13:30",
    tuesday: "08:00 - 13:30",
    wednesday: "08:00 - 12:00",
    thursday: "08:00 - 13:30",
    friday: "08:00 - 13:00",
    saturday: "Geschlossen",
    sunday: "Geschlossen",
    additionalInfo: "In den großen Pausen geöffnet. Ausleihe und Rückgabe möglich."
  };

  // Extend loan function
  const handleExtend = (loan: Loan) => {
    // Generate new due date (standard extend is 14 days)
    const currentDueDate = new Date(loan.dueDate);
    currentDueDate.setDate(currentDueDate.getDate() + 14);
    const newDueDateStr = currentDueDate.toISOString().split("T")[0];
    onExtendBook(loan.id, newDueDateStr);
  };

  // CSV Data Export
  const handleExportCSV = () => {
    // CSV Header Definition
    const headers = [
      "ID/ISBN",
      "Titel",
      "Autor",
      "Kategorie/Genre",
      "Anschaffungspreis (EUR)",
      "Seitenanzahl",
      "Status",
      "Ausleiher-ID",
      "Ausleiher-Name",
      "Ausleiher-Rolle",
      "Ausleih-Datum",
      "Rückgabe-Sollfrist",
      "Rückgabe-Istdatum",
      "Verlängerungsanzahl",
      "Ausleihe-Status"
    ];

    // Build data rows for all books, including active or historical loans
    const rows = books.map((book) => {
      // Find the active loan or most recent loan for this book
      const activeLoan = loans.find((l) => l.bookId === book.id && !l.returnDate);
      
      return [
        `"${book.isbn || book.id}"`,
        `"${book.title.replace(/"/g, '""')}"`,
        `"${book.author.replace(/"/g, '""')}"`,
        `"${book.genre.replace(/"/g, '""')}"`,
        (book.price || 0).toFixed(2),
        book.pages || 0,
        book.status === "borrowed" ? "Ausgeliehen" : "Verfügbar",
        activeLoan ? `"${activeLoan.memberId}"` : '""',
        activeLoan ? `"${activeLoan.memberName.replace(/"/g, '""')}"` : '""',
        activeLoan ? `"${activeLoan.memberRole}"` : '""',
        activeLoan ? activeLoan.loanDate : '""',
        activeLoan ? activeLoan.dueDate : '""',
        activeLoan?.returnDate || '""',
        activeLoan ? activeLoan.extendedCount : 0,
        activeLoan ? activeLoan.status : '""'
      ];
    });

    // Generate CSV content using semicolons (highly compatible with Excel in German-speaking regions)
    const csvContent = [
      headers.join(";"),
      ...rows.map((row) => row.join(";"))
    ].join("\n");

    // Create a Blob with BOM for correct German Excel UTF-8 display (umlauts like ä, ö, ü)
    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `LesePortal_Daten_Export_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Group books by Genre for an elegant horizontal bar chart
  const genreCounts: Record<string, number> = {};
  books.forEach((b) => {
    genreCounts[b.genre] = (genreCounts[b.genre] || 0) + 1;
  });
  const genresSorted = Object.entries(genreCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // --- RECHARTS DATA PREPARATION ---
  
  // Custom interactive Tooltip component
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900/95 text-white p-3 rounded-xl border border-slate-800 shadow-xl text-xs font-sans backdrop-blur-xs">
          <p className="font-bold mb-1 text-slate-300">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center gap-2 mt-0.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color || entry.payload?.color || '#6366f1' }} />
              <span className="text-slate-400">{entry.name}:</span>
              <span className="font-mono font-bold text-white">{entry.value}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  // 1. Stock Status Donut Chart
  const availableCount = Math.max(0, totalBooks - borrowedBooks);
  const activeBorrowedCount = Math.max(0, borrowedBooks - overdueLoans.length);
  const overdueCount = overdueLoans.length;

  const stockStatusData = [
    { name: "Verfügbar", value: availableCount, color: "#10b981" }, // emerald-500
    { name: "Ausgeliehen", value: activeBorrowedCount, color: "#6366f1" }, // indigo-600
    { name: "Überfällig", value: overdueCount, color: "#f43f5e" }, // rose-500
  ].filter((item) => item.value > 0);

  // 2. Bar Chart Categories
  const genreChartData = Object.entries(genreCounts).map(([name, count]) => ({
    name,
    Bücher: count,
  }));
  const genreChartDataSorted = genreChartData
    .sort((a, b) => b.Bücher - a.Bücher)
    .slice(0, 5); // top 5 categories

  const otherGenresCount = genreChartData
    .sort((a, b) => b.Bücher - a.Bücher)
    .slice(5)
    .reduce((sum, item) => sum + item.Bücher, 0);

  if (otherGenresCount > 0) {
    genreChartDataSorted.push({ name: "Andere", Bücher: otherGenresCount });
  }

  // 3. Area Chart Loans Trend (past 7 days)
  const loansByDate: Record<string, number> = {};
  loans.forEach((l) => {
    if (l.loanDate) {
      loansByDate[l.loanDate] = (loansByDate[l.loanDate] || 0) + 1;
    }
  });

  const last7DaysData = [];
  const todayDate = new Date("2026-06-24"); // Aligned with the dashboard stand date
  for (let i = 6; i >= 0; i--) {
    const d = new Date(todayDate);
    d.setDate(todayDate.getDate() - i);
    const yyyymmdd = d.toISOString().split("T")[0];
    
    const parts = yyyymmdd.split("-");
    const label = `${parts[2]}.${parts[1]}`;
    const count = loansByDate[yyyymmdd] || 0;
    
    last7DaysData.push({
      date: label,
      "Ausleihen": count,
    });
  }

  return (
    <div className="space-y-6" id="dashboard-section">
      {/* Welcome Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Bibliotheks-Zentrale</h2>
          <p className="text-sm text-gray-500">
            Systemübersicht, fällige Rückgaben und Bestands-Statistiken für heute (24. Juni 2026)
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white px-3.5 py-2 rounded-xl border border-indigo-700 transition-colors shadow-2xs"
            title="Katalog und alle Ausleihen als CSV exportieren"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Daten exportieren (CSV)</span>
          </button>
          <div className="flex items-center gap-2 text-xs font-mono bg-slate-100 text-slate-700 px-3 py-2 rounded-xl border border-slate-200">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>STAND: 24.06.2026</span>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* KPI 1: Total Books */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-gray-500 uppercase tracking-wider">Gesamtbestand</span>
            <span className="text-2xl font-bold text-gray-900">{totalBooks}</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">Bücher im System</span>
          </div>
        </div>

        {/* KPI 2: Borrowed Books */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <RefreshCw className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <span className="block text-xs font-medium text-gray-500 uppercase tracking-wider">Ausgeliehen</span>
            <span className="text-2xl font-bold text-gray-900">{borrowedBooks}</span>
            <span className="block text-[10px] text-amber-600 font-semibold mt-0.5">
              {totalBooks > 0 ? Math.round((borrowedBooks / totalBooks) * 100) : 0}% Auslastung
            </span>
          </div>
        </div>

        {/* KPI 3: Members */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-teal-50 text-teal-600 rounded-xl">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-gray-500 uppercase tracking-wider">Karteninhaber</span>
            <span className="text-2xl font-bold text-gray-900">{totalMembers}</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">Schüler & Lehrer</span>
          </div>
        </div>

        {/* KPI 4: Overdue - High Contrast warning! */}
        <div className={`p-5 rounded-2xl border flex items-center gap-4 shadow-xs transition-colors ${
          overdueLoans.length > 0
            ? "bg-red-50/50 border-red-200 text-red-900"
            : "bg-white border-gray-200 text-gray-900"
        }`}>
          <div className={`p-3 rounded-xl ${
            overdueLoans.length > 0 ? "bg-red-100 text-red-600" : "bg-gray-100 text-gray-500"
          }`}>
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-gray-500 uppercase tracking-wider">Überfällig</span>
            <span className={`text-2xl font-bold ${overdueLoans.length > 0 ? "text-red-600 animate-pulse" : "text-gray-900"}`}>
              {overdueLoans.length}
            </span>
            <span className="block text-[10px] text-red-500 font-medium mt-0.5">
              {overdueLoans.length > 0 ? "SOFORT MAHNEN!" : "Keine Verzüge"}
            </span>
          </div>
        </div>

        {/* KPI 5: Total Value */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 flex items-center gap-4 shadow-xs">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-gray-500 uppercase tracking-wider">Anschaffungswert</span>
            <span className="text-2xl font-bold text-gray-900">{totalStockValue.toFixed(2)} €</span>
            <span className="block text-[10px] text-gray-400 mt-0.5">Investiertes Budget</span>
          </div>
        </div>

      </div>

      {/* Visuelle Grafiken und Analysen (Recharts) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="dashboard-charts-grid">
        
        {/* Card 1: Bestands- & Ausleihstatus */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
                <PieIcon className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-gray-800 text-sm">Bestands- & Ausleihstatus</h3>
            </div>
            <p className="text-[11px] text-gray-400 mb-4">Verfügbarkeit der Systembestände im Überblick</p>
          </div>
          
          <div className="relative h-[180px] flex items-center justify-center my-2">
            {totalBooks === 0 ? (
              <div className="text-center text-xs text-gray-400 font-medium">Keine Bücher im Bestand</div>
            ) : (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stockStatusData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={70}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {stockStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
                {/* Center text overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-2xl font-black text-gray-800 leading-none">{totalBooks}</span>
                  <span className="text-[9px] uppercase tracking-wider font-extrabold text-gray-400 mt-0.5">Bücher</span>
                </div>
              </>
            )}
          </div>

          {totalBooks > 0 && (
            <div className="flex flex-wrap justify-center gap-x-4 gap-y-1.5 mt-2 text-[10px] font-semibold border-t border-slate-50 pt-3">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 block" />
                <span className="text-gray-600">Frei ({availableCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 block" />
                <span className="text-gray-600">Verliehen ({activeBorrowedCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 block" />
                <span className="text-gray-600">Überfällig ({overdueCount})</span>
              </div>
            </div>
          )}
        </div>

        {/* Card 2: Top-Kategorien im Bestand */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                <BarChart2 className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-gray-800 text-sm">Top-Kategorien</h3>
            </div>
            <p className="text-[11px] text-gray-400 mb-4">Aufteilung des Gesamtbestands nach Buch-Genres</p>
          </div>

          <div className="h-[180px] flex items-center justify-center my-2">
            {totalBooks === 0 ? (
              <div className="text-center text-xs text-gray-400 font-medium">Keine Kategoriedaten</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={genreChartDataSorted} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f8fafc" vertical={false} />
                  <XAxis
                    dataKey="name"
                    tick={{ fill: '#64748b', fontSize: 9, fontWeight: 600 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: '#64748b', fontSize: 9, fontWeight: 600 }}
                    axisLine={false}
                    tickLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(99, 102, 241, 0.03)' }} />
                  <Bar dataKey="Bücher" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
          
          <div className="text-[10px] text-center text-gray-400 mt-2 border-t border-slate-50 pt-3 font-semibold">
            Bücheranzahl je Hauptgenre des LesePortals
          </div>
        </div>

        {/* Card 3: Ausleih-Entwicklung */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-2xs flex flex-col justify-between md:col-span-2 lg:col-span-1">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                <TrendingUp className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-gray-800 text-sm">Ausleih-Aktivität</h3>
            </div>
            <p className="text-[11px] text-gray-400 mb-4">Täglicher Verlauf der registrierten Ausleihen</p>
          </div>

          <div className="h-[180px] flex items-center justify-center my-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={last7DaysData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorAusleihen" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f8fafc" vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fill: '#64748b', fontSize: 9, fontWeight: 600 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: '#64748b', fontSize: 9, fontWeight: 600 }}
                  axisLine={false}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="Ausleihen"
                  stroke="#6366f1"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorAusleihen)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="text-[10px] text-center text-gray-400 mt-2 border-t border-slate-50 pt-3 font-semibold">
            Tagesaktuelle Registrierungen über die letzten 7 Tage
          </div>
        </div>

      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Active and Overdue Loans - Left Column (Colspan 2) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-200 shadow-xs overflow-hidden flex flex-col">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-slate-50">
            <div>
              <h3 className="font-semibold text-gray-900">Aktuelle Fälligkeiten & Ausleihen</h3>
              <p className="text-xs text-gray-500">Datenbank zur Verwaltung offener Bestände und Verzugsfristen</p>
            </div>
            <button
              onClick={() => onNavigateToTab("loans")}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 hover:underline"
            >
              Alle Ausleihen
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-6 flex-1">
            {activeLoans.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center text-gray-400">
                <BookOpen className="w-12 h-12 stroke-1 mb-3" />
                <p className="text-sm">Aktuell sind keine Bücher ausgeliehen.</p>
                <button
                  onClick={() => onNavigateToTab("loans")}
                  className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium rounded-lg transition-colors"
                >
                  Buch ausleihen
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr className="border-b border-gray-100 text-xs text-gray-400 uppercase font-semibold">
                      <th className="pb-3">Buch</th>
                      <th className="pb-3">Ausleiher</th>
                      <th className="pb-3">Rückgabe am</th>
                      <th className="pb-3">Status</th>
                      <th className="pb-3 text-right">Aktion</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {activeLoans.map((loan) => {
                      const isOverdue = loan.dueDate < "2026-06-24";
                      return (
                        <tr key={loan.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-3.5 font-medium text-gray-900 pr-3">
                            <div className="max-w-[200px] truncate" title={loan.bookTitle}>
                              {loan.bookTitle}
                            </div>
                          </td>
                          <td className="py-3.5 text-gray-600">
                            <div className="flex flex-col">
                              <span className="font-semibold text-xs">{loan.memberName}</span>
                              <span className="text-[10px] text-gray-400">
                                {loan.memberRole} • {loan.memberId}
                              </span>
                            </div>
                          </td>
                          <td className="py-3.5 font-mono text-xs">
                            {loan.dueDate.split("-").reverse().join(".")}
                          </td>
                          <td className="py-3.5">
                            {isOverdue ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-100 text-red-800 animate-pulse">
                                Überfällig
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-green-100 text-green-800">
                                Aktiv
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => handleExtend(loan)}
                              className="px-2 py-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 border border-indigo-200 hover:border-indigo-300 rounded transition-colors"
                              title="Frist um 14 Tage verlängern"
                            >
                              Frist +14 Tage
                            </button>
                            <button
                              onClick={() => onReturnBook(loan.id)}
                              className="px-2 py-1 text-[11px] font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded transition-colors"
                              title="Buch zurückgeben"
                            >
                              Zurückgeben
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Genre statistics and Quick Links - Right Column */}
        <div className="space-y-6">
          
          {/* Genre statistics */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-xs p-6 flex flex-col">
            <h3 className="font-semibold text-gray-900 mb-1">Kategorie-Verteilung</h3>
            <p className="text-xs text-gray-500 mb-4">Aufteilung der Bücher im Bestand</p>

            {books.length === 0 ? (
              <p className="text-xs text-gray-400 text-center py-6">Keine Bücher vorhanden</p>
            ) : (
              <div className="space-y-3.5">
                {genresSorted.map(([genre, count]) => {
                  const percentage = Math.round((count / totalBooks) * 100);
                  return (
                    <div key={genre} className="space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-medium text-gray-700">{genre}</span>
                        <span className="text-gray-500 font-mono font-semibold">
                          {count} ({percentage}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Öffnungszeiten Card */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-xs p-6 flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 text-sm">Bibliotheks-Öffnungszeiten</h3>
                  <p className="text-[10px] text-gray-400">Reguläre Zeiten für Ausleihe & Rückgabe</p>
                </div>
              </div>
              
              {currentUser.role === "Bücherei-Lehrer/in" && (
                <button
                  onClick={() => setIsEditingHours(true)}
                  className="px-2.5 py-1 hover:bg-indigo-50 border border-indigo-150 hover:border-indigo-200 text-indigo-600 rounded-lg transition-colors font-semibold text-xs flex items-center gap-1"
                  title="Öffnungszeiten bearbeiten"
                >
                  Ändern
                </button>
              )}
            </div>

            <div className="space-y-2 text-xs text-gray-600">
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="font-medium text-gray-500">Montag</span>
                <span className="font-semibold text-gray-800">{currentHours.monday}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="font-medium text-gray-500">Dienstag</span>
                <span className="font-semibold text-gray-800">{currentHours.tuesday}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="font-medium text-gray-500">Mittwoch</span>
                <span className="font-semibold text-gray-800">{currentHours.wednesday}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="font-medium text-gray-500">Donnerstag</span>
                <span className="font-semibold text-gray-800">{currentHours.thursday}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="font-medium text-gray-500">Freitag</span>
                <span className="font-semibold text-gray-800">{currentHours.friday}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="font-medium text-gray-500">Samstag</span>
                <span className="font-semibold text-gray-400">{currentHours.saturday}</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="font-medium text-gray-500">Sonntag</span>
                <span className="font-semibold text-gray-400">{currentHours.sunday}</span>
              </div>

              {currentHours.additionalInfo && (
                <div className="mt-3 p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-[11px] text-slate-500 italic font-medium leading-relaxed">
                  {currentHours.additionalInfo}
                </div>
              )}
            </div>
          </div>

          {/* Quick-Guide cards */}
          <div className="bg-slate-900 text-white rounded-2xl shadow-xs p-6 flex flex-col justify-between border border-slate-800">
            <div>
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mb-2">
                Echtes Ausleihen im Alltag
              </span>
              <h4 className="font-semibold text-base mb-1.5">Ausweise drucken & scannen</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Füge Schüler oder Lehrer im Reiter <strong>"Karten/Mitglieder"</strong> hinzu. Die Software generiert sofort einen individuellen Ausweis inklusive Barcode zum Ausdrucken. Diesen Barcode kannst du an der Theke direkt abscannen!
              </p>
            </div>
            <button
              onClick={() => onNavigateToTab("members")}
              className="mt-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold rounded-lg text-center transition-colors self-start"
            >
              Mitgliedskarten ansehen
            </button>
          </div>

        </div>

      </div>

      {/* Edit Opening Hours Modal */}
      {isEditingHours && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-3xl border border-gray-200 shadow-xl max-w-lg w-full overflow-hidden animate-slide-up">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-gray-150 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Clock className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Öffnungszeiten festlegen</h3>
              </div>
              <button
                onClick={() => setIsEditingHours(false)}
                className="text-gray-400 hover:text-gray-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {/* Modal Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const updated: LibraryOpeningHours = {
                  schoolCode: currentUser.schoolCode,
                  monday: (formData.get("monday") as string) || "Geschlossen",
                  tuesday: (formData.get("tuesday") as string) || "Geschlossen",
                  wednesday: (formData.get("wednesday") as string) || "Geschlossen",
                  thursday: (formData.get("thursday") as string) || "Geschlossen",
                  friday: (formData.get("friday") as string) || "Geschlossen",
                  saturday: (formData.get("saturday") as string) || "Geschlossen",
                  sunday: (formData.get("sunday") as string) || "Geschlossen",
                  additionalInfo: (formData.get("additionalInfo") as string) || "",
                };
                onSaveOpeningHours(updated);
                setIsEditingHours(false);
              }}
              className="p-6 space-y-4"
            >
              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Montag</label>
                  <input
                    type="text"
                    name="monday"
                    defaultValue={currentHours.monday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. 08:00 - 13:30"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Dienstag</label>
                  <input
                    type="text"
                    name="tuesday"
                    defaultValue={currentHours.tuesday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. 08:00 - 13:30"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Mittwoch</label>
                  <input
                    type="text"
                    name="wednesday"
                    defaultValue={currentHours.wednesday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. 08:00 - 12:00"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Donnerstag</label>
                  <input
                    type="text"
                    name="thursday"
                    defaultValue={currentHours.thursday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. 08:00 - 13:30"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Freitag</label>
                  <input
                    type="text"
                    name="friday"
                    defaultValue={currentHours.friday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. 08:00 - 13:00"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Samstag</label>
                  <input
                    type="text"
                    name="saturday"
                    defaultValue={currentHours.saturday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. Geschlossen"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Sonntag</label>
                  <input
                    type="text"
                    name="sunday"
                    defaultValue={currentHours.sunday}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium"
                    placeholder="z.B. Geschlossen"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-1">Zusätzliche Hinweise</label>
                <textarea
                  name="additionalInfo"
                  defaultValue={currentHours.additionalInfo}
                  rows={2}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white text-gray-800 font-medium resize-none"
                  placeholder="z.B. In den Schulferien geschlossen. Sonder-Ausleihen nach Absprache."
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsEditingHours(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-500 hover:text-gray-700 hover:bg-slate-50 rounded-xl transition-colors"
                >
                  Abbrechen
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors"
                >
                  Speichern
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
