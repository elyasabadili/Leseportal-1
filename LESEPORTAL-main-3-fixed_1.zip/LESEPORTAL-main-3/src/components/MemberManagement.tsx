import React, { useState } from "react";
import { UserPlus, Search, Trash2, Printer, CreditCard, Check, Sparkles, X, Info, Settings, Eye, HelpCircle } from "lucide-react";
import { Member } from "../types";
import { Barcode } from "../utils/barcode";

interface MemberManagementProps {
  members: Member[];
  onAddMember: (member: Member) => void;
  onDeleteMember: (id: string) => void;
}

// Print Card Component for modular rendering
const PrintCard: React.FC<{
  member: Member;
  style: "dark" | "light" | "barcode-only";
  layout: "a4-8" | "a4-15" | "single";
  showCutLines: boolean;
}> = ({ member, style, layout, showCutLines }) => {
  const isDark = style === "dark";
  const isBarcodeOnly = style === "barcode-only";

  // Dimensions and padding based on layout selection
  let cardClass = "";
  let widthMm = 85;
  let heightMm = 54;
  let paddingClass = "p-4";

  if (layout === "a4-8") {
    cardClass = "w-[85mm] h-[54mm]";
    widthMm = 85;
    heightMm = 54;
    paddingClass = "p-3 sm:p-4";
  } else if (layout === "a4-15") {
    cardClass = "w-[60mm] h-[40mm]";
    widthMm = 60;
    heightMm = 40;
    paddingClass = "p-2";
  } else {
    cardClass = "w-[100mm] h-[60mm]";
    widthMm = 100;
    heightMm = 60;
    paddingClass = "p-5";
  }

  // Visual themes
  let bgClass = "bg-white border";
  let textClass = "text-slate-900";
  let subtitleClass = "text-slate-500";
  let idBadgeClass = "bg-slate-100 text-slate-700";

  if (isDark) {
    bgClass = "bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 text-white border border-slate-800 shadow-sm";
    textClass = "text-white";
    subtitleClass = "text-indigo-300";
    idBadgeClass = "bg-indigo-900/60 text-indigo-200 border border-indigo-700/50";
  } else if (isBarcodeOnly) {
    bgClass = "bg-white border-2 border-black";
    textClass = "text-black";
    subtitleClass = "text-black";
    idBadgeClass = "border border-black text-black font-bold";
  } else {
    // Elegant light
    bgClass = "bg-white border border-slate-300 shadow-2xs";
    textClass = "text-slate-900";
    subtitleClass = "text-slate-500 font-medium";
    idBadgeClass = "bg-indigo-50 text-indigo-700 border border-indigo-100 font-semibold";
  }

  return (
    <div 
      className={`box-border relative rounded-xl flex flex-col justify-between overflow-hidden shadow-xs shrink-0 ${cardClass} ${bgClass} ${paddingClass}`}
      style={{
        width: `${widthMm}mm`,
        height: `${heightMm}mm`,
        borderStyle: showCutLines ? "dashed" : "solid",
        borderColor: showCutLines ? (isBarcodeOnly ? "#000000" : "rgba(239, 68, 68, 0.5)") : undefined,
        borderWidth: showCutLines ? "1.2px" : "1px",
      }}
    >
      {/* Visual mesh overlay for premium dark theme */}
      {isDark && (
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-white/5 rounded-full pointer-events-none" />
      )}

      {/* Header */}
      <div className="flex items-start justify-between w-full shrink-0 border-b pb-1.5" style={{ borderColor: isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)" }}>
        <div>
          <span className={`block font-extrabold uppercase tracking-widest text-[7px] leading-none ${isDark ? "text-indigo-400" : "text-indigo-600"}`}>
            Schulbibliothek
          </span>
          <h4 className={`font-bold uppercase tracking-wider text-[10px] mt-0.5 leading-none ${textClass}`}>
            Bibliotheksausweis
          </h4>
        </div>
        <span className={`font-mono text-[9px] px-1.5 py-0.5 rounded leading-none ${idBadgeClass}`}>
          {member.id}
        </span>
      </div>

      {/* Body details */}
      <div className="flex items-center gap-2.5 py-1 flex-1 min-h-0">
        {!isBarcodeOnly && (
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-base shrink-0 border ${
            isDark ? "bg-white/10 border-white/10" : "bg-slate-50 border-slate-200"
          }`}>
            {member.role === "Lehrer" ? "👨‍🏫" : "🎒"}
          </div>
        )}
        <div className="flex-1 min-w-0 leading-tight">
          <span className={`block font-extrabold truncate text-[11px] uppercase ${textClass}`}>
            {member.name}
          </span>
          <span className={`block text-[9px] font-semibold mt-0.5 capitalize ${subtitleClass}`}>
            {member.role}
          </span>
          <span className={`block text-[9px] truncate ${subtitleClass}`}>
            {member.classOrSubject}
          </span>
        </div>
      </div>

      {/* Code-39 Barcode block - always white inside card for clean laser reflection */}
      <div className="bg-white p-1 rounded h-11 shrink-0 flex items-center justify-center select-none overflow-hidden shadow-2xs">
        <Barcode value={member.id} height={22} showText={false} />
      </div>
    </div>
  );
};

export const MemberManagement: React.FC<MemberManagementProps> = ({
  members,
  onAddMember,
  onDeleteMember,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");

  // Form states
  const [name, setName] = useState("");
  const [role, setRole] = useState<"Schüler" | "Lehrer">("Schüler");
  const [classOrSubject, setClassOrSubject] = useState("");

  // Print Desk states
  const [showPrintCenter, setShowPrintCenter] = useState(false);
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [printLayout, setPrintLayout] = useState<"a4-8" | "a4-15" | "single">("a4-8");
  const [printStyle, setPrintStyle] = useState<"dark" | "light" | "barcode-only">("dark");
  const [showCutLines, setShowCutLines] = useState(true);
  const [showPrintPreview, setShowPrintPreview] = useState(false);

  // Single card viewing state (for backwards compatibility with existing design)
  const [selectedCardMember, setSelectedCardMember] = useState<Member | null>(null);

  const resetForm = () => {
    setName("");
    setRole("Schüler");
    setClassOrSubject("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !classOrSubject) return;

    // Generate unique ID
    const prefix = role === "Schüler" ? "S" : "L";
    const randomNumber = Math.floor(10000 + Math.random() * 90000);
    const memberId = `${prefix}-${randomNumber}`;

    const newMember: Member = {
      id: memberId,
      name,
      role,
      classOrSubject,
      barcode: memberId,
      createdAt: new Date().toISOString(),
    };

    onAddMember(newMember);
    resetForm();
    setShowAddForm(false);
    
    // Auto open card preview for the newly added user to make it feel super interactive and responsive!
    setSelectedCardMember(newMember);
  };

  // Filter members
  const filteredMembers = members.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.classOrSubject.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole = roleFilter === "All" || m.role === roleFilter;

    return matchesSearch && matchesRole;
  });

  // Toggle selection for bulk print
  const toggleMemberSelection = (id: string) => {
    if (selectedMemberIds.includes(id)) {
      setSelectedMemberIds(selectedMemberIds.filter((item) => item !== id));
    } else {
      setSelectedMemberIds([...selectedMemberIds, id]);
    }
  };

  // Mass actions
  const handleSelectAllFiltered = () => {
    const filteredIds = filteredMembers.map((m) => m.id);
    setSelectedMemberIds(Array.from(new Set([...selectedMemberIds, ...filteredIds])));
  };

  const handleSelectAllSchueler = () => {
    const schuelerIds = filteredMembers.filter((m) => m.role === "Schüler").map((m) => m.id);
    setSelectedMemberIds(Array.from(new Set([...selectedMemberIds, ...schuelerIds])));
  };

  const handleSelectAllLehrer = () => {
    const lehrerIds = filteredMembers.filter((m) => m.role === "Lehrer").map((m) => m.id);
    setSelectedMemberIds(Array.from(new Set([...selectedMemberIds, ...lehrerIds])));
  };

  const handleClearSelection = () => {
    setSelectedMemberIds([]);
  };

  // Printing engine
  const handleTriggerPrint = () => {
    // Check if the application is running inside an iframe
    const isIframe = window.self !== window.top;

    if (!isIframe) {
      try {
        window.print();
        return;
      } catch (e) {
        console.warn("Direct print failed, trying window.open fallback...", e);
      }
    }

    // Fallback for iframe environment: Open in a new tab/window and print
    const printContent = document.getElementById("print-area")?.innerHTML;
    const styleElements = Array.from(document.querySelectorAll("style, link[rel='stylesheet']"))
      .map((el) => el.outerHTML)
      .join("\n");

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert(
        "Der Browser blockiert das direkte Drucken aus der Vorschau-Umgebung.\n\nBitte klicken Sie oben rechts in der App auf den blauen Button 'In neuem Tab öffnen' (Open in New Tab), um die Ausweise problemlos zu drucken, oder erlauben Sie Popups für diese Seite in Ihren Browsereinstellungen!"
      );
      return;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Ausweise Drucken - Schulbibliothek</title>
          ${styleElements}
          <style>
            /* Make print elements visible on screen in the new window for layout confirmation */
            #print-area, .print-sheet {
              display: grid !important;
              visibility: visible !important;
            }
            body {
              background: #f8fafc;
              margin: 0;
              padding: 24px;
              display: flex;
              flex-direction: column;
              align-items: center;
              font-family: system-ui, -apple-system, sans-serif;
            }
            .print-sheet {
              background: white !important;
              box-shadow: 0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -4px rgba(0,0,0,0.08);
              margin-bottom: 30px !important;
              border-radius: 12px;
              border: 1px solid #e2e8f0;
              box-sizing: border-box;
            }
            @media print {
              body {
                background: white;
                padding: 0;
              }
              .print-sheet {
                box-shadow: none;
                margin-bottom: 0 !important;
                border-radius: 0;
                border: none;
              }
              .no-print {
                display: none !important;
              }
            }
          </style>
        </head>
        <body>
          <div style="background: #ffffff; padding: 14px 28px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 24px; max-width: 600px; text-align: center; font-size: 13px; color: #334155; box-shadow: 0 1px 3px rgba(0,0,0,0.05);" class="no-print">
            <strong style="color: #4f46e5;">Druck-Vorschau aktiv!</strong> Falls sich der Druckdialog nicht automatisch geöffnet hat, drücken Sie bitte <kbd style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-family: monospace; border: 1px solid #cbd5e1; font-weight: bold;">Strg + P</kbd> (Windows) oder <kbd style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-family: monospace; border: 1px solid #cbd5e1; font-weight: bold;">Cmd + P</kbd> (Mac).
          </div>
          <div id="print-area">
            ${printContent}
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 450);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Backward compatible print function for individual cards
  const handlePrintCard = () => {
    if (!selectedCardMember) return;
    
    // Set parameters to standard individual print
    setSelectedMemberIds([selectedCardMember.id]);
    setPrintLayout("single");
    setPrintStyle("dark");
    setShowCutLines(false);
    setShowPrintPreview(true);
    setSelectedCardMember(null); // Close the preview modal
  };

  // Paginate selected members for print layouts
  const getSelectedMembers = () => {
    return members.filter((m) => selectedMemberIds.includes(m.id));
  };

  const chunkArray = <T,>(arr: T[], size: number): T[][] => {
    const chunks: T[][] = [];
    for (let i = 0; i < arr.length; i += size) {
      chunks.push(arr.slice(i, i + size));
    }
    return chunks;
  };

  const selectedMembersList = getSelectedMembers();
  
  // Choose page sizes based on layout
  const pageSizeMap = {
    "a4-8": 8,   // 2 columns, 4 rows
    "a4-15": 15, // 3 columns, 5 rows
    "single": 1, // 1 label per page
  };
  const printPageSize = pageSizeMap[printLayout];
  const printPages = chunkArray<Member>(selectedMembersList, printPageSize);

  return (
    <div className="space-y-6">
      
      {/* Styling injection for printing sheet page layout alignment */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          /* Hide main app elements completely */
          body * {
            visibility: hidden !important;
          }
          /* Show print area container only */
          #print-area, #print-area * {
            visibility: visible !important;
          }
          #print-area {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 210mm !important;
            margin: 0 !important;
            padding: 0 !important;
            background: white !important;
          }
          @page {
            size: A4;
            margin: 0;
          }
          /* Standard A4 layout template page */
          .print-sheet {
            width: 210mm !important;
            height: 297mm !important;
            padding: 15mm 12mm !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            page-break-after: always !important;
            background: white !important;
            overflow: hidden !important;
            display: grid !important;
            align-content: start !important;
            justify-content: center !important;
          }
          .print-sheet-grid-8 {
            grid-template-columns: 85mm 85mm !important;
            gap: 12mm 14mm !important;
          }
          .print-sheet-grid-15 {
            grid-template-columns: 60mm 60mm 60mm !important;
            gap: 8mm 6mm !important;
            padding: 12mm 10mm !important;
          }
          .print-sheet-single {
            width: 100mm !important;
            height: 60mm !important;
            padding: 4mm !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            page-break-after: always !important;
            background: white !important;
            overflow: hidden !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
          }
          .print-sheet:last-child, .print-sheet-single:last-child {
            page-break-after: avoid !important;
          }
          /* For browsers to print colors and backgrounds exactly as styled */
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `}} />

      {/* Header / Title area */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Karten & Mitglieder</h2>
          <p className="text-sm text-gray-500">
            Ausweise für Schüler und Lehrer anlegen, verwalten und mit scannbarem Barcode ausdrucken.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => {
              setShowPrintCenter(!showPrintCenter);
              if (!showPrintCenter) {
                // Clear selection on open
                setSelectedMemberIds([]);
              }
            }}
            className={`px-4 py-2.5 font-semibold text-sm rounded-xl transition-all shadow-xs flex items-center gap-2 border ${
              showPrintCenter
                ? "bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100"
                : "bg-white hover:bg-slate-50 border-gray-200 text-gray-700"
            }`}
          >
            <Printer className="w-4 h-4" />
            <span>{showPrintCenter ? "Druck-Zentrum schließen" : "Ausweis-Druckzentrum"}</span>
          </button>
          <button
            onClick={() => {
              resetForm();
              setShowAddForm(!showAddForm);
            }}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-xl transition-all shadow-xs flex items-center gap-2 active:scale-98"
          >
            <UserPlus className="w-4 h-4" />
            <span>{showAddForm ? "Formular schließen" : "Mitglied hinzufügen"}</span>
          </button>
        </div>
      </div>

      {/* Quick help banner inside print mode */}
      {showPrintCenter && (
        <div className="bg-indigo-50 border border-indigo-100/80 rounded-2xl p-4 flex gap-3.5 items-start">
          <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-bold text-indigo-950 text-xs">Massen-Druckmodus ist aktiv</h4>
            <p className="text-xs text-indigo-800 leading-relaxed">
              Klicke auf die Mitgliederkarten unten, um sie für das Drucken auszuwählen oder wieder abzuwählen. Nutze das Einstellungsfeld darunter, um das Druck-Layout zu konfigurieren und einen scannbaren A4-Druckbogen zu generieren.
            </p>
          </div>
        </div>
      )}

      {/* Manual Add Member Form */}
      {showAddForm && (
        <div className="bg-slate-50 p-6 rounded-2xl border border-gray-200 shadow-inner">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-indigo-600" />
            <span>Neues Bibliotheksmitglied anlegen</span>
          </h3>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Vollständiger Name *</label>
              <input
                type="text"
                required
                placeholder="Vor- und Nachname"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Rolle / Status</label>
              <div className="flex bg-gray-100 p-1 rounded-lg border border-gray-200">
                <button
                  type="button"
                  onClick={() => setRole("Schüler")}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-colors ${
                    role === "Schüler" ? "bg-white text-gray-900 shadow-xs" : "text-gray-500"
                  }`}
                >
                  Schüler
                </button>
                <button
                  type="button"
                  onClick={() => setRole("Lehrer")}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-colors ${
                    role === "Lehrer" ? "bg-white text-gray-900 shadow-xs" : "text-gray-500"
                  }`}
                >
                  Lehrer
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                {role === "Schüler" ? "Klasse / Klassenstufe *" : "Unterrichtete Fächer *"}
              </label>
              <input
                type="text"
                required
                placeholder={role === "Schüler" ? "z.B. Klasse 9b" : "z.B. Deutsch, Englisch"}
                value={classOrSubject}
                onChange={(e) => setClassOrSubject(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none"
              />
            </div>
            <div className="sm:col-span-3 flex justify-end gap-2 mt-2">
              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setShowAddForm(false);
                }}
                className="px-4 py-2 text-sm text-gray-700 bg-white hover:bg-gray-100 border border-gray-300 rounded-lg"
              >
                Abbrechen
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                Registrieren & Karte generieren
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Advanced Print Control Desk (Druck-Zentrum) Option Panel */}
      {showPrintCenter && (
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-5 shadow-xs animate-fade-in">
          
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-xs shrink-0">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Ausweis-Druck konfigurieren</h3>
                <p className="text-xs text-slate-500">
                  {selectedMemberIds.length} von {members.length} Mitgliedern für den Druckvorgang ausgewählt.
                </p>
              </div>
            </div>
            
            {/* Bulk Selection Helpers */}
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={handleSelectAllFiltered}
                className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
              >
                Alle gefilterten ({filteredMembers.length})
              </button>
              <button
                type="button"
                onClick={handleSelectAllSchueler}
                className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
              >
                Nur Schüler
              </button>
              <button
                type="button"
                onClick={handleSelectAllLehrer}
                className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
              >
                Nur Lehrer
              </button>
              <button
                type="button"
                onClick={handleClearSelection}
                className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
              >
                Auswahl aufheben
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-slate-200">
            
            {/* Format Selector */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider">
                Druck-Format / Bogen-Einteilung
              </label>
              <select
                value={printLayout}
                onChange={(e: any) => setPrintLayout(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="a4-8">A4-Bogen (8 Ausweise, 2x4 Raster)</option>
                <option value="a4-15">A4-Bogen (15 Etiketten, 3x5 Raster)</option>
                <option value="single">Einzelausweis / Label-Rolle</option>
              </select>
            </div>

            {/* Style Design Selector */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider">
                Layout / Visuelles Design
              </label>
              <select
                value={printStyle}
                onChange={(e: any) => setPrintStyle(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="dark">Premium Cosmic (Dunkel)</option>
                <option value="light">Klassisch Light (Tintensparend)</option>
                <option value="barcode-only">Reiner Barcode (S/W-Etikett)</option>
              </select>
            </div>

            {/* Cut marks Checkbox */}
            <div className="flex flex-col justify-end">
              <div className="flex items-center gap-2 h-9">
                <input
                  type="checkbox"
                  id="cut-lines-checkbox"
                  checked={showCutLines}
                  onChange={(e) => setShowCutLines(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 cursor-pointer"
                />
                <label htmlFor="cut-lines-checkbox" className="text-xs font-bold text-slate-700 cursor-pointer">
                  Schneidelinien (Schnittlinien)
                </label>
              </div>
            </div>

            {/* Submit Action */}
            <div className="flex items-end">
              <button
                type="button"
                disabled={selectedMemberIds.length === 0}
                onClick={() => setShowPrintPreview(true)}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-bold rounded-lg shadow-xs flex items-center justify-center gap-2 transition-all"
              >
                <Eye className="w-4 h-4" />
                <span>Druckvorschau öffnen ({selectedMemberIds.length})</span>
              </button>
            </div>
          </div>

        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-white p-4 rounded-xl border border-gray-200">
        <div className="sm:col-span-2 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Name, Klasse, Fächer oder ID suchen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none placeholder-gray-400 bg-white"
          />
        </div>
        <div>
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none bg-white"
          >
            <option value="All">Alle Statusgruppen</option>
            <option value="Schüler">Nur Schüler</option>
            <option value="Lehrer">Nur Lehrer</option>
          </select>
        </div>
      </div>

      {/* Grid of Members Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map((member) => {
          const isSelected = selectedMemberIds.includes(member.id);
          
          return (
            <div
              key={member.id}
              onClick={() => {
                if (showPrintCenter) {
                  toggleMemberSelection(member.id);
                }
              }}
              className={`relative bg-white rounded-2xl border transition-all p-5 flex flex-col justify-between group ${
                showPrintCenter ? "cursor-pointer select-none" : ""
              } ${
                showPrintCenter && isSelected
                  ? "ring-2 ring-indigo-600 border-indigo-200 bg-indigo-50/10"
                  : "border-gray-200 shadow-xs hover:shadow-md hover:border-indigo-100"
              }`}
            >
              {/* Checkbox overlay in print selection mode */}
              {showPrintCenter && (
                <div className="absolute top-4 right-4 z-10">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={(e) => {
                      e.stopPropagation(); // Prevent duplicate card toggle event
                      toggleMemberSelection(member.id);
                    }}
                    className="w-5 h-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 cursor-pointer"
                  />
                </div>
              )}

              {/* Top area details */}
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg ${
                      member.role === "Lehrer" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                    }`}>
                      {member.role === "Lehrer" ? "👨‍🏫" : "🎒"}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-950 group-hover:text-indigo-600 transition-colors">
                        {member.name}
                      </h4>
                      <span className="inline-block text-[10px] uppercase font-bold text-gray-400">
                        {member.role} • {member.classOrSubject}
                      </span>
                    </div>
                  </div>
                  {/* Hide original ID block if print checkbox is active to avoid overlapping */}
                  {!showPrintCenter && (
                    <span className="font-mono text-xs text-gray-400 bg-slate-50 px-2 py-1 rounded">
                      {member.id}
                    </span>
                  )}
                </div>

                {/* Barcode snapshot representation */}
                <div className="mt-4 p-2.5 bg-slate-50 rounded-xl border border-dashed border-gray-200 flex flex-col items-center justify-center h-20 overflow-hidden select-none">
                  <div id={`barcode-${member.id}`} className="scale-85 origin-center">
                    <Barcode value={member.id} height={35} showText={false} />
                  </div>
                  <span className="text-[10px] font-mono text-gray-400 mt-1">{member.id}</span>
                </div>
              </div>

              {/* Bottom panel actions */}
              <div className="flex items-center justify-between border-t border-gray-100 pt-3.5 mt-4">
                <button
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent toggling selection
                    setSelectedCardMember(member);
                  }}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 hover:underline"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  Ausweis anzeigen
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent toggling selection
                    onDeleteMember(member.id);
                  }}
                  className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Mitglied löschen"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Backward compatible individual Card Preview Modal */}
      {selectedCardMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 flex flex-col">
            
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-semibold text-gray-900">Bibliotheksausweis drucken</h3>
              <button
                onClick={() => setSelectedCardMember(null)}
                className="p-1 hover:bg-gray-100 text-gray-500 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body showing visual preview card */}
            <div className="p-6 flex flex-col items-center justify-center bg-slate-100">
              
              {/* Printable container design card */}
              <div className="w-full max-w-[360px] aspect-[1.7/1] bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 text-white rounded-xl shadow-lg p-5 flex flex-col justify-between relative overflow-hidden border border-slate-800">
                {/* Visual mesh */}
                <div className="absolute -top-12 -right-12 w-28 h-28 bg-white/3 rounded-full pointer-events-none" />

                {/* Card header */}
                <div className="flex items-start justify-between border-b border-white/10 pb-2">
                  <div>
                    <span className="block text-[8px] uppercase tracking-widest text-indigo-400 font-extrabold">
                      Schulbibliothek
                    </span>
                    <h4 className="text-xs font-bold uppercase tracking-wider">
                      Bibliotheksausweis
                    </h4>
                  </div>
                  <span className="font-mono text-[9px] bg-slate-800/80 px-1.5 py-0.5 rounded text-slate-300">
                    {selectedCardMember.id}
                  </span>
                </div>

                {/* Card info */}
                <div className="flex items-center gap-3.5 py-2">
                  <div className="w-11 h-11 bg-white/10 border border-white/20 rounded-lg flex items-center justify-center text-xl shadow-inner">
                    {selectedCardMember.role === "Lehrer" ? "👨‍🏫" : "🎒"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block font-bold text-sm truncate">{selectedCardMember.name}</span>
                    <span className="block text-[10px] text-slate-300 capitalize">{selectedCardMember.role}</span>
                    <span className="block text-[10px] text-slate-400 truncate">{selectedCardMember.classOrSubject}</span>
                  </div>
                </div>

                {/* Card barcode */}
                <div className="bg-white p-1 rounded-md h-11 overflow-hidden flex items-center justify-center select-none shadow-xs mt-1">
                  <Barcode value={selectedCardMember.id} height={25} showText={false} />
                </div>
              </div>

            </div>

            {/* Modal actions */}
            <div className="px-6 py-4 border-t border-gray-100 bg-slate-50 flex justify-between">
              <span className="text-[10px] text-gray-400 flex items-center gap-1">
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                Code 39 konform & scannbar
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedCardMember(null)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Schließen
                </button>
                <button
                  onClick={handlePrintCard}
                  className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  Druckvorschau
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* New Interactive WYSIWYG Print Preview Overlay Modal */}
      {showPrintPreview && (
        <div className="fixed inset-0 z-50 bg-slate-900/90 backdrop-blur-xs overflow-y-auto flex items-start justify-center p-4 md:p-8">
          <div className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden my-auto max-h-[90vh]">
            
            {/* Modal Header Controls */}
            <div className="px-6 py-4 border-b border-gray-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
              <div>
                <h3 className="font-extrabold text-slate-900 flex items-center gap-2">
                  <Printer className="w-5 h-5 text-indigo-600" />
                  <span>Druckbogen-Vorschau (WYSIWYG)</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Überprüfe die Seitenaufteilung. Ausgewählt: <strong>{selectedMemberIds.length} Ausweise</strong> ({printPages.length} Seite/n)
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setShowPrintPreview(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-700 bg-white hover:bg-gray-100 border border-gray-300 rounded-lg transition-colors"
                >
                  Schließen / Anpassen
                </button>
                <button
                  onClick={handleTriggerPrint}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  Drucken starten
                </button>
              </div>
            </div>

            {/* Main view split pane */}
            <div className="flex-1 overflow-y-auto p-6 bg-slate-100 flex flex-col lg:flex-row gap-6">
              
              {/* Settings checklist pane */}
              <div className="w-full lg:w-72 shrink-0 space-y-4">
                
                {/* Print parameters adjusters */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-4 shadow-3xs">
                  <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <Settings className="w-4 h-4 text-indigo-600" />
                    <span>Druckparameter</span>
                  </h4>
                  
                  {/* Spacing template option */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Layout / Format</label>
                    <select
                      value={printLayout}
                      onChange={(e: any) => setPrintLayout(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold"
                    >
                      <option value="a4-8">A4 (8 Ausweise • 2x4)</option>
                      <option value="a4-15">A4 (15 Etiketten • 3x5)</option>
                      <option value="single">Einzelausweis / Label</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Farbdesign</label>
                    <select
                      value={printStyle}
                      onChange={(e: any) => setPrintStyle(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold"
                    >
                      <option value="dark">Cosmic Indigo (Dunkel)</option>
                      <option value="light">Eco Light (Hell)</option>
                      <option value="barcode-only">Schwarz-Weiß (S/W)</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="preview-cutlines"
                      checked={showCutLines}
                      onChange={(e) => setShowCutLines(e.target.checked)}
                      className="w-4 h-4 text-indigo-600 border-gray-300 rounded cursor-pointer"
                    />
                    <label htmlFor="preview-cutlines" className="text-xs font-bold text-slate-700 cursor-pointer">
                      Schneidelinien zeichnen
                    </label>
                  </div>
                </div>

                {/* Crucial help note */}
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl space-y-2 text-amber-900 shadow-3xs">
                  <div className="flex items-center gap-1.5">
                    <HelpCircle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span className="font-extrabold text-xs">Wichtiger Druckhinweis!</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    Um die farbigen Ausweismotive (Cosmic Dunkel) exakt auszudrucken, aktiviere im System-Druckdialog deines Browsers die Option:
                  </p>
                  <p className="font-bold text-[11px] border-l-2 border-amber-400 pl-2">
                    "Hintergrundgrafiken" (Background Graphics) drucken
                  </p>
                  <p className="text-[11px] leading-relaxed">
                    Setze die Ränder auf <strong>"Keine" (None)</strong> für eine perfekte Ausrichtung des Rasters.
                  </p>
                </div>

              </div>

              {/* Live print sheet render simulation - Scrollable workspace */}
              <div className="flex-1 flex flex-col items-center gap-8 overflow-y-auto max-h-[60vh] lg:max-h-[70vh] border border-slate-200 bg-slate-300/40 p-6 rounded-2xl shadow-inner">
                {printPages.length === 0 ? (
                  <div className="text-center py-16 text-slate-400 font-medium">
                    Keine Ausweise ausgewählt.
                  </div>
                ) : (
                  printPages.map((pageMembers: Member[], pageIndex) => (
                    <div 
                      key={pageIndex}
                      className="relative bg-white shadow-2xl shrink-0 border border-slate-300"
                      style={{
                        width: printLayout === "single" ? "100mm" : "210mm",
                        minHeight: printLayout === "single" ? "60mm" : "297mm",
                        padding: printLayout === "single" ? "4mm" : printLayout === "a4-15" ? "12mm 10mm" : "15mm 12mm",
                        boxSizing: "border-box",
                      }}
                    >
                      {/* Floating page index indicator for multiple sheets */}
                      {printLayout !== "single" && (
                        <div className="absolute top-2 left-2 bg-slate-800 text-white font-mono text-[9px] px-2 py-0.5 rounded shadow-xs z-10 select-none">
                          Seite {pageIndex + 1} von {printPages.length}
                        </div>
                      )}

                      {/* Flex or Grid container */}
                      <div 
                        className={
                          printLayout === "single"
                            ? "flex items-center justify-center w-full h-full"
                            : printLayout === "a4-15"
                            ? "grid grid-cols-3 gap-x-[6mm] gap-y-[8mm] justify-center"
                            : "grid grid-cols-2 gap-x-[14mm] gap-y-[12mm] justify-center"
                        }
                      >
                        {pageMembers.map((member) => (
                          <PrintCard
                            key={member.id}
                            member={member}
                            style={printStyle}
                            layout={printLayout}
                            showCutLines={showCutLines}
                          />
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>

            </div>

            {/* Modal actions footer */}
            <div className="px-6 py-4 border-t border-gray-200 bg-slate-50 flex items-center justify-between shrink-0">
              <span className="text-[11px] text-slate-500 font-semibold flex items-center gap-1">
                <Check className="w-4 h-4 text-emerald-500" />
                Vektorscharfe Code-39 Barcodes
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowPrintPreview(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Zurück
                </button>
                <button
                  type="button"
                  onClick={handleTriggerPrint}
                  className="px-6 py-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-2 shadow-xs transition-colors"
                >
                  <Printer className="w-4.5 h-4.5" />
                  <span>Jetzt drucken</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Synchronized Printed DOM Area - Invisible on screen, perfectly formatted on printed pages */}
      <div id="print-area" className="hidden">
        {printPages.map((pageMembers: Member[], pageIndex) => (
          <div 
            key={pageIndex}
            className={`print-sheet ${
              printLayout === "single" 
                ? "print-sheet-single" 
                : printLayout === "a4-15" 
                ? "print-sheet-grid-15" 
                : "print-sheet-grid-8"
            }`}
          >
            {pageMembers.map((member) => (
              <PrintCard
                key={member.id}
                member={member}
                style={printStyle}
                layout={printLayout}
                showCutLines={showCutLines}
              />
            ))}
          </div>
        ))}
      </div>

    </div>
  );
};
