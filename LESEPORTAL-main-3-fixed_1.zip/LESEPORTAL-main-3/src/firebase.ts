import { initializeApp } from "firebase/app";
import { initializeFirestore } from "firebase/firestore";

// Firebase configuration from firebase-applet-config.json
const firebaseConfig = {
  apiKey: "AIzaSyApjePpFGU-QgcMJSbcQf4q0pP39PtgiSw",
  authDomain: "authentic-acronym-j07pf.firebaseapp.com",
  projectId: "authentic-acronym-j07pf",
  storageBucket: "authentic-acronym-j07pf.firebasestorage.app",
  messagingSenderId: "556986089614",
  appId: "1:556986089614:web:7a902496ec00148d25c9df",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore pointing to our custom database ID
const db = initializeFirestore(app, {}, "ai-studio-4241663d-8866-4fbc-b468-821a9c2a9cb8");

export { app, db };
