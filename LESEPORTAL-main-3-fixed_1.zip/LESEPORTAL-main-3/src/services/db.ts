import {
  collection,
  getDocs,
  setDoc,
  doc,
  deleteDoc,
  updateDoc,
} from "firebase/firestore";
import { db } from "../firebase";

import { Book, Member, Loan, LibraryUser, School, LibraryOpeningHours } from "../types";

// ----------------------------------------------------
// SEED / DEFAULT DATA
// ----------------------------------------------------
const DEFAULT_SCHOOLS: School[] = [
  {
    id: "DEMO123",
    name: "Goethe-Gymnasium",
    isActive: true,
    createdAt: "2026-06-01T12:00:00.000Z",
  },
  {
    id: "SCHULE-A",
    name: "Schiller-Realschule",
    isActive: true,
    createdAt: "2026-06-02T12:00:00.000Z",
  }
];
const DEFAULT_BOOKS: Book[] = [
  {
    id: "9783453148643",
    isbn: "9783453148643",
    title: "Der Hobbit",
    author: "J.R.R. Tolkien",
    description: "Die klassische Fantasy-Erzählung über Bilbo Beutlins abenteuerliche Reise zum Einsamen Berg, um einen verlorenen Schatz von einem Drachen zurückzuerobern.",
    genre: "Fantasy",
    price: 14.99,
    pages: 384,
    status: "available",
    borrowerId: null,
    borrowerName: null,
    dueDate: null,
    createdAt: "2026-06-01T10:00:00.000Z",
  },
  {
    id: "9783150000014",
    isbn: "9783150000014",
    title: "Faust: Der Tragödie erster Teil",
    author: "Johann Wolfgang von Goethe",
    description: "Das weltberühmte deutsche Drama über den Gelehrten Faust, seine Sinnkrise und den verhängnisvollen Pakt mit dem Teufel Mephisto.",
    genre: "Klassiker",
    price: 9.90,
    pages: 168,
    status: "available",
    borrowerId: null,
    borrowerName: null,
    dueDate: null,
    createdAt: "2026-06-02T10:00:00.000Z",
  },
  {
    id: "9783257230475",
    isbn: "9783257230475",
    title: "Die Physiker",
    author: "Friedrich Dürrenmatt",
    description: "Eine groteske Komödie im Irrenhaus über die ethische Verantwortung der Wissenschaft im Atomzeitalter.",
    genre: "Drama",
    price: 11.50,
    pages: 96,
    status: "borrowed",
    borrowerId: "L-20005",
    borrowerName: "Dr. Andreas Meyer",
    dueDate: "2026-07-20",
    createdAt: "2026-06-03T10:00:00.000Z",
  },
  {
    id: "9783849045333",
    isbn: "9783849045333",
    title: "Abitur-Wissen Physik",
    author: "Stark Redaktion",
    description: "Kompaktes Lern- und Nachschlagewerk zur idealen Vorbereitung auf das Physik-Abitur in der Oberstufe.",
    genre: "Sachbuch",
    price: 16.95,
    pages: 250,
    status: "borrowed",
    borrowerId: "S-10021",
    borrowerName: "Max Mustermann",
    dueDate: "2026-06-18", // Overdue relative to current date 2026-06-24
    createdAt: "2026-06-04T10:00:00.000Z",
  },
];

const DEFAULT_MEMBERS: Member[] = [
  {
    id: "S-10021",
    name: "Max Mustermann",
    role: "Schüler",
    classOrSubject: "Klasse 10b",
    barcode: "S-10021",
    createdAt: "2026-06-01T11:00:00.000Z",
  },
  {
    id: "S-10022",
    name: "Emma Schmidt",
    role: "Schüler",
    classOrSubject: "Klasse 12a",
    barcode: "S-10022",
    createdAt: "2026-06-02T11:00:00.000Z",
  },
  {
    id: "L-20005",
    name: "Dr. Andreas Meyer",
    role: "Lehrer",
    classOrSubject: "Mathematik, Physik",
    barcode: "L-20005",
    createdAt: "2026-06-03T11:00:00.000Z",
  },
  {
    id: "L-20006",
    name: "Sabine Weber",
    role: "Lehrer",
    classOrSubject: "Deutsch, Geschichte",
    barcode: "L-20006",
    createdAt: "2026-06-04T11:00:00.000Z",
  },
];

const DEFAULT_LOANS: Loan[] = [
  {
    id: "loan_1",
    bookId: "9783257230475",
    bookTitle: "Die Physiker",
    memberId: "L-20005",
    memberName: "Dr. Andreas Meyer",
    memberRole: "Lehrer",
    loanDate: "2026-06-20",
    dueDate: "2026-07-20",
    returnDate: null,
    extendedCount: 0,
    status: "active",
  },
  {
    id: "loan_2",
    bookId: "9783849045333",
    bookTitle: "Abitur-Wissen Physik",
    memberId: "S-10021",
    memberName: "Max Mustermann",
    memberRole: "Schüler",
    loanDate: "2026-06-04",
    dueDate: "2026-06-18",
    returnDate: null,
    extendedCount: 0,
    status: "overdue",
  },
];

const DEFAULT_USERS: LibraryUser[] = [
  {
    id: "U-0",
    username: "superadmin",
    passwordHash: "E.king20124242", // TODO: Use bcrypt hashing in production
    name: "System Superadmin",
    role: "Superadmin",
    classOrSubject: "Global System",
    memberId: null,
    schoolCode: "SYSTEM",
    isActive: true,
    createdAt: "2026-06-01T12:00:00.000Z",
  },
  {
    id: "U-1",
    username: "buecherei",
    passwordHash: "buecherei123",
    name: "Frau Müller (Bücherei)",
    role: "Bücherei-Lehrer/in",
    classOrSubject: "Bücherei-Aufsicht",
    memberId: null,
    schoolCode: "DEMO123",
    isActive: true,
    createdAt: "2026-06-01T12:00:00.000Z",
  },
  {
    id: "U-2",
    username: "max",
    passwordHash: "max123",
    name: "Max Mustermann",
    role: "Schüler",
    classOrSubject: "Klasse 10b",
    memberId: "S-10021",
    schoolCode: "DEMO123",
    isActive: true,
    createdAt: "2026-06-01T12:00:00.000Z",
  },
  {
    id: "U-3",
    username: "meyer",
    passwordHash: "meyer123",
    name: "Dr. Andreas Meyer",
    role: "Lehrer",
    classOrSubject: "Mathematik, Physik",
    memberId: "L-20005",
    schoolCode: "DEMO123",
    isActive: true,
    createdAt: "2026-06-01T12:00:00.000Z",
  },
];

// Helper to determine loan state relative to a given date (Current date: 2026-06-24)
export function getLoanStatus(loan: Loan, currentDateStr = new Date().toISOString().split("T")[0]): "active" | "returned" | "overdue" {
  if (loan.returnDate) return "returned";
  if (loan.dueDate < currentDateStr) return "overdue";
  return "active";
}

// ----------------------------------------------------
// DATABASE SERVICE (FIRESTORE + LOCALSTORAGE)
// ----------------------------------------------------
export class LibraryDB {
  private static getLocal<T>(key: string): T | null {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  private static setLocal<T>(key: string, data: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error("Local storage error:", e);
    }
  }

  // --- BOOKS METHODS ---
  static async getBooks(): Promise<Book[]> {
    try {
      const booksCol = collection(db, "books");
      const snapshot = await getDocs(booksCol);
      const list = snapshot.docs.map((d) => d.data() as Book);

      if (list.length === 0) {
        // Seed Firestore if empty, and write to localStorage
        const cached = this.getLocal<Book[]>("library_books");
        const initial = cached && cached.length > 0 ? cached : DEFAULT_BOOKS;
        for (const book of initial) {
          await setDoc(doc(db, "books", book.id), book);
        }
        this.setLocal("library_books", initial);
        return initial;
      }

      this.setLocal("library_books", list);
      return list;
    } catch (err) {
      console.warn("Firestore error, loading books from LocalStorage:", err);
      const cached = this.getLocal<Book[]>("library_books");
      if (!cached) {
        this.setLocal("library_books", DEFAULT_BOOKS);
        return DEFAULT_BOOKS;
      }
      return cached;
    }
  }

  static async saveBook(book: Book): Promise<void> {
    const list = await this.getBooks();
    const updated = list.filter((b) => b.id !== book.id);
    updated.push(book);
    this.setLocal("library_books", updated);

    try {
      await setDoc(doc(db, "books", book.id), book);
    } catch (err) {
      console.warn("Firestore saveBook failed, saved locally:", err);
    }
  }

  static async deleteBook(id: string): Promise<void> {
    const list = await this.getBooks();
    const updated = list.filter((b) => b.id !== id);
    this.setLocal("library_books", updated);

    try {
      await deleteDoc(doc(db, "books", id));
    } catch (err) {
      console.warn("Firestore deleteBook failed, deleted locally:", err);
    }
  }

  // --- MEMBERS METHODS ---
  static async getMembers(): Promise<Member[]> {
    try {
      const col = collection(db, "members");
      const snapshot = await getDocs(col);
      const list = snapshot.docs.map((d) => d.data() as Member);

      if (list.length === 0) {
        const cached = this.getLocal<Member[]>("library_members");
        const initial = cached && cached.length > 0 ? cached : DEFAULT_MEMBERS;
        for (const m of initial) {
          await setDoc(doc(db, "members", m.id), m);
        }
        this.setLocal("library_members", initial);
        return initial;
      }

      this.setLocal("library_members", list);
      return list;
    } catch (err) {
      console.warn("Firestore error, loading members from LocalStorage:", err);
      const cached = this.getLocal<Member[]>("library_members");
      if (!cached) {
        this.setLocal("library_members", DEFAULT_MEMBERS);
        return DEFAULT_MEMBERS;
      }
      return cached;
    }
  }

  static async saveMember(member: Member): Promise<void> {
    const list = await this.getMembers();
    const updated = list.filter((m) => m.id !== member.id);
    updated.push(member);
    this.setLocal("library_members", updated);

    try {
      await setDoc(doc(db, "members", member.id), member);
    } catch (err) {
      console.warn("Firestore saveMember failed, saved locally:", err);
    }
  }

  static async deleteMember(id: string): Promise<void> {
    const list = await this.getMembers();
    const updated = list.filter((m) => m.id !== id);
    this.setLocal("library_members", updated);

    try {
      await deleteDoc(doc(db, "members", id));
    } catch (err) {
      console.warn("Firestore deleteMember failed, deleted locally:", err);
    }
  }

  // --- LOANS METHODS ---
  static async getLoans(): Promise<Loan[]> {
    try {
      const col = collection(db, "loans");
      const snapshot = await getDocs(col);
      const list = snapshot.docs.map((d) => d.data() as Loan);

      if (list.length === 0) {
        const cached = this.getLocal<Loan[]>("library_loans");
        const initial = cached && cached.length > 0 ? cached : DEFAULT_LOANS;
        for (const l of initial) {
          await setDoc(doc(db, "loans", l.id), l);
        }
        this.setLocal("library_loans", initial);
        return initial;
      }

      // Check overdue statuses against current date 2026-06-24
      const updatedList = list.map((l) => ({
        ...l,
        status: getLoanStatus(l),
      }));

      this.setLocal("library_loans", updatedList);
      return updatedList;
    } catch (err) {
      console.warn("Firestore error, loading loans from LocalStorage:", err);
      const cached = this.getLocal<Loan[]>("library_loans");
      const initial = cached || DEFAULT_LOANS;
      const updatedList = initial.map((l) => ({
        ...l,
        status: getLoanStatus(l),
      }));
      this.setLocal("library_loans", updatedList);
      return updatedList;
    }
  }

  static async createLoan(loan: Loan): Promise<void> {
    // 1. Save loan
    const loansList = await this.getLoans();
    const updatedLoans = [...loansList.filter((l) => l.id !== loan.id), loan];
    this.setLocal("library_loans", updatedLoans);

    // 2. Update book status to borrowed
    const booksList = await this.getBooks();
    const targetBook = booksList.find((b) => b.id === loan.bookId);
    if (targetBook) {
      targetBook.status = "borrowed";
      targetBook.borrowerId = loan.memberId;
      targetBook.borrowerName = loan.memberName;
      targetBook.dueDate = loan.dueDate;
      await this.saveBook(targetBook);
    }

    try {
      await setDoc(doc(db, "loans", loan.id), loan);
    } catch (err) {
      console.warn("Firestore createLoan failed, saved locally:", err);
    }
  }

  static async returnLoan(loanId: string, returnDate = new Date().toISOString().split("T")[0]): Promise<void> {
    const loansList = await this.getLoans();
    const loan = loansList.find((l) => l.id === loanId);
    if (!loan) return;

    // 1. Update loan
    loan.returnDate = returnDate;
    loan.status = "returned";
    const updatedLoans = loansList.map((l) => (l.id === loanId ? loan : l));
    this.setLocal("library_loans", updatedLoans);

    // 2. Update book to available
    const booksList = await this.getBooks();
    const targetBook = booksList.find((b) => b.id === loan.bookId);
    if (targetBook) {
      targetBook.status = "available";
      targetBook.borrowerId = null;
      targetBook.borrowerName = null;
      targetBook.dueDate = null;
      await this.saveBook(targetBook);
    }

    try {
      await setDoc(doc(db, "loans", loanId), loan);
    } catch (err) {
      console.warn("Firestore returnLoan failed, saved locally:", err);
    }
  }

  static async extendLoan(loanId: string, newDueDate: string): Promise<void> {
    const loansList = await this.getLoans();
    const loan = loansList.find((l) => l.id === loanId);
    if (!loan) return;

    // 1. Update loan
    loan.dueDate = newDueDate;
    loan.extendedCount += 1;
    loan.status = getLoanStatus(loan);
    const updatedLoans = loansList.map((l) => (l.id === loanId ? loan : l));
    this.setLocal("library_loans", updatedLoans);

    // 2. Update book due date
    const booksList = await this.getBooks();
    const targetBook = booksList.find((b) => b.id === loan.bookId);
    if (targetBook) {
      targetBook.dueDate = newDueDate;
      await this.saveBook(targetBook);
    }

    try {
      await setDoc(doc(db, "loans", loanId), loan);
    } catch (err) {
      console.warn("Firestore extendLoan failed, saved locally:", err);
    }
  }

  // --- USERS METHODS ---
  static async getUsers(): Promise<LibraryUser[]> {
    try {
      const col = collection(db, "users");
      const snapshot = await getDocs(col);
      let list = snapshot.docs.map((d) => d.data() as LibraryUser);

      if (list.length === 0) {
        const cached = this.getLocal<LibraryUser[]>("library_users");
        const initial = cached && cached.length > 0 ? cached : DEFAULT_USERS;
        for (const u of initial) {
          await setDoc(doc(db, "users", u.id), u);
        }
        this.setLocal("library_users", initial);
        return initial;
      }

      // Check if superadmin is missing in Firestore
      const hasSuperadmin = list.some((u) => u.username === "superadmin");
      if (!hasSuperadmin) {
        const superadminUser: LibraryUser = {
          id: "U-0",
          username: "superadmin",
          passwordHash: "E.king20124242",
          name: "System Superadmin",
          role: "Superadmin",
          classOrSubject: "Global System",
          memberId: null,
          schoolCode: "SYSTEM",
          isActive: true,
          createdAt: new Date().toISOString(),
        };
        await setDoc(doc(db, "users", superadminUser.id), superadminUser);
        list.push(superadminUser);
      }

      // Ensure superadmin password is up to date in firestore/local cache
      let modified = false;
      list = list.map((u) => {
        if (u.username === "superadmin" && u.passwordHash !== "E.king20124242") {
          modified = true;
          return { ...u, passwordHash: "E.king20124242" };
        }
        return u;
      });

      if (modified) {
        const superadminUser = list.find((u) => u.username === "superadmin");
        if (superadminUser) {
          await setDoc(doc(db, "users", superadminUser.id), superadminUser);
        }
      }

      this.setLocal("library_users", list);
      return list;
    } catch (err) {
      console.warn("Firestore error, loading users from LocalStorage:", err);
      let cached = this.getLocal<LibraryUser[]>("library_users");
      if (!cached) {
        this.setLocal("library_users", DEFAULT_USERS);
        return DEFAULT_USERS;
      }

      // Check if superadmin is missing in local storage cache
      const hasSuperadmin = cached.some((u) => u.username === "superadmin");
      if (!hasSuperadmin) {
        const superadminUser: LibraryUser = {
          id: "U-0",
          username: "superadmin",
          passwordHash: "E.king20124242",
          name: "System Superadmin",
          role: "Superadmin",
          classOrSubject: "Global System",
          memberId: null,
          schoolCode: "SYSTEM",
          isActive: true,
          createdAt: new Date().toISOString(),
        };
        cached.push(superadminUser);
        this.setLocal("library_users", cached);
      }
      
      let modified = false;
      cached = cached.map((u) => {
        if (u.username === "superadmin" && u.passwordHash !== "E.king20124242") {
          modified = true;
          return { ...u, passwordHash: "E.king20124242" };
        }
        return u;
      });
      if (modified) {
        this.setLocal("library_users", cached);
      }
      return cached;
    }
  }

  static async saveUser(user: LibraryUser): Promise<void> {
    const list = await this.getUsers();
    const updated = list.filter((u) => u.id !== user.id);
    updated.push(user);
    this.setLocal("library_users", updated);

    try {
      await setDoc(doc(db, "users", user.id), user);
    } catch (err) {
      console.warn("Firestore saveUser failed, saved locally:", err);
    }
  }

  static async deleteUser(userId: string): Promise<void> {
    const list = await this.getUsers();
    const updated = list.filter((u) => u.id !== userId);
    this.setLocal("library_users", updated);

    try {
      await deleteDoc(doc(db, "users", userId));
    } catch (err) {
      console.warn("Firestore deleteUser failed, deleted locally:", err);
    }
  }

  static async registerUser(user: LibraryUser): Promise<void> {
    // 1. Save user
    await this.saveUser(user);

    // 2. Automatically register them as a Member if pupils/teachers so they can borrow books right away
    if (user.memberId && (user.role === "Schüler" || user.role === "Lehrer")) {
      const newMember: Member = {
        id: user.memberId,
        name: user.name,
        role: user.role === "Lehrer" ? "Lehrer" : "Schüler",
        classOrSubject: user.classOrSubject,
        barcode: user.memberId,
        createdAt: new Date().toISOString(),
      };
      await this.saveMember(newMember);
    }
  }

  // --- SCHOOLS METHODS ---
  static async getSchools(): Promise<School[]> {
    try {
      const col = collection(db, "schools");
      const snapshot = await getDocs(col);
      const list = snapshot.docs.map((d) => d.data() as School);

      if (list.length === 0) {
        const cached = this.getLocal<School[]>("library_schools");
        const initial = cached && cached.length > 0 ? cached : DEFAULT_SCHOOLS;
        for (const s of initial) {
          await setDoc(doc(db, "schools", s.id), s);
        }
        this.setLocal("library_schools", initial);
        return initial;
      }

      this.setLocal("library_schools", list);
      return list;
    } catch (err) {
      console.warn("Firestore error, loading schools from LocalStorage:", err);
      const cached = this.getLocal<School[]>("library_schools");
      if (!cached) {
        this.setLocal("library_schools", DEFAULT_SCHOOLS);
        return DEFAULT_SCHOOLS;
      }
      return cached;
    }
  }

  static async saveSchool(school: School): Promise<void> {
    const list = await this.getSchools();
    const updated = list.filter((s) => s.id !== school.id);
    updated.push(school);
    this.setLocal("library_schools", updated);

    try {
      await setDoc(doc(db, "schools", school.id), school);
    } catch (err) {
      console.warn("Firestore saveSchool failed, saved locally:", err);
    }
  }

  static async deleteSchool(schoolId: string): Promise<void> {
    const list = await this.getSchools();
    const updated = list.filter((s) => s.id !== schoolId);
    this.setLocal("library_schools", updated);

    try {
      await deleteDoc(doc(db, "schools", schoolId));
    } catch (err) {
      console.warn("Firestore deleteSchool failed, deleted locally:", err);
    }
  }

  // --- OPENING HOURS METHODS ---
  static async getOpeningHoursList(): Promise<LibraryOpeningHours[]> {
    try {
      const col = collection(db, "opening_hours");
      const snapshot = await getDocs(col);
      const list = snapshot.docs.map((d) => d.data() as LibraryOpeningHours);

      if (list.length === 0) {
        const cached = this.getLocal<LibraryOpeningHours[]>("library_opening_hours") || [];
        this.setLocal("library_opening_hours", cached);
        return cached;
      }
      this.setLocal("library_opening_hours", list);
      return list;
    } catch (err) {
      console.warn("Firestore error, loading opening hours from LocalStorage:", err);
      return this.getLocal<LibraryOpeningHours[]>("library_opening_hours") || [];
    }
  }

  static async getOpeningHours(schoolCode: string): Promise<LibraryOpeningHours> {
    const list = await this.getOpeningHoursList();
    const matched = list.find((h) => h.schoolCode === schoolCode);
    if (matched) return matched;

    // Default opening hours
    return {
      schoolCode,
      monday: "08:00 - 13:30",
      tuesday: "08:00 - 13:30",
      wednesday: "08:00 - 12:00",
      thursday: "08:00 - 13:30",
      friday: "08:00 - 13:00",
      saturday: "Geschlossen",
      sunday: "Geschlossen",
      additionalInfo: "In den großen Pausen geöffnet. Ausleihe und Rückgabe möglich."
    };
  }

  static async saveOpeningHours(hours: LibraryOpeningHours): Promise<void> {
    const list = await this.getOpeningHoursList();
    const updated = list.filter((h) => h.schoolCode !== hours.schoolCode);
    updated.push(hours);
    this.setLocal("library_opening_hours", updated);

    try {
      await setDoc(doc(db, "opening_hours", hours.schoolCode), hours);
    } catch (err) {
      console.warn("Firestore saveOpeningHours failed, saved locally:", err);
    }
  }
}

