export interface Book {
  id: string; // ISBN or auto-id
  isbn: string;
  title: string;
  author: string;
  description: string;
  genre: string;
  price: number;
  pages: number;
  status: "available" | "borrowed";
  borrowerId: string | null;
  borrowerName: string | null;
  dueDate: string | null;
  createdAt: string;
}

export interface Member {
  id: string; // "S-XXXXX" or "L-XXXXX"
  name: string;
  role: "Schüler" | "Lehrer";
  classOrSubject: string; // Class for students, subjects for teachers
  barcode: string; // Same as id
  createdAt: string;
}

export interface Loan {
  id: string;
  bookId: string;
  bookTitle: string;
  memberId: string;
  memberName: string;
  memberRole: "Schüler" | "Lehrer";
  loanDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  returnDate: string | null; // YYYY-MM-DD if returned, else null
  extendedCount: number;
  status: "active" | "returned" | "overdue";
}

export interface LibraryUser {
  id: string;
  username: string;
  passwordHash: string; // for simplicity and demo-ready, we store simple passwords
  name: string;
  role: "Schüler" | "Lehrer" | "Bücherei-Lehrer/in" | "Superadmin";
  classOrSubject: string;
  memberId: string | null; // linked member card ID
  schoolCode: string;
  isActive?: boolean; // whether this user account is active or paused
  createdAt: string;
}

export interface School {
  id: string; // Schulcode (uppercase)
  name: string; // Schulname
  isActive: boolean; // Aktiv oder Pausiert
  createdAt: string;
}

export interface LibraryOpeningHours {
  schoolCode: string;
  monday: string;
  tuesday: string;
  wednesday: string;
  thursday: string;
  friday: string;
  saturday: string;
  sunday: string;
  additionalInfo?: string;
}

